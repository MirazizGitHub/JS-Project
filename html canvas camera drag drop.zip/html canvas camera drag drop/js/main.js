const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

canvas.width = 700;
canvas.height = 500;



let is_dragging = false;
let startX = 0;
let startY = 0;


let mouseCordinate = {
    x: 0,
    y: 0,
}


let is_mouse_in_shape = function(x, y, canv) {
    

    if (x > 0 && x < canv.width && y > 0 && y < canv.height) {
        return true;
    }

    return false;
}


let mouse_down = function(event) {
    event.preventDefault();

    startX = parseInt(event.clientX);
    startY = parseInt(event.clientY);

	
        if (is_mouse_in_shape(startX, startY, canvas)) {
            is_dragging = true;
            return;
        }
}

let mouse_up = function(event) {
    if (!is_dragging) {
        return;
    }

    event.preventDefault();
    is_dragging = false;
}

let mouse_out = function(event) {
    if (!is_dragging) {
        return;
    }

    event.preventDefault();
    is_dragging = false;
}

let mouse_move = function(event) {
    if (!is_dragging) {
        return;
    } else {
        event.preventDefault();
        let mouseX = parseInt(event.clientX);
        let mouseY = parseInt(event.clientY);

        let dx = mouseX - startX;
        let dy = mouseY - startY;


        mouseCordinate.x = mouseCordinate.x - dx;
        mouseCordinate.y = mouseCordinate.y - dy;

        // console.log(mouseCordinate.x);


        startX = mouseX;
        startY = mouseY;
    }
}


canvas.onmousedown = mouse_down;
canvas.onmouseup = mouse_up;
canvas.onmouseout = mouse_out;
canvas.onmousemove = mouse_move;




function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    /* */
    init();
    /* */
    requestAnimationFrame(animate);
}
animate();