let level1 = new Level({
    size: [2184, 1365],
    objects: {
        backgroundEffect: [
            new Background(), /*  size: 728 455  */
        ],
    }
});