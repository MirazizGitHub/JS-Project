class Level {
    constructor(options) {
        this.objects = [];
        /* camera start */
        this.size = options.size || [canvas.width, canvas.height];
        this.cameraPos = options.cameraPos || [0, this.size[1] - canvas.height];
        this.originalCameraPos = [this.cameraPos[0], this.cameraPos[1]];
        /**/
        this.bg = options.objects.backgroundEffect;

        this.player = null;
        /**/
    }
    updateCamera() {
        /**/
        this.bg.forEach(bgc => {
            bgc.level = this;
            bgc.update();
            bgc.draw();
        });
    }
    update() {
        /**/
        if (mouseCordinate.x < 0) {
            mouseCordinate.x = 0;
        }
        if (mouseCordinate.y < 0) {
            mouseCordinate.y = 0;
        }
        if (mouseCordinate.x > this.size[0] - canvas.width) {
            mouseCordinate.x = this.size[0] - canvas.width;
        }
        if (mouseCordinate.y > this.size[1] - canvas.height) {
            mouseCordinate.y = this.size[1] - canvas.height;
        }
        /**/
        this.updateCamera();
        this.cameraPos[0] = minmax(
            Math.abs(mouseCordinate.x),
            0,
            this.size[0] - canvas.width
        );
        this.cameraPos[1] = minmax(
            Math.abs(mouseCordinate.y),
            0,
            this.size[1] - canvas.height
        );
    }
    draw() {
        ctx.beginPath();
        ctx.fillStyle = 'white';
        ctx.font = "30px Arial";
        ctx.fillText('Html canvas Camera drag drop Field !!!', 50, 50);
        ctx.fill();
        ctx.closePath();
    }
}
function minmax(val, min, max) {
    return Math.max(min, Math.min(max, val));
}
