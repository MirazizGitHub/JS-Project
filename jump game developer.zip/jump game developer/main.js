
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

canvas.width = 600;
canvas.height = 400;

let arrowLeft = false, arrowRight = false, arrowTop = false, arrowBottom = false, space = false;

const objects = [];

let player = new Player();

class Rectangle {
	constructor(x, y, width, height, color) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.color = color;
	}
	physics () {	}
	draw () {
		ctx.beginPath();
		ctx.fillStyle = this.color;
		ctx.fillRect(this.x, this.y, this.width, this.height);
		ctx.closePath();
	}
}


objects.push(new Rectangle(80, 300, 100, 10, 'blue'));
objects.push(new Rectangle(300, 280, 10, 100, 'purple'));
objects.push(new Rectangle(400, 130, 100, 10, 'orangered'));


function init() {
	objects.forEach(obj => {
		obj.physics();
		obj.draw();
	});
	player.update();
	player.control();
	player.draw();
}


function animate() {
	ctx.clearRect(0, 0, canvas.width, canvas.height);

	/*  */
	init();
	/*  */

	requestAnimationFrame(animate);
}
animate();

function controller() {
	document.addEventListener('keydown', (e) => {
		if (e.keyCode === 37) {
			arrowLeft = true;
		}
		if (e.keyCode === 38) {
			arrowTop = true;
		}
		if (e.keyCode === 39) {
			arrowRight = true;
		}
		if (e.keyCode === 40) {
			arrowBottom = true;
		}
		if (e.code = 'Space') {
			space = true;
		}
	});
	document.addEventListener('keyup', (e) => {
		if (e.keyCode === 37) {
			arrowLeft = false;
		}
		if (e.keyCode === 38) {
			arrowTop = false;
		}
		if (e.keyCode === 39) {
			arrowRight = false;
		}
		if (e.keyCode === 40) {
			arrowBottom = false;
		}
		if (e.code = 'Space') {
			space = false;
		}
	});
}
controller();

