
class Player {
	constructor() {
		this.x = 100;
		this.y = 100;
		this.width = 30;
		this.height = 30;
		this.color = 'red';
		this.grav = 0.005;
		this.vel = { x: 0, y: 0 }
		this.speed = 3;
		this.jumpSeed = 4;
		this.onGround = false;
		this.vx = 5;
		this.acc_x = 0;
		this.friction = 0.5;
		this.deltaTime = 30;
		/*   */
	}
	physics() {
		this.vel.x += this.acc_x;
		this.vel.x *= (1 - this.friction);
		this.vel.y += this.grav * this.deltaTime;
		this.x += this.vel.x;
		this.y += this.vel.y * this.speed;
		this.onGround = false;
	}
	update() {
		this.pos_x = this.x;
		this.pos_y = this.y;
		this.physics();
		/* Collision start */
		objects.forEach(obj => {
			/* Bottom collision rectangle */
			if (this.pos_y + this.height <= obj.y && overlapsWith(this, obj)) {
				this.y = (obj.y - this.height);
				this.vel.y = 0;
				this.onGround = true;
            }
            /* Top collision rectangle */
            if (this.pos_y >= obj.y + obj.height && overlapsWith(this, obj)) {
            	this.y = (obj.y + obj.height);
            	this.vel.y = 0;
            }
            /* Left collision rectangle */
            if (this.pos_x + this.width <= obj.x && overlapsWith(this, obj)) {
            	this.x = (obj.x - this.width);
            	this.vel.x = 0;
            }
            /* Right collisio rectangle */
            if (this.pos_x >= obj.x + obj.width && overlapsWith(this, obj)) {
            	this.x = (obj.x + obj.width);
            	this.vel.x = 0;
            }
		});
		/* Collision end */
		if ((this.y + this.height) >= canvas.height) {
            this.y = canvas.height - this.height;
            this.vel.y = 0;
            this.onGround = true;
        }
        if ((this.x + this.width) >= canvas.width) {
        	this.x = canvas.width - this.width;
        	this.vel.x *= -2;
        }
        if (this.x <= 0) {
        	this.x = 0;
        	this.vel.x *= -2;
        }
	}
	control() {
		if (arrowTop) {
			if (this.onGround) {
				this.vel.y -= this.jumpSeed;
				this.onGround = false;
			}
		}
		if (arrowLeft) {
			this.acc_x = -this.vx;
		}
		if (arrowRight) {
			this.acc_x = this.vx;
		}
		if (!arrowLeft && !arrowRight) {
			this.acc_x = 0;
		}

	}
	draw() {
		ctx.beginPath();
		ctx.fillStyle = this.color;
		ctx.fillRect(this.x, this.y, this.width, this.height);
		ctx.fill();
		ctx.closePath();
	}
}

function overlapsWith(player, obj) {
	return (
		player.x <= (obj.x + obj.width) &&
		(player.x + player.width) >= obj.x  &&
		(player.y + player.height) >= obj.y &&
		player.y <= (obj.y + obj.height)
	);
}
