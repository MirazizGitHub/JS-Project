// Canvas ni olish
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

// Asosiy massivlar - barcha ob'ektlar va to'qnashuvlar
const BODIES = [];
const COLLISIONS = [];

// Klaviatura tugmalari holati
let LEFT, UP, RIGHT, DOWN;
let friction = 0; // Ishqalanish koeffitsienti

// ============================================
// VEKTOR KLASSI - matematik amallar uchun
// ============================================
class Vector {
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }

    // Vektorlarni qo'shish
    add(v) {
        return new Vector(this.x + v.x, this.y + v.y);
    }

    // Vektorlarni ayirish
    subtr(v) {
        return new Vector(this.x - v.x, this.y - v.y);
    }

    // Vektor uzunligi
    mag() {
        return Math.sqrt(this.x**2 + this.y**2);
    }

    // Vektorni songa ko'paytirish
    mult(n) {
        return new Vector(this.x * n, this.y * n);
    }

    // Perpendikulyar vektor
    normal() {
        return new Vector(-this.y, this.x).unit();
    }

    // Birlik vektor (uzunligi 1 bo'lgan)
    unit() {
        if(this.mag() === 0) return new Vector(0, 0);
        return new Vector(this.x/this.mag(), this.y/this.mag());
    }

    // Vektorni chizish
    drawVec(start_x, start_y, n, color) {
        ctx.beginPath();
        ctx.moveTo(start_x, start_y);
        ctx.lineTo(start_x + this.x * n, start_y + this.y * n);
        ctx.strokeStyle = color;
        ctx.stroke();
        ctx.closePath();
    }
    
    // Skalyar ko'paytma
    static dot(v1, v2) {
        return v1.x * v2.x + v1.y * v2.y;
    }

    // Vektorli ko'paytma
    static cross(v1, v2) {
        return v1.x * v2.y - v1.y * v2.x;
    }
}

// ============================================
// MATRITSA KLASSI - aylanish uchun
// ============================================
class Matrix {
    constructor(rows, cols) {
        this.rows = rows;
        this.cols = cols;
        this.data = Array(rows).fill().map(() => Array(cols).fill(0));
    }

    // Vektorni matritsaga ko'paytirish
    multiplyVec(vec) {
        return new Vector(
            this.data[0][0] * vec.x + this.data[0][1] * vec.y,
            this.data[1][0] * vec.x + this.data[1][1] * vec.y
        );
    }
}

// ============================================
// CHIZIQ KLASSI
// ============================================
class Line {
    constructor(x0, y0, x1, y1) {
        this.vertex = [new Vector(x0, y0), new Vector(x1, y1)];
        this.dir = this.vertex[1].subtr(this.vertex[0]).unit();
        this.mag = this.vertex[1].subtr(this.vertex[0]).mag();
    }

    draw() {
        ctx.beginPath();
        ctx.moveTo(this.vertex[0].x, this.vertex[0].y);
        ctx.lineTo(this.vertex[1].x, this.vertex[1].y);
        ctx.strokeStyle = "black";
        ctx.stroke();
        ctx.closePath();
    }
}

// ============================================
// DOIRA KLASSI
// ============================================
class Circle {
    constructor(x, y, r) {
        this.vertex = [];
        this.pos = new Vector(x, y);
        this.r = r;
    }

    draw() {
        ctx.beginPath();
        ctx.arc(this.pos.x, this.pos.y, this.r, 0, 2 * Math.PI);
        ctx.stroke();
        ctx.closePath();
    }
}

// ============================================
// TO'RTBURCHAK KLASSI
// ============================================
class Rectangle {
    constructor(x1, y1, x2, y2, w) {
        this.vertex = [];
        this.vertex[0] = new Vector(x1, y1);
        this.vertex[1] = new Vector(x2, y2);
        this.dir = this.vertex[1].subtr(this.vertex[0]).unit();
        this.refDir = this.dir;
        this.length = this.vertex[1].subtr(this.vertex[0]).mag();
        this.width = w;
        
        // To'rtburchak uchlarini hisoblash
        this.vertex[2] = this.vertex[1].add(this.dir.normal().mult(this.width));
        this.vertex[3] = this.vertex[2].add(this.dir.normal().mult(-this.length));
        this.pos = this.vertex[0].add(this.dir.mult(this.length/2)).add(this.dir.normal().mult(this.width/2));
        
        this.angle = 0;
        this.rotMat = new Matrix(2, 2);
    }

    draw() {
        ctx.beginPath();
        ctx.moveTo(this.vertex[0].x, this.vertex[0].y);
        for(let i = 1; i < 4; i++) {
            ctx.lineTo(this.vertex[i].x, this.vertex[i].y);
        }
        ctx.lineTo(this.vertex[0].x, this.vertex[0].y);
        ctx.strokeStyle = "black";
        ctx.stroke();
        ctx.closePath();
    }

    // Aylantirilgan uchlarni qayta hisoblash
    getVertices() {
        this.rotMat = rotMx(this.angle);
        this.dir = this.rotMat.multiplyVec(this.refDir);
        this.vertex[0] = this.pos.add(this.dir.mult(-this.length/2)).add(this.dir.normal().mult(this.width/2));
        this.vertex[1] = this.pos.add(this.dir.mult(-this.length/2)).add(this.dir.normal().mult(-this.width/2));
        this.vertex[2] = this.pos.add(this.dir.mult(this.length/2)).add(this.dir.normal().mult(-this.width/2));
        this.vertex[3] = this.pos.add(this.dir.mult(this.length/2)).add(this.dir.normal().mult(this.width/2));
    }
}

// ============================================
// ASOSIY JISM KLASSI
// ============================================
class Body {
    constructor(x, y) {
        this.comp = [];
        this.pos = new Vector(x, y);
        this.m = 0;           // Massa
        this.inv_m = 0;       // Teskari massa
        this.inertia = 0;     // Inertsiya
        this.inv_inertia = 0; // Teskari inertsiya
        this.elasticity = 1;  // Elastiklik (sakrash)
        
        this.vel = new Vector(0, 0);    // Tezlik
        this.acc = new Vector(0, 0);     // Tezlanish
        this.acceleration = 1;
        this.angVel = 0;                 // Burchak tezligi
        this.player = false;
        BODIES.push(this);
    }

    draw() {}
    display() {}
    reposition() {}
    keyControl() {}
}

// ============================================
// TO'P KLASSI
// ============================================
class Ball extends Body {
    constructor(x, y, r, m) {
        super();
        this.comp = [new Circle(x, y, r)];
        this.m = m;
        this.inv_m = m === 0 ? 0 : 1 / m;
    }

    draw() {
        this.comp[0].draw();
    }

    display() {
        this.vel.drawVec(this.pos.x, this.pos.y, 10, "green");
        ctx.fillStyle = "black";
        ctx.fillText("m = " + this.m, this.pos.x - 10, this.pos.y - 5);
        ctx.fillText("e = " + this.elasticity, this.pos.x - 10, this.pos.y + 5);
    }

    // Pozitsiyani yangilash
    reposition() {
        this.acc = this.acc.unit().mult(this.acceleration);
        this.vel = this.vel.add(this.acc).mult(1 - friction);
        this.comp[0].pos = this.comp[0].pos.add(this.vel);
    }

    // Klaviatura bilan boshqarish
    keyControl() {
        this.acc.x = LEFT ? -this.acceleration : (RIGHT ? this.acceleration : 0);
        this.acc.y = UP ? -this.acceleration : (DOWN ? this.acceleration : 0);
    }
}

// ============================================
// QUTI KLASSI
// ============================================
class Box extends Body {
    constructor(x1, y1, x2, y2, w, m) {
        super();
        this.comp = [new Rectangle(x1, y1, x2, y2, w)];
        this.m = m;
        this.inv_m = m === 0 ? 0 : 1 / m;
        this.inertia = this.m * (this.comp[0].width**2 + this.comp[0].length**2) / 12;
        this.inv_inertia = m === 0 ? 0 : 1 / this.inertia;
    }

    draw() {
        this.comp[0].draw();
    }

    keyControl() {
        if(UP) this.acc = this.comp[0].dir.mult(-this.acceleration);
        if(DOWN) this.acc = this.comp[0].dir.mult(this.acceleration);
        if(LEFT) this.angVel = -0.1;
        if(RIGHT) this.angVel = 0.1;
        if(!UP && !DOWN) this.acc = new Vector(0, 0);
        if(!LEFT && !RIGHT) this.angVel = 0;
    }

    reposition() {
        this.acc = this.acc.unit().mult(this.acceleration);
        this.vel = this.vel.add(this.acc).mult(1 - friction);
        this.comp[0].pos = this.comp[0].pos.add(this.vel);
        this.comp[0].angle += this.angVel;
        this.comp[0].getVertices();
    }
}

// ============================================
// TO'QNASHUV MA'LUMOTLARI
// ============================================
class CollData {
    constructor(o1, o2, axis, pen, vertex) {
        this.o1 = o1;
        this.o2 = o2;
        this.axis = axis;
        this.pen = pen;
        this.vertex = vertex;
    }

    // Penetratsiyani hal qilish
    penRes() {
        let penVec = this.axis.mult(this.pen / (this.o1.inv_m + this.o2.inv_m));
        this.o1.comp[0].pos = this.o1.comp[0].pos.add(penVec.mult(this.o1.inv_m));
        this.o2.comp[0].pos = this.o2.comp[0].pos.add(penVec.mult(-this.o2.inv_m));
    }

    // To'qnashuvni hal qilish
    collRes() {
        let collArm1 = this.vertex.subtr(this.o1.comp[0].pos);
        let rotVel1 = new Vector(-this.o1.angVel * collArm1.y, this.o1.angVel * collArm1.x);
        let closVel1 = this.o1.vel.add(rotVel1);
        
        let collArm2 = this.vertex.subtr(this.o2.comp[0].pos);
        let rotVel2 = new Vector(-this.o2.angVel * collArm2.y, this.o2.angVel * collArm2.x);
        let closVel2 = this.o2.vel.add(rotVel2);

        let impAug1 = Vector.cross(collArm1, this.axis);
        impAug1 = impAug1 * this.o1.inv_inertia * impAug1;
        let impAug2 = Vector.cross(collArm2, this.axis);
        impAug2 = impAug2 * this.o2.inv_inertia * impAug2;

        let relVel = closVel1.subtr(closVel2);
        let sepVel = Vector.dot(relVel, this.axis);
        let new_sepVel = -sepVel * Math.min(this.o1.elasticity, this.o2.elasticity);
        
        let impulse = (new_sepVel - sepVel) / (this.o1.inv_m + this.o2.inv_m + impAug1 + impAug2);
        let impulseVec = this.axis.mult(impulse);

        this.o1.vel = this.o1.vel.add(impulseVec.mult(this.o1.inv_m));
        this.o2.vel = this.o2.vel.add(impulseVec.mult(-this.o2.inv_m));
        this.o1.angVel += this.o1.inv_inertia * Vector.cross(collArm1, impulseVec);
        this.o2.angVel -= this.o2.inv_inertia * Vector.cross(collArm2, impulseVec);
    }
}

// ============================================
// YORDAMCHI FUNKSIYALAR
// ============================================

// Aylanish matritsasi
function rotMx(angle) {
    let m = new Matrix(2, 2);
    m.data[0][0] = Math.cos(angle);
    m.data[0][1] = -Math.sin(angle);
    m.data[1][0] = Math.sin(angle);
    m.data[1][1] = Math.cos(angle);
    return m;
}

// Tasodifiy son
function randInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Foydalanuvchi kirishi
function userInput() {
    canvas.addEventListener('keydown', (event) => {
        if(event.keyCode === 37) LEFT = true;
        if(event.keyCode === 38) UP = true;
        if(event.keyCode === 39) RIGHT = true;
        if(event.keyCode === 40) DOWN = true;
    });
    canvas.addEventListener('keyup', (event) => {
        if(event.keyCode === 37) LEFT = false;
        if(event.keyCode === 38) UP = false;
        if(event.keyCode === 39) RIGHT = false;
        if(event.keyCode === 40) DOWN = false;
    });
}

// SAT algoritmi - to'qnashuvni tekshirish
function sat(o1, o2) {
    let minOverlap = null;
    let smallestAxis;
    let vertexObj;
    let axes = findAxes(o1, o2);
    let firstShapeAxes = getShapeAxes(o1);

    for(let i = 0; i < axes.length; i++) {
        let proj1 = projShapeOntoAxis(axes[i], o1);
        let proj2 = projShapeOntoAxis(axes[i], o2);
        let overlap = Math.min(proj1.max, proj2.max) - Math.max(proj1.min, proj2.min);
        
        if(overlap < 0) return false;

        if((proj1.max > proj2.max && proj1.min < proj2.min) ||
           (proj1.max < proj2.max && proj1.min > proj2.min)) {
            let mins = Math.abs(proj1.min - proj2.min);
            let maxs = Math.abs(proj1.max - proj2.max);
            if(mins < maxs) {
                overlap += mins;
            } else {
                overlap += maxs;
                axes[i] = axes[i].mult(-1);
            }
        }

        if(overlap < minOverlap || minOverlap === null) {
            minOverlap = overlap;
            smallestAxis = axes[i];
            if(i < firstShapeAxes) {
                vertexObj = o2;
                if(proj1.max > proj2.max) smallestAxis = axes[i].mult(-1);
            } else {
                vertexObj = o1;
                if(proj1.max < proj2.max) smallestAxis = axes[i].mult(-1);
            }
        }
    }

    let contactVertex = projShapeOntoAxis(smallestAxis, vertexObj).collVertex;
    if(vertexObj === o2) smallestAxis = smallestAxis.mult(-1);

    return { pen: minOverlap, axis: smallestAxis, vertex: contactVertex };
}

// Shaklni o'qqa proyeksiya qilish
function projShapeOntoAxis(axis, obj) {
    setBallVerticesAlongAxis(obj, axis);
    let min = Vector.dot(axis, obj.vertex[0]);
    let max = min;
    let collVertex = obj.vertex[0];
    
    for(let i = 0; i < obj.vertex.length; i++) {
        let p = Vector.dot(axis, obj.vertex[i]);
        if(p < min) { min = p; collVertex = obj.vertex[i]; }
        if(p > max) max = p;
    }
    return { min: min, max: max, collVertex: collVertex };
}

// Proyeksiya o'qlarini topish
function findAxes(o1, o2) {
    let axes = [];
    if(o1 instanceof Circle && o2 instanceof Circle) {
        axes.push(o2.pos.subtr(o1.pos).unit());
    } else if(o1 instanceof Circle) {
        axes.push(closestVertexToPoint(o2, o1.pos).subtr(o1.pos).unit());
        axes.push(o2.dir.normal());
        if(o2 instanceof Rectangle) axes.push(o2.dir);
    } else if(o2 instanceof Circle) {
        axes.push(o1.dir.normal());
        if(o1 instanceof Rectangle) axes.push(o1.dir);
        axes.push(closestVertexToPoint(o1, o2.pos).subtr(o2.pos).unit());
    } else {
        axes.push(o1.dir.normal());
        if(o1 instanceof Rectangle) axes.push(o1.dir);
        axes.push(o2.dir.normal());
        if(o2 instanceof Rectangle) axes.push(o2.dir);
    }
    return axes;
}

// Eng yaqin uchni topish
function closestVertexToPoint(obj, p) {
    let closestVertex = obj.vertex[0];
    let minDist = p.subtr(obj.vertex[0]).mag();
    
    for(let i = 1; i < obj.vertex.length; i++) {
        let dist = p.subtr(obj.vertex[i]).mag();
        if(dist < minDist) {
            closestVertex = obj.vertex[i];
            minDist = dist;
        }
    }
    return closestVertex;
}

// Shakl o'qlari sonini qaytarish
function getShapeAxes(obj) {
    if(obj instanceof Circle || obj instanceof Line) return 1;
    if(obj instanceof Rectangle) return 2;
}

// To'p uchlarini o'q bo'yicha o'rnatish
function setBallVerticesAlongAxis(obj, axis) {
    if(obj instanceof Circle) {
        obj.vertex[0] = obj.pos.add(axis.unit().mult(-obj.r));
        obj.vertex[1] = obj.pos.add(axis.unit().mult(obj.r));
    }
}

// ============================================
// ASOSIY TSIKL
// ============================================
function mainLoop() {
    ctx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
    userInput();
    COLLISIONS.length = 0;
    
    // Barcha jismlarni yangilash
    BODIES.forEach((b) => {
        b.draw();
        b.display();
        if(b.player) b.keyControl();
        b.reposition();
    });
    
    // To'qnashuvlarni tekshirish
    BODIES.forEach((b, index) => {
        for(let i = index + 1; i < BODIES.length; i++) {
            let bestSat = { pen: null, axis: null, vertex: null };
            
            for(let c1 = 0; c1 < b.comp.length; c1++) {
                for(let c2 = 0; c2 < BODIES[i].comp.length; c2++) {
                    let result = sat(b.comp[c1], BODIES[i].comp[c2]);
                    if(result && result.pen > bestSat.pen) {
                        bestSat = result;
                    }
                }
            }
            
            if(bestSat.pen !== null) {
                COLLISIONS.push(new CollData(b, BODIES[i], bestSat.axis, bestSat.pen, bestSat.vertex));
            }
        }
    });

    // To'qnashuvlarni hal qilish
    COLLISIONS.forEach((c) => {
        c.penRes();
        c.collRes();
    });

    requestAnimationFrame(mainLoop);
}

// ============================================
// BOSHLANG'ICH O'RNATISH
// ============================================
new Box(canvas.width - 35, 10, canvas.width - 35, 30, 570, 0);
new Box(canvas.width - 35, canvas.height - 30, canvas.width - 35, canvas.height - 10, 570, 0);

new Box(30, 10, 30, canvas.height - 10, 20, 0);
new Box(canvas.width - 10, 10, canvas.width - 10, canvas.height - 10, 20, 0);


// Tasodifiy ob'ektlar yaratish
for(let i = 0; i < 10; i++) {
    let x0 = randInt(100, canvas.clientWidth - 100);
    let y0 = randInt(100, canvas.clientHeight - 100);
    let r = randInt(10, 30);
    let m = randInt(1, 10);
    
    if(i % 3 === 1) {
        let x1 = x0 + randInt(-50, 50);
        let y1 = y0 + randInt(-50, 50);
        new Box(x0, y0, x1, y1, r, m);
    }
    if(i % 3 === 2) {
        new Ball(x0, y0, r, m);
    }
}

// O'yinchi to'pi
let playerBall = new Ball(320, 240, 10, 5);
playerBall.player = true;

// Animatsiyani boshlash
requestAnimationFrame(mainLoop);