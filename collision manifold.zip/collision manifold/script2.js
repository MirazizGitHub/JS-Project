// Canvas ni olish
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

// Asosiy massivlar - barcha ob'ektlar va to'qnashuvlar
const BODIES = [];
const COLLISIONS = [];

// Klaviatura tugmalari holati
let LEFT, UP, RIGHT, DOWN;
let friction = 0.009; // Ishqalanish koeffitsienti
let gravity = { x: 0, y: 0 }; // Gravitatsiya

// Gravitatsiya checkbox ni tekshirish
function updateGravity() {
    const gravityCheckbox = document.getElementById('gravt');
    if (gravityCheckbox && gravityCheckbox.checked) {
        gravity = { x: 0, y: 0.5 }; // Gravitatsiya yoqilgan
    } else {
        gravity = { x: 0, y: 0 }; // Gravitatsiya o'chirilgan
    }
}

// ============================================
// MATRITSA KLASSI - aylanish uchun
// ============================================
class Matrix {
    constructor(rows, cols) {
        this.rows = rows;
        this.cols = cols;
        this.data = Array(rows).fill().map(() => Array(cols).fill(0));
    }

    // Vektorni matritsaga ko'paytirish
    multiplyVec(vec) {
        return {
            x: this.data[0][0] * vec.x + this.data[0][1] * vec.y,
            y: this.data[1][0] * vec.x + this.data[1][1] * vec.y
        };
    }
}

// ============================================
// VEKTOR MATEMATIK FUNKSIYALARI
// ============================================

// Vektorlarni qo'shish
function addVectors(v1, v2) {
    return { x: v1.x + v2.x, y: v1.y + v2.y };
}

// Vektorlarni ayirish
function subtractVectors(v1, v2) {
    return { x: v1.x - v2.x, y: v1.y - v2.y };
}

// Vektor uzunligi
function vectorMagnitude(v) {
    return Math.sqrt(v.x ** 2 + v.y ** 2);
}

// Vektorni songa ko'paytirish
function multiplyVector(v, n) {
    return { x: v.x * n, y: v.y * n };
}

// Birlik vektor (uzunligi 1 bo'lgan)
function unitVector(v) {
    const mag = vectorMagnitude(v);
    if (mag === 0) return { x: 0, y: 0 };
    return { x: v.x / mag, y: v.y / mag };
}

// Perpendikulyar vektor
function normalVector(v) {
    return unitVector({ x: -v.y, y: v.x });
}

// Skalyar ko'paytma
function dotProduct(v1, v2) {
    return v1.x * v2.x + v1.y * v2.y;
}

// Vektorli ko'paytma
function crossProduct(v1, v2) {
    return v1.x * v2.y - v1.y * v2.x;
}

// Vektorni chizish
function drawVector(vec, start_x, start_y, n, color) {
    ctx.beginPath();
    ctx.moveTo(start_x, start_y);
    ctx.lineTo(start_x + vec.x * n, start_y + vec.y * n);
    ctx.strokeStyle = color;
    ctx.stroke();
    ctx.closePath();
}

// ============================================
// CHIZIQ KLASSI
// ============================================
class Line {
    constructor(x0, y0, x1, y1) {
        this.vertex = [
            { x: x0, y: y0 },
            { x: x1, y: y1 }
        ];
        const diff = subtractVectors(this.vertex[1], this.vertex[0]);
        this.dir = unitVector(diff);
        this.mag = vectorMagnitude(diff);
    }

    draw() {
        ctx.beginPath();
        ctx.moveTo(this.vertex[0].x, this.vertex[0].y);
        ctx.lineTo(this.vertex[1].x, this.vertex[1].y);
        ctx.strokeStyle = "black";
        ctx.stroke();
        ctx.closePath();
    }
}

// ============================================
// DOIRA KLASSI
// ============================================
class Circle {
    constructor(x, y, r) {
        this.vertex = [];
        this.pos = { x: x, y: y };
        this.r = r;
        this.angle = 0; // Aylanish burchagi
    }

    draw() {
        ctx.beginPath();
        ctx.arc(this.pos.x, this.pos.y, this.r, 0, 2 * Math.PI);
        ctx.stroke();
        
        // To'pning aylanishini ko'rsatish uchun chiziq
        ctx.beginPath();
        ctx.moveTo(this.pos.x, this.pos.y);
        ctx.lineTo(
            this.pos.x + Math.cos(this.angle) * this.r,
            this.pos.y + Math.sin(this.angle) * this.r
        );
        ctx.strokeStyle = "red";
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.strokeStyle = "black";
        ctx.lineWidth = 1;
        
        ctx.closePath();
    }
}

// ============================================
// TO'RTBURCHAK KLASSI
// ============================================
class Rectangle {
    constructor(x1, y1, x2, y2, w) {
        this.vertex = [];
        this.vertex[0] = { x: x1, y: y1 };
        this.vertex[1] = { x: x2, y: y2 };
        
        const diff = subtractVectors(this.vertex[1], this.vertex[0]);
        this.dir = unitVector(diff);
        this.refDir = { x: this.dir.x, y: this.dir.y };
        this.length = vectorMagnitude(diff);
        this.width = w;
        
        // To'rtburchak uchlarini hisoblash
        const normal = normalVector(this.dir);
        this.vertex[2] = addVectors(this.vertex[1], multiplyVector(normal, this.width));
        this.vertex[3] = addVectors(this.vertex[2], multiplyVector(normal, -this.length));
        
        const halfLength = multiplyVector(this.dir, this.length / 2);
        const halfWidth = multiplyVector(normal, this.width / 2);
        this.pos = addVectors(addVectors(this.vertex[0], halfLength), halfWidth);
        
        this.angle = 0;
        this.rotMat = new Matrix(2, 2);
    }

    draw() {
        ctx.beginPath();
        ctx.moveTo(this.vertex[0].x, this.vertex[0].y);
        for (let i = 1; i < 4; i++) {
            ctx.lineTo(this.vertex[i].x, this.vertex[i].y);
        }
        ctx.lineTo(this.vertex[0].x, this.vertex[0].y);
        ctx.strokeStyle = "black";
        ctx.stroke();
        ctx.closePath();
    }

    // Aylantirilgan uchlarni qayta hisoblash
    getVertices() {
        this.rotMat = rotMx(this.angle);
        this.dir = this.rotMat.multiplyVec(this.refDir);
        
        const halfLength = multiplyVector(this.dir, this.length / 2);
        const negHalfLength = multiplyVector(this.dir, -this.length / 2);
        const normal = normalVector(this.dir);
        const posWidth = multiplyVector(normal, this.width / 2);
        const negWidth = multiplyVector(normal, -this.width / 2);
        
        this.vertex[0] = addVectors(addVectors(this.pos, negHalfLength), posWidth);
        this.vertex[1] = addVectors(addVectors(this.pos, negHalfLength), negWidth);
        this.vertex[2] = addVectors(addVectors(this.pos, halfLength), negWidth);
        this.vertex[3] = addVectors(addVectors(this.pos, halfLength), posWidth);
    }
}

// ============================================
// TO'P KLASSI
// ============================================
class Ball {
    constructor(x, y, r, m) {
        this.comp = [new Circle(x, y, r)];
        this.pos = { x: x, y: y };
        this.m = m;
        this.inv_m = m === 0 ? 0 : 1 / m;
        this.inertia = 0;
        this.inv_inertia = 0;
        this.elasticity = 1;
        
        this.vel = { x: 0, y: 0 };
        this.acc = { x: 0, y: 0 };
        this.acceleration = 1;
        this.angle = 0; // Aylanish burchagi
        this.angVel = 0;
        this.player = false;
        
        BODIES.push(this);
    }

    draw() {
        this.comp[0].draw();
    }

    display() {
        // Text kerak emas
    }

    // Pozitsiyani yangilash
    reposition() {
        // Gravitatsiyani qo'shish (faqat massa 0 bo'lmasa)
        if (this.m !== 0) {
            this.vel = addVectors(this.vel, gravity);
        }
        
        this.acc = multiplyVector(unitVector(this.acc), this.acceleration);
        this.vel = multiplyVector(addVectors(this.vel, this.acc), 1 - friction);
        this.comp[0].pos = addVectors(this.comp[0].pos, this.vel);
        this.pos = { x: this.comp[0].pos.x, y: this.comp[0].pos.y };
        
        // Real fizik aylanish - to'p radiusiga nisbatan
        // Formula: burchak = masofa / radius
        
        // Agar to'p gorizontal harakat qilsa - X yo'nalishi asosiy
        // Agar to'p vertikal harakat qilsa - Y yo'nalishi ham hisoblanadi
        
        // X bo'yicha aylanish (asosiy)
        const rotationX = this.vel.x / this.comp[0].r;
        
        // Umumiy aylanish
        this.angle += rotationX; // O'ngga = soat yo'nalishi, chapga = teskari
        this.angVel = rotationX;
        this.comp[0].angle = this.angle;
    }

    // Klaviatura bilan boshqarish
    keyControl() {
        this.acc.x = LEFT ? -this.acceleration : (RIGHT ? this.acceleration : 0);
        this.acc.y = UP ? -this.acceleration : (DOWN ? this.acceleration : 0);
    }
}

// ============================================
// QUTI KLASSI
// ============================================
class Box {
    constructor(x1, y1, x2, y2, w, m) {
        this.comp = [new Rectangle(x1, y1, x2, y2, w)];
        this.pos = { x: this.comp[0].pos.x, y: this.comp[0].pos.y };
        this.m = m;
        this.inv_m = m === 0 ? 0 : 1 / m;
        this.inertia = this.m * (this.comp[0].width ** 2 + this.comp[0].length ** 2) / 12;
        this.inv_inertia = this.inertia === 0 ? 0 : 1 / this.inertia;
        this.elasticity = 1;
        
        this.vel = { x: 0, y: 0 };
        this.acc = { x: 0, y: 0 };
        this.acceleration = 1;
        this.angVel = 0;
        this.angle = 0;
        this.player = false;
        
        BODIES.push(this);
    }

    draw() {
        this.comp[0].draw();
    }

    display() {
        // Text kerak emas
    }

    // Pozitsiyani yangilash
    reposition() {
        // Gravitatsiyani qo'shish (faqat massa 0 bo'lmasa)
        if (this.m !== 0) {
            this.vel = addVectors(this.vel, gravity);
        }
        
        this.acc = multiplyVector(unitVector(this.acc), this.acceleration);
        this.vel = multiplyVector(addVectors(this.vel, this.acc), 1 - friction);
        this.pos = addVectors(this.pos, this.vel);
        
        // Angular damping - aylanishni sekinlashtirish
        this.angVel *= 0.98;
        
        // Agar deyarli to'xtagan bo'lsa - to'liq to'xtatish
        // const speed = Math.sqrt(this.vel.x ** 2 + this.vel.y ** 2);
        // if (speed < 0.5 && Math.abs(this.angVel) < 0.05) {
        //     this.angVel *= 0.85; // Tez to'xtaydi
        // }
        
        // // Agar juda kichik aylanish bo'lsa - 0 ga teng qilish
        // if (Math.abs(this.angVel) < 0.03) {
        //     this.angVel = 0;
        // }
        
        this.angle += this.angVel;
        this.comp[0].angle = this.angle;
        this.comp[0].pos = { x: this.pos.x, y: this.pos.y };
        this.comp[0].getVertices();
    }

    // Klaviatura bilan boshqarish
    keyControl() {
        this.acc.x = LEFT ? -this.acceleration : (RIGHT ? this.acceleration : 0);
        this.acc.y = UP ? -this.acceleration : (DOWN ? this.acceleration : 0);
    }
}

// ============================================
// TO'QNASHUV MA'LUMOTLARI KLASSI
// ============================================
class CollData {
    constructor(o1, o2, axis, pen, vertex) {
        this.o1 = o1;
        this.o2 = o2;
        this.axis = axis;
        this.pen = pen;
        this.vertex = vertex;
    }

    // Penetratsiyani hal qilish
    penRes() {
        const penVec = multiplyVector(this.axis, this.pen / (this.o1.inv_m + this.o2.inv_m));
        this.o1.pos = addVectors(this.o1.pos, multiplyVector(penVec, this.o1.inv_m));
        this.o2.pos = addVectors(this.o2.pos, multiplyVector(penVec, -this.o2.inv_m));
        
        if (this.o1.comp[0] instanceof Circle) {
            this.o1.comp[0].pos = { x: this.o1.pos.x, y: this.o1.pos.y };
        } else {
            this.o1.comp[0].pos = { x: this.o1.pos.x, y: this.o1.pos.y };
            this.o1.comp[0].getVertices();
        }
        
        if (this.o2.comp[0] instanceof Circle) {
            this.o2.comp[0].pos = { x: this.o2.pos.x, y: this.o2.pos.y };
        } else {
            this.o2.comp[0].pos = { x: this.o2.pos.x, y: this.o2.pos.y };
            this.o2.comp[0].getVertices();
        }
    }

    // To'qnashuvni hal qilish
    collRes() {
        const collArm1 = subtractVectors(this.vertex, this.o1.comp[0].pos);
        const rotVel1 = { 
            x: -this.o1.angVel * collArm1.y, 
            y: this.o1.angVel * collArm1.x 
        };
        const closVel1 = addVectors(this.o1.vel, rotVel1);

        const collArm2 = subtractVectors(this.vertex, this.o2.comp[0].pos);
        const rotVel2 = { 
            x: -this.o2.angVel * collArm2.y, 
            y: this.o2.angVel * collArm2.x 
        };
        const closVel2 = addVectors(this.o2.vel, rotVel2);

        let impAug1 = crossProduct(collArm1, this.axis);
        impAug1 = impAug1 * this.o1.inv_inertia * impAug1;
        let impAug2 = crossProduct(collArm2, this.axis);
        impAug2 = impAug2 * this.o2.inv_inertia * impAug2;

        const relVel = subtractVectors(closVel1, closVel2);
        const sepVel = dotProduct(relVel, this.axis);
        const new_sepVel = -sepVel * Math.min(this.o1.elasticity, this.o2.elasticity);
        
        const impulse = (new_sepVel - sepVel) / (this.o1.inv_m + this.o2.inv_m + impAug1 + impAug2);
        const impulseVec = multiplyVector(this.axis, impulse);

        this.o1.vel = addVectors(this.o1.vel, multiplyVector(impulseVec, this.o1.inv_m));
        this.o2.vel = addVectors(this.o2.vel, multiplyVector(impulseVec, -this.o2.inv_m));
        
        // Angular impulse ni hisoblash
        let angImpulse1 = this.o1.inv_inertia * crossProduct(collArm1, impulseVec);
        let angImpulse2 = this.o2.inv_inertia * crossProduct(collArm2, impulseVec);
        
        // Angular impulse ni cheklash - juda katta bo'lmasligi uchun
        const maxAngImpulse = 0.1;
        if (Math.abs(angImpulse1) > maxAngImpulse) {
            angImpulse1 = Math.sign(angImpulse1) * maxAngImpulse;
        }
        if (Math.abs(angImpulse2) > maxAngImpulse) {
            angImpulse2 = Math.sign(angImpulse2) * maxAngImpulse;
        }
        
        this.o1.angVel += angImpulse1;
        this.o2.angVel -= angImpulse2;
    }
}

// ============================================
// YORDAMCHI FUNKSIYALAR
// ============================================

// Aylanish matritsasi
function rotMx(angle) {
    const m = new Matrix(2, 2);
    m.data[0][0] = Math.cos(angle);
    m.data[0][1] = -Math.sin(angle);
    m.data[1][0] = Math.sin(angle);
    m.data[1][1] = Math.cos(angle);
    return m;
}

// Tasodifiy son
function randInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Foydalanuvchi kirishi
function userInput() {
    canvas.addEventListener('keydown', (event) => {
        if (event.keyCode === 37) LEFT = true;
        if (event.keyCode === 38) UP = true;
        if (event.keyCode === 39) RIGHT = true;
        if (event.keyCode === 40) DOWN = true;
    });
    canvas.addEventListener('keyup', (event) => {
        if (event.keyCode === 37) LEFT = false;
        if (event.keyCode === 38) UP = false;
        if (event.keyCode === 39) RIGHT = false;
        if (event.keyCode === 40) DOWN = false;
    });
}

// SAT algoritmi - to'qnashuvni tekshirish
function sat(o1, o2) {
    let minOverlap = null;
    let smallestAxis;
    let vertexObj;
    const axes = findAxes(o1, o2);
    const firstShapeAxes = getShapeAxes(o1);

    for (let i = 0; i < axes.length; i++) {
        const proj1 = projShapeOntoAxis(axes[i], o1);
        const proj2 = projShapeOntoAxis(axes[i], o2);
        let overlap = Math.min(proj1.max, proj2.max) - Math.max(proj1.min, proj2.min);
        
        if (overlap < 0) return false;

        if ((proj1.max > proj2.max && proj1.min < proj2.min) ||
            (proj1.max < proj2.max && proj1.min > proj2.min)) {
            const mins = Math.abs(proj1.min - proj2.min);
            const maxs = Math.abs(proj1.max - proj2.max);
            if (mins < maxs) {
                overlap += mins;
            } else {
                overlap += maxs;
                axes[i] = multiplyVector(axes[i], -1);
            }
        }

        if (overlap < minOverlap || minOverlap === null) {
            minOverlap = overlap;
            smallestAxis = { x: axes[i].x, y: axes[i].y };
            if (i < firstShapeAxes) {
                vertexObj = o2;
                if (proj1.max > proj2.max) smallestAxis = multiplyVector(axes[i], -1);
            } else {
                vertexObj = o1;
                if (proj1.max < proj2.max) smallestAxis = multiplyVector(axes[i], -1);
            }
        }
    }

    const contactVertex = projShapeOntoAxis(smallestAxis, vertexObj).collVertex;
    if (vertexObj === o2) smallestAxis = multiplyVector(smallestAxis, -1);

    return { pen: minOverlap, axis: smallestAxis, vertex: contactVertex };
}

// Shaklni o'qqa proyeksiya qilish
function projShapeOntoAxis(axis, obj) {
    setBallVerticesAlongAxis(obj, axis);
    let min = dotProduct(axis, obj.vertex[0]);
    let max = min;
    let collVertex = { x: obj.vertex[0].x, y: obj.vertex[0].y };
    
    for (let i = 0; i < obj.vertex.length; i++) {
        const p = dotProduct(axis, obj.vertex[i]);
        if (p < min) { 
            min = p; 
            collVertex = { x: obj.vertex[i].x, y: obj.vertex[i].y }; 
        }
        if (p > max) max = p;
    }
    return { min: min, max: max, collVertex: collVertex };
}

// Proyeksiya o'qlarini topish
function findAxes(o1, o2) {
    const axes = [];
    if (o1 instanceof Circle && o2 instanceof Circle) {
        axes.push(unitVector(subtractVectors(o2.pos, o1.pos)));
    } else if (o1 instanceof Circle) {
        axes.push(unitVector(subtractVectors(closestVertexToPoint(o2, o1.pos), o1.pos)));
        axes.push(normalVector(o2.dir));
        if (o2 instanceof Rectangle) axes.push({ x: o2.dir.x, y: o2.dir.y });
    } else if (o2 instanceof Circle) {
        axes.push(normalVector(o1.dir));
        if (o1 instanceof Rectangle) axes.push({ x: o1.dir.x, y: o1.dir.y });
        axes.push(unitVector(subtractVectors(closestVertexToPoint(o1, o2.pos), o2.pos)));
    } else {
        axes.push(normalVector(o1.dir));
        if (o1 instanceof Rectangle) axes.push({ x: o1.dir.x, y: o1.dir.y });
        axes.push(normalVector(o2.dir));
        if (o2 instanceof Rectangle) axes.push({ x: o2.dir.x, y: o2.dir.y });
    }
    return axes;
}

// Eng yaqin uchni topish
function closestVertexToPoint(obj, p) {
    let closestVertex = { x: obj.vertex[0].x, y: obj.vertex[0].y };
    let minDist = vectorMagnitude(subtractVectors(p, obj.vertex[0]));
    
    for (let i = 1; i < obj.vertex.length; i++) {
        const dist = vectorMagnitude(subtractVectors(p, obj.vertex[i]));
        if (dist < minDist) {
            closestVertex = { x: obj.vertex[i].x, y: obj.vertex[i].y };
            minDist = dist;
        }
    }
    return closestVertex;
}

// Shakl o'qlari sonini qaytarish
function getShapeAxes(obj) {
    if (obj instanceof Circle || obj instanceof Line) return 1;
    if (obj instanceof Rectangle) return 2;
}

// To'p uchlarini o'q bo'yicha o'rnatish
function setBallVerticesAlongAxis(obj, axis) {
    if (obj instanceof Circle) {
        const unit = unitVector(axis);
        obj.vertex[0] = addVectors(obj.pos, multiplyVector(unit, -obj.r));
        obj.vertex[1] = addVectors(obj.pos, multiplyVector(unit, obj.r));
    }
}

// ============================================
// ASOSIY TSIKL
// ============================================
function mainLoop() {
    ctx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
    userInput();
    updateGravity(); // Gravitatsiyani tekshirish
    COLLISIONS.length = 0;
    
    // Barcha jismlarni yangilash
    BODIES.forEach((b) => {
        b.draw();
        b.display();
        if (b.player) b.keyControl();
        b.reposition();
    });
    
    // To'qnashuvlarni tekshirish
    BODIES.forEach((b, index) => {
        for (let i = index + 1; i < BODIES.length; i++) {
            let bestSat = { pen: null, axis: null, vertex: null };
            
            for (let c1 = 0; c1 < b.comp.length; c1++) {
                for (let c2 = 0; c2 < BODIES[i].comp.length; c2++) {
                    const result = sat(b.comp[c1], BODIES[i].comp[c2]);
                    if (result && result.pen > bestSat.pen) {
                        bestSat = result;
                    }
                }
            }
            
            if (bestSat.pen !== null) {
                COLLISIONS.push(new CollData(b, BODIES[i], bestSat.axis, bestSat.pen, bestSat.vertex));
            }
        }
    });

    // To'qnashuvlarni hal qilish
    COLLISIONS.forEach((c) => {
        c.penRes();
        c.collRes();
    });

    requestAnimationFrame(mainLoop);
}

// ============================================
// BOSHLANG'ICH O'RNATISH
// ============================================
new Box(canvas.width - 35, 10, canvas.width - 35, 30, 570, 0);
new Box(canvas.width - 35, canvas.height - 30, canvas.width - 35, canvas.height - 10, 570, 0);

new Box(30, 10, 30, canvas.height - 10, 20, 0);
new Box(canvas.width - 10, 10, canvas.width - 10, canvas.height - 10, 20, 0);


// Tasodifiy ob'ektlar yaratish
for (let i = 0; i < 10; i++) {
    const x0 = randInt(100, canvas.clientWidth - 100);
    const y0 = randInt(100, canvas.clientHeight - 100);
    const r = randInt(10, 30);
    const m = randInt(1, 10);
    
    if (i % 3 === 1) {
        const x1 = x0 + randInt(-50, 50);
        const y1 = y0 + randInt(-50, 50);
        new Box(x0, y0, x1, y1, r, 100);
    }
    if (i % 3 === 2) {
        new Ball(x0, y0, r, m);
    }
}

// O'yinchi to'pi
const playerBall = new Ball(320, 240, 10, 5);
playerBall.player = true;

// Animatsiyani boshlash
requestAnimationFrame(mainLoop);
