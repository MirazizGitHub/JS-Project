
class OdometerClass {
    constructor(obj) {
        this.el = {
            min: '0',
            value: '0',
            leng_val: obj.value.length
        }
        this.srValue = null;
        this.fill = null;
        this.digitCols = null;
        this.lastDigits = "";
        this.rollDuration = 0;
        this.trans09 = false;
        this.obj = obj;
        this.element = obj.element;
        let odometer = this;

        if (this.el) {
            this.buildSlider();
            this.el.value = String(obj.value);
            this.changeValue();
            obj.loaded({ numb_befor: this.el.value, reload: function(numb_value) {
                odometer.el.value = String(numb_value);
                odometer.changeValue();
            } });
        }
    }

    buildSlider() {

        let counter = document.createElement("span");
        counter.className = "odometer_animate_count";
        this.element.appendChild(counter);

        let srValue = document.createElement("span");
        srValue.className = "odometer_animate_count-sr";
        srValue.textContent = "0";
        counter.appendChild(srValue);

        for (let D = 0; D < this.el.leng_val; D++) {
            let digitCol = document.createElement("span");
            digitCol.className = "odometer_animate_count-column";
            counter.appendChild(digitCol);

            for (let d = 0; d <= 11; d++) {
                let digit = document.createElement("span");
                digit.className = "odometer_animate_count-digit";

                if (d > 0)
                    digit.textContent = d == 11 ? 0 : `${d - 1}`;

                digitCol.appendChild(digit);
            }
        }

        this.srValue = srValue;
        this.digitCols = counter.querySelectorAll(".odometer_animate_count-column");
        this.lastDigits = this.el.value;

        while (this.lastDigits.length < this.digitCols.length)
            this.lastDigits = " " + this.lastDigits;

        this.changeValue();

        let colCS = window.getComputedStyle(this.digitCols[0]),
            transDur = colCS.getPropertyValue("transition-duration"),
            msLabelPos = transDur.indexOf("ms"),
            sLabelPos = transDur.indexOf("s");

        if (msLabelPos > -1)
            this.rollDuration = transDur.substring(0, msLabelPos);
        else if (sLabelPos > -1)
            this.rollDuration = transDur.substring(0, sLabelPos) * 1e3;
    }
    changeValue() {
         if (+this.el.value < this.el.min)
            this.el.value = this.el.min;

        if (this.srValue)
            this.srValue.textContent = this.el.value;

        if (this.digitCols) {
            let rangeVal = this.el.value;

            while (rangeVal.length < this.digitCols.length)
                rangeVal = " " + rangeVal;

            let diffsFromLast = [];
            if (this.lastDigits) {
                rangeVal.split("").forEach((r, i) => {
                    let diff = +r - this.lastDigits[i];
                    diffsFromLast.push(diff);
                });
            }

            this.trans09 = false;
            rangeVal.split("").forEach((e, i) => {
                let digitH = 1.5,
                    over9 = false,
                    under0 = false,
                    transY = e === " " ? 0 : (-digitH * (+e + 1)),
                    col = this.digitCols[i];

                if (e == 0 && diffsFromLast[i] == -9) {
                    transY = -digitH * 11;
                    over9 = true;

                } else if (e == 9 && diffsFromLast[i] == 9) {
                    transY = 0;
                    under0 = true;
                }

                col.style.transform = `translateY(${transY}em)`;
                col.firstChild.textContent = "";

                if (over9 || under0) {
                    this.trans09 = true;
                    if (under0)
                        col.firstChild.textContent = e;

                    setTimeout(() => {
                        if (this.trans09) {
                            let pauseClass = "odometer_animate_count-column--pause",
                                transYAgain = -digitH * (over9 ? 1 : 10);

                            col.classList.add(pauseClass);
                            col.style.transform = `translateY(${transYAgain}em)`;
                            void col.offsetHeight;
                            col.classList.remove(pauseClass);

                            if (under0)
                                col.firstChild.textContent = "";
                        }

                    }, this.rollDuration);
                }
            });
            this.lastDigits = rangeVal;
        }
    }
}

new OdometerClass({
    value: '1000',
    element: document.querySelector('.title'),
    loaded: (data) => {
        setInterval(function() {
            let numb = Math.floor(Math.random() * 9000);
            data.reload(numb);
        }, 2000);
    }
});