let canvas = document.getElementById('cv');
let ctx = canvas.getContext('2d');

canvas.width = window.innerWidth - 10;
canvas.height = window.innerHeight - 10;

let mouse = {
    x: 200, y: 200,
}

canvas.addEventListener('mousemove', (event) => {
    mouse.x = event.clientX;
    mouse.y = event.clientY;
});

class Line {
    constructor() {
        this.l1x = mouse.x;
        this.l1y = mouse.y;
        this.l1r = 60;
        this.l1c = '#fff';
        this.l1w = 2;

        this.l2x = canvas.width / 2;
        this.l2y = canvas.height / 2;
        this.l2r = 90;
        this.l2c = '#fff';
        this.l1w = 2;
    }
    update() {
        this.l1x = mouse.x;
        this.l1y = mouse.y;

        let dx = this.l1x - this.l2x;
        let dy = this.l1y - this.l2y;
        let distance = Math.sqrt(dx * dx + dy * dy);

        ctx.beginPath();
        ctx.font = "30px Calibri";
        ctx.fillStyle = '#fff';
        ctx.fillText('Distance: ' + distance.toFixed(0), 700, 700);
        ctx.closePath();
    }
    Line1() {
        ctx.beginPath();
        ctx.lineWidth = this.l1w;
        ctx.strokeStyle = this.l1c;
        ctx.arc(this.l1x, this.l1y, this.l1r, 0, Math.PI * 2);

        //
        ctx.moveTo(this.l1x, 0);
        ctx.lineTo(this.l1x, this.l1y);
        ctx.lineTo(0, this.l1y);
        //
        ctx.font = "30px Calibri";
        ctx.fillStyle = this.l1c;
        ctx.fillText("x: " + this.l1x.toFixed(0), this.l1x + 10, (this.l1y / 2));
        ctx.fillText("y: " + this.l1y.toFixed(0), (this.l1x / 2), (this.l1y - 10));

        ctx.arc(this.l1x, this.l1y, 2, 0, Math.PI * 2);
        ctx.stroke();
        ctx.closePath();
    }
    Line2() {
        ctx.beginPath();
        ctx.lineWidth = this.l2w;
        ctx.strokeStyle = this.l2c;
        ctx.arc(this.l2x, this.l2y, this.l2r, 0, Math.PI * 2);

        //
        ctx.moveTo(this.l2x, 0);
        ctx.lineTo(this.l2x, this.l2y);
        ctx.lineTo(0, this.l2y);
        //
        ctx.font = "30px Calibri";
        ctx.fillStyle = this.l2c;
        ctx.fillText("x: " + this.l2x.toFixed(0), this.l2x + 10, (this.l2y / 2));
        ctx.fillText("y: " + this.l2y.toFixed(0), (this.l2x / 2), (this.l2y - 10));

        ctx.arc(this.l2x, this.l2y, 2, 0, Math.PI * 2);
        ctx.stroke();
        ctx.closePath();
    }
}


let line = new Line();

const init = () => {
    line.update();
    line.Line1();
    line.Line2();
}


const loop = () => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    /*  */
    init();
    /*  */

    requestAnimationFrame(loop);
}
loop();