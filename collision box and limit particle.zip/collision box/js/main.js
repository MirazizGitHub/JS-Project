
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

canvas.width = 600;
canvas.height = 400;

let arrowLeft = false, arrowRight = false, arrowTop = false, arrowBottom = false, space = false;

let objects = [];
let particles = [];
let jackpot_boolean = false;
let jackpot_numb = false;

objects = [
	new Rectangle(80, 300, 100, 10, 'blue'),
	new Rectangle(300, 280, 10, 100, 'purple'),
	new Rectangle(400, 130, 100, 10, 'green')
];



controller();

function animate() {
	ctx.clearRect(0, 0, canvas.width, canvas.height);
	// ctx.fillStyle = 'rgba(20, 20, 20, 0.5)';
	// ctx.fillRect(0, 0, canvas.width, canvas.height);

	/*  */
	init();
	/*  */

	requestAnimationFrame(animate);
}


function overlapsWith(player, obj) {
	return (
		player.x <= (obj.x + obj.width) &&
		(player.x + player.width) >= obj.x  &&
		(player.y + player.height) >= obj.y &&
		player.y <= (obj.y + obj.height)
	);
}

animate();


