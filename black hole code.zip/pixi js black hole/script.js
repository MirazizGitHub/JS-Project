// PixiJS ilovasini yaratish
const app = new PIXI.Application({
    width: window.innerWidth,
    height: window.innerHeight,
    resizeTo: window,
    backgroundColor: 0x050505 // To'q kulrang fon (rasm yuklanmasa ko'rinadi)
});

// Canvasni sahifaga qo'shish
document.body.appendChild(app.view);
app.view.style.position = 'absolute';
app.view.style.top = '0';
app.view.style.left = '0';
app.view.style.zIndex = '0';

const pos1 = { x: app.screen.width * 0.4, y: app.screen.height * 0.5 };
const pos2 = { x: app.screen.width * 0.6, y: app.screen.height * 0.5 };

// Filtrlar
const filter1 = new PIXI.filters.BulgePinchFilter({
    center: [pos1.x, pos1.y], 
    radius: 150, 
    strength: 2 // -1 = qavariq (bulge), yorug'likni chetga itaradi
});

const filter2 = new PIXI.filters.BulgePinchFilter({
    center: [pos2.x, pos2.y], 
    radius: 150, 
    strength: 2
});

// Orqa fon rasmi yuklanishini kutamiz
PIXI.Assets.load('bg.jpg').then((texture) => {
    const bg = new PIXI.Sprite(texture);
    app.stage.addChild(bg);
    
    // Filtrlarni fon rasmiga biriktiramiz
    bg.filters = [filter1, filter2];

    // Qora tuynuklarning mutlaq qora qismini (Event horizon) chizamiz
    const bh1 = new PIXI.Graphics();
    bh1.lineStyle(3, 0xffffff, 0.4); // Oq hoshiya (aniq ko'rinishi uchun)
    bh1.beginFill(0x000000);
    bh1.drawCircle(0, 0, 45); 
    bh1.endFill();
    app.stage.addChild(bh1);

    const bh2 = new PIXI.Graphics();
    bh2.lineStyle(3, 0xffffff, 0.4);
    bh2.beginFill(0x000000);
    bh2.drawCircle(0, 0, 35);
    bh2.endFill();
    app.stage.addChild(bh2);

    let dragging1 = false;
    let dragging2 = false;

    app.view.addEventListener('mousedown', (e) => {
        const dist1 = Math.hypot(e.clientX - pos1.x, e.clientY - pos1.y);
        const dist2 = Math.hypot(e.clientX - pos2.x, e.clientY - pos2.y);
        
        if (e.button === 0) { 
            if (dist1 < dist2) dragging1 = true;
            else dragging2 = true;
        } else if (e.button === 2) { 
            if (dist2 < dist1) dragging2 = true;
            else dragging1 = true;
        }
    });

    window.addEventListener('mousemove', (e) => {
        if (dragging1) {
            pos1.x = e.clientX;
            pos1.y = e.clientY;
        }
        if (dragging2) {
            pos2.x = e.clientX;
            pos2.y = e.clientY;
        }
    });

    window.addEventListener('mouseup', () => {
        dragging1 = false;
        dragging2 = false;
    });

    app.view.addEventListener('contextmenu', e => e.preventDefault());

    // Har bir kadrda chizish va pozitsiyalarni yangilash
    app.ticker.add(() => {
        // Rasm o'lchamini ekranga moslash
        bg.width = app.screen.width;
        bg.height = app.screen.height;

        // BulgePinchFilter ba'zan absolyut koordinatalarni oladi. Shuning uchun ekranga nisbatan foizini emas o'zini beramiz
        // Agar xato ishlasa `pos.x / app.screen.width` ishlatamiz. Hozir normallashtirilgan usulda sinaymiz:
        filter1.center = [pos1.x / app.screen.width, pos1.y / app.screen.height];
        filter2.center = [pos2.x / app.screen.width, pos2.y / app.screen.height];
        
        bh1.x = pos1.x;
        bh1.y = pos1.y;
        bh2.x = pos2.x;
        bh2.y = pos2.y;
    });
}).catch(err => {
    console.error("Fon rasmi yuklanmadi:", err);
});
