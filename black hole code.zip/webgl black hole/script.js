const canvas = document.getElementById('canvas');
const gl = canvas.getContext('webgl');

const vertexShaderSource = `
    attribute vec2 position;
    varying vec2 vUv;
    void main() {
        vUv = position * 0.5 + 0.5;
        gl_Position = vec4(position, 0.0, 1.0);
    }
`;

const fragmentShaderSource = `
    precision highp float;
    uniform sampler2D u_image;
    uniform vec2 u_resolution;
    uniform vec2 u_bh1;
    uniform vec2 u_bh2;
    uniform float u_mass1;
    uniform float u_mass2;

    varying vec2 vUv;

    void main() {
        vec2 uv = gl_FragCoord.xy / u_resolution.xy;
        vec2 pos = gl_FragCoord.xy;
        
        // Correcting Y axis for WebGL
        vec2 bh1_pos = vec2(u_bh1.x, u_resolution.y - u_bh1.y);
        vec2 bh2_pos = vec2(u_bh2.x, u_resolution.y - u_bh2.y);
        
        vec2 d1 = pos - bh1_pos;
        float r1 = length(d1);
        
        vec2 d2 = pos - bh2_pos;
        float r2 = length(d2);
        
        // Event horizon (completely black)
        float eventHorizon1 = u_mass1 * 0.2;
        float eventHorizon2 = u_mass2 * 0.2;
        
        if (r1 < eventHorizon1 || r2 < eventHorizon2) {
            gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
            return;
        }
        
        // Deflection due to gravitational lensing
        // shift is proportional to mass / r^2 in direction of the black hole
        vec2 shift1 = d1 * (u_mass1 * 80.0 / (r1 * r1));
        vec2 shift2 = d2 * (u_mass2 * 80.0 / (r2 * r2));
        
        vec2 finalUv = uv - (shift1 + shift2) / u_resolution.xy;
        
        // Sample background image
        vec4 color = texture2D(u_image, vec2(finalUv.x, 1.0 - finalUv.y));
        
        // Slight darkening near the event horizon for realism
        float glow1 = smoothstep(eventHorizon1, eventHorizon1 + u_mass1 * 0.5, r1);
        float glow2 = smoothstep(eventHorizon2, eventHorizon2 + u_mass2 * 0.5, r2);
        
        gl_FragColor = color * min(glow1, glow2);
    }
`;

function createShader(gl, type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        console.error(gl.getShaderInfoLog(shader));
        gl.deleteShader(shader);
        return null;
    }
    return shader;
}

const vertexShader = createShader(gl, gl.VERTEX_SHADER, vertexShaderSource);
const fragmentShader = createShader(gl, gl.FRAGMENT_SHADER, fragmentShaderSource);

const program = gl.createProgram();
gl.attachShader(program, vertexShader);
gl.attachShader(program, fragmentShader);
gl.linkProgram(program);
gl.useProgram(program);

const positionAttributeLocation = gl.getAttribLocation(program, "position");
const positionBuffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
const positions = [
    -1, -1,
     1, -1,
    -1,  1,
    -1,  1,
     1, -1,
     1,  1,
];
gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);

gl.enableVertexAttribArray(positionAttributeLocation);
gl.vertexAttribPointer(positionAttributeLocation, 2, gl.FLOAT, false, 0, 0);

const resolutionLocation = gl.getUniformLocation(program, "u_resolution");
const bh1Location = gl.getUniformLocation(program, "u_bh1");
const bh2Location = gl.getUniformLocation(program, "u_bh2");
const mass1Location = gl.getUniformLocation(program, "u_mass1");
const mass2Location = gl.getUniformLocation(program, "u_mass2");
const imageLocation = gl.getUniformLocation(program, "u_image");

let bh1 = { x: window.innerWidth * 0.4, y: window.innerHeight * 0.5, mass: 180 };
let bh2 = { x: window.innerWidth * 0.6, y: window.innerHeight * 0.5, mass: 150 };

let dragging1 = false;
let dragging2 = false;

// Handle mouse events to move the black holes
canvas.addEventListener('mousedown', (e) => {
    const dist1 = Math.hypot(e.clientX - bh1.x, e.clientY - bh1.y);
    const dist2 = Math.hypot(e.clientX - bh2.x, e.clientY - bh2.y);
    
    // Left click moves the closest one, or specific buttons
    if (e.button === 0) { // Left click
        if (dist1 < dist2) dragging1 = true;
        else dragging2 = true;
    } else if (e.button === 2) { // Right click
        if (dist2 < dist1) dragging2 = true;
        else dragging1 = true;
    }
});

window.addEventListener('mousemove', (e) => {
    if (dragging1) {
        bh1.x = e.clientX;
        bh1.y = e.clientY;
    }
    if (dragging2) {
        bh2.x = e.clientX;
        bh2.y = e.clientY;
    }
});

window.addEventListener('mouseup', () => {
    dragging1 = false;
    dragging2 = false;
});

// Prevent context menu on right click
canvas.addEventListener('contextmenu', e => e.preventDefault());

// Handle touch events for mobile/touch screens
canvas.addEventListener('touchstart', (e) => {
    e.preventDefault();
    for (let i = 0; i < e.touches.length; i++) {
        const touch = e.touches[i];
        const dist1 = Math.hypot(touch.clientX - bh1.x, touch.clientY - bh1.y);
        const dist2 = Math.hypot(touch.clientX - bh2.x, touch.clientY - bh2.y);
        
        if (dist1 < dist2 && !dragging2) {
            dragging1 = true;
            bh1.x = touch.clientX;
            bh1.y = touch.clientY;
        } else if (!dragging1) {
            dragging2 = true;
            bh2.x = touch.clientX;
            bh2.y = touch.clientY;
        }
    }
}, {passive: false});

canvas.addEventListener('touchmove', (e) => {
    e.preventDefault();
    for (let i = 0; i < e.touches.length; i++) {
        const touch = e.touches[i];
        // simple heuristic: just assign first touch to 1, second to 2 if both dragging
        if (i === 0 && dragging1) {
            bh1.x = touch.clientX;
            bh1.y = touch.clientY;
        } else if (i === 0 && dragging2) {
            bh2.x = touch.clientX;
            bh2.y = touch.clientY;
        } else if (i === 1 && (dragging1 || dragging2)) {
            if (dragging1) {
                bh2.x = touch.clientX;
                bh2.y = touch.clientY;
            } else {
                bh1.x = touch.clientX;
                bh1.y = touch.clientY;
            }
        }
    }
}, {passive: false});

canvas.addEventListener('touchend', () => {
    dragging1 = false;
    dragging2 = false;
});

// Load background image and start render loop
const image = new Image();
image.src = 'bg1.jpg';
image.onload = () => {
    const texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
    
    // For images that are not power of 2
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    
    function render() {
        // Resize canvas if window size changes
        if (canvas.width !== window.innerWidth || canvas.height !== window.innerHeight) {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            gl.viewport(0, 0, canvas.width, canvas.height);
        }
        
        gl.uniform2f(resolutionLocation, canvas.width, canvas.height);
        gl.uniform2f(bh1Location, bh1.x, bh1.y);
        gl.uniform2f(bh2Location, bh2.x, bh2.y);
        gl.uniform1f(mass1Location, bh1.mass);
        gl.uniform1f(mass2Location, bh2.mass);
        
        gl.drawArrays(gl.TRIANGLES, 0, 6);
        requestAnimationFrame(render);
    }
    
    // Start animation loop
    render();
};
