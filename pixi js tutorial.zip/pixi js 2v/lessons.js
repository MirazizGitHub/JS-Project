// Professional PixiJS v2 Darslari Ma'lumotlar Bazasi
const LESSONS = [
  {
    id: 1,
    title: "1-dars: Kirish va Dars konsepsiyasi",
    description: "Ilg'or bosqichda PixiJS-ni qanday o'rganamiz, darslar maqsadi va dasturiy optimallashtirish konsepsiyalari.",
    content: `
<h3>Professional PixiJS v2 Kursiga Xush Kelibsiz!</h3>
<p>Ushbu kurs oddiy 2D elementlarni chizishdan tashqariga chiqib, professional darajada 2D o'yinlar va interaktiv dasturlar yaratishni o'rgatadi. Biz bu erda PixiJS-ning eng chuqur, eng muhim dasturlash uslublarini va o'yin mexanikasini optimal boshqarishni ko'rib chiqamiz.</p>
<p><strong>Ushbu kursning asosiy mavzulari:</strong></p>
<ul>
    <li>JavaScript-ning **Massivlari (Arrays)** va **Obyektlari (Objects)** orqali yuzlab grafik elementlarni samarali boshqarish.</li>
    <li>Elementlarni dinamik yaratish va **aniq tanlangan elementni o'chirish** logikasi (GPU va tezkor xotirani butunlay tozalash).</li>
    <li>**Bullet Pooling (O'qlar Puli)**: O'yinlarda eng ko'p ishlatiladigan va kadrlar soni (FPS) qotib qolishini oldini oluvchi eng asosiy optimallashtirish turi.</li>
    <li>Kadrma-kadr (frame-by-frame) hamda kod orqali dasturiy **animatsiyalar** yaratish.</li>
    <li>**Xotira tahlili (Memory Leaks)**: Brauzer xotirasida o'chirilmagan massiv elementlari tufayli o'yin qotishini aniqlash va tuzatish.</li>
</ul>
<h3>Kutubxonani HTML-ga ulash</h3>
<p>Biz barcha kodlarni to'g'ridan-to'g'ri HTML faylida ishlatamiz. Hech qanday qo'shimcha o'rnatishlar shart emas. PixiJS v8 CDN tegi:</p>
<pre><code class="language-html">&lt;script src="https://pixijs.download/v8.2.6/pixi.min.js"&gt;&lt;/script&gt;</code></pre>
    `,
    code: `// PixiJS professional darslarining boshlanishi
console.log("Professional PixiJS v2 platformasi ishga tushdi.");`,
    mockupType: "intro"
  },
  {
    id: 2,
    title: "2-dars: Massivlar yordamida Guruhlash",
    description: "JavaScript massivlari orqali yuzlab PixiJS obyektlarini saqlash va ularni Ticker siklida yangilash.",
    content: `
<h3>Nega Massivlar Kerak?</h3>
<p>O'yinda bitta obyektni (masalan o'yinchi kemasi) boshqarish oson. Ammo ekranda 50 ta dushman yoki 100 ta tushayotgan tangalar paydo bo'lsa, ularning har biriga alohida o'zgaruvchi ochib bo'lmaydi. Ularni bitta **Massiv (Array)** ichida saqlash va boshqarish lozim.</p>
<h3>Massivda elementlarni saqlash algoritmi:</h3>
<ol>
    <li>Bo'sh massiv yaratish: <code>const enemies = [];</code></li>
    <li>Yangi spritelarni yaratib massivga qo'shish: <code>enemies.push(sprite);</code></li>
    <li><code>app.ticker</code> ichida massivni aylanib chiqib, har bir element koordinatasini o'zgartirish.</li>
</ol>
<h3>Ticker ichida massiv bilan ishlash namunasi:</h3>
<p>Elementlarni yangilashda <code>for...of</code> yoki oddiy <code>for</code> siklidan foydalanish eng toza va tezkor yo'ldir:</p>
<pre><code class="language-javascript">const enemies = [];
// 5 ta dushman yaratib massivga qo'shamiz
for (let i = 0; i < 5; i++) {
    const enemy = new PIXI.Graphics();
    enemy.rect(-15, -15, 30, 30);
    enemy.fill(0xff3366);
    enemy.x = 100 + i * 100;
    enemy.y = 50;
    
    app.stage.addChild(enemy);
    enemies.push(enemy); // Massivga saqlaymiz
}
// Har kadrda ularni pastga harakatlantiramiz
app.ticker.add((ticker) => {
    for (const enemy of enemies) {
        enemy.y += 2 * ticker.deltaTime; // Har bir dushman pastga tushadi
        enemy.rotation += 0.02 * ticker.deltaTime; // Aylanadi
    }
});</code></pre>
    `,
    code: `// Obyektlarni massiv orqali boshqarish
const app = new PIXI.Application();
await app.init({ width: 600, height: 400, backgroundColor: 0x111 });
document.body.appendChild(app.canvas);
const stars = [];
// 50 ta yulduzchani massivga joylash
for (let i = 0; i < 50; i++) {
    const star = new PIXI.Graphics().circle(0, 0, Math.random() * 3 + 1).fill(0xffffff);
    star.x = Math.random() * 600;
    star.y = Math.random() * 400;
    
    app.stage.addChild(star);
    stars.push(star);
}
app.ticker.add((ticker) => {
    stars.forEach(star => {
        star.y += 1 * ticker.deltaTime; // Yulduzlar pastga oqadi
        if (star.y > 400) star.y = 0;   // Ekranda qayta paydo bo'lish
    });
});`,
    mockupType: "arrays"
  },
  {
    id: 3,
    title: "3-dars: O'yin Obyekti Modeli (Entities)",
    description: "Obyektlar (Objects) yordamida har bir elementning xususiyatlarini (HP, tezlik, o'q kuchi) birgalikda saqlash.",
    content: `
<h3>O'yin Obyekti Modeli (Entity Pattern)</h3>
<p>Faqatgina PixiJS Sprite obyektining o'zi bilan ishlash ba'zan noqulay. Chunki har bir dushmanning o'ziga xos xususiyatlari bo'ladi, masalan: <strong>tezligi, hayot darajasi (HP), o'q otish vaqti</strong> va boshqalar. Buni hal qilish uchun biz har bir dushmanni oddiy **JavaScript Obyekti** ko'rinishida tasvirlaymiz:</p>
<pre><code class="language-javascript">// O'yin obyekti modeli
const enemyEntity = {
    sprite: new PIXI.Sprite(texture),
    speed: 3,
    hp: 100,
    direction: 1, // 1: o'ngga, -1: chapga
    scoreValue: 50
};</code></pre>
<h3>Obyektlarni massiv bilan boshqarish</h3>
<p>Biz o'yin obyektlarini massivga yig'amiz va har kadrda faqatgina uning ichki qiymatlari orqali sprite-ni harakatlantiramiz:</p>
<pre><code class="language-javascript">const activeEnemies = [];
function spawnEnemy() {
    const enemy = {
        sprite: new PIXI.Graphics().rect(-10, -10, 20, 20).fill(0xff0000),
        hp: 3,
        speed: Math.random() * 3 + 1
    };
    enemy.sprite.position.set(Math.random() * 600, 50);
    app.stage.addChild(enemy.sprite);
    
    activeEnemies.push(enemy);
}
app.ticker.add((ticker) => {
    for (const enemy of activeEnemies) {
        // Obyektning xususiy tezligi orqali grafik sprite-ni harakatlantirish
        enemy.sprite.y += enemy.speed * ticker.deltaTime;
        
        // Agar hp 0 bo'lsa dushman boshqacha rangga kiradi
        if (enemy.hp <= 0) {
            enemy.sprite.tint = 0x333333; 
        }
    }
});</code></pre>
<p><strong>Natijada:</strong> O'yin logikasi toza va tushunarli bo'ladi. Grafika (Sprite) va o'yin ma'lumotlari (HP, tezlik) bitta tizimga birlashadi.</p>
    `,
    code: `// Entity Pattern yordamida o'yin qahramonlarini yaratish
const app = new PIXI.Application();
await app.init({ width: 600, height: 400, backgroundColor: 0x1a0a2a });
document.body.appendChild(app.canvas);
const monsters = [];
function addMonster() {
    const graphics = new PIXI.Graphics().rect(-15, -15, 30, 30).fill(0xa55eea);
    graphics.position.set(Math.random() * 500 + 50, 100);
    app.stage.addChild(graphics);
    // Bizning Entity modelimiz
    const monster = {
        visual: graphics,
        hp: 5,
        speedX: Math.random() > 0.5 ? 2 : -2,
        speedY: Math.random() * 1 + 1
    };
    monsters.push(monster);
}
addMonster();
addMonster();
app.ticker.add((ticker) => {
    monsters.forEach(m => {
        m.visual.x += m.speedX * ticker.deltaTime;
        m.visual.y += m.speedY * ticker.deltaTime;
        
        // Devorlardan qaytish logikasi
        if (m.visual.x < 20 || m.visual.x > 580) m.speedX *= -1;
    });
});`,
    mockupType: "entities"
  },
  {
    id: 4,
    title: "4-dars: Dinamik Element Qo'shish",
    description: "Sichqoncha yoki klaviatura orqali cheksiz miqdorda dinamik o'qlar va dushmanlar yaratish tizimi.",
    content: `
<h3>Dinamik Yaratish (Instantiating)</h3>
<p>Haqiqiy o'yinda o'qlar o'yinchi probel tugmasini bosganda, dushmanlar esa vaqt o'tishi bilan o'z-o'zidan paydo bo'lishi kerak. Buning uchun biz hodisalar tinglovchisi (Event Listeners) yoki vaqt taymerlaridan (Intervals) foydalanamiz.</p>
<h3>1. Vaqt bo'yicha dinamik yaratish (Spawning)</h3>
<p>Har 1.5 soniyada yangi dushmanni sahnaga qo'shish uchun JavaScript-ning <code>setInterval</code> funksiyasidan foydalanamiz:</p>
<pre><code class="language-javascript">const enemies = [];
setInterval(() => {
    const enemy = new PIXI.Graphics();
    enemy.circle(0, 0, 15);
    enemy.fill(0xff3366);
    
    // Ekranning yuqori qismidagi tasodifiy X koordinatada paydo qilish
    enemy.x = Math.random() * (600 - 30) + 15;
    enemy.y = -20; // Ekrandan tepada
    
    app.stage.addChild(enemy);
    enemies.push(enemy); // Harakatlanishi uchun massivga solamiz
}, 1500);</code></pre>
<h3>2. Foydalanuvchi harakati bilan dinamik yaratish (O'q otish)</h3>
<p>Sichqoncha chap tugmasi sahna ustida bosilganda bosilgan nuqtada yangi shar yaratish namunasi:</p>
<pre><code class="language-javascript">const bullets = [];
// Sahnani interaktiv qilish
app.stage.eventMode = 'static';
app.stage.hitArea = app.screen; // Butun ekranni bosish uchun faollashtirish
app.stage.on('pointerdown', (event) => {
    const bullet = new PIXI.Graphics();
    bullet.rect(-3, -10, 6, 20);
    bullet.fill(0xffcc00);
    
    // Sichqoncha bosilgan joy koordinatasini olish
    bullet.x = event.global.x;
    bullet.y = event.global.y;
    
    app.stage.addChild(bullet);
    bullets.push(bullet);
});</code></pre>
    `,
    code: `// Sichqoncha bosilganda dinamik ravishda element yaratish
const app = new PIXI.Application();
await app.init({ width: 600, height: 400, backgroundColor: 0x121214 });
document.body.appendChild(app.canvas);
const shapes = [];
app.stage.eventMode = 'static';
app.stage.hitArea = app.screen;
app.stage.on('pointerdown', (e) => {
    const shape = new PIXI.Graphics().rect(-15, -15, 30, 30).fill(0x00ffcc);
    shape.x = e.global.x;
    shape.y = e.global.y;
    
    app.stage.addChild(shape);
    shapes.push(shape);
});
app.ticker.add((ticker) => {
    shapes.forEach(s => {
        s.y += 3 * ticker.deltaTime; // Shakllar tushib ketadi
        s.rotation += 0.05 * ticker.deltaTime;
    });
});`,
    mockupType: "dynamic-add"
  },
  {
    id: 5,
    title: "5-dars: Tanlangan Elementni O'chirish",
    description: "Ekrandan chiqib ketgan yoki to'qnashgan elementlarni massivdan topib o'chirish va xotiradan tozalash logikasi.",
    content: `
<h3>Xotira tozalashning o'ta muhimligi</h3>
<p>Agar siz dinamik yaratilgan elementlarni (masalan o'qlarni) ekrandan chiqib ketganda shunchaki o'chirmasangiz, brauzer orqa fonda ularni massivda saqlayveradi va koordinatasini hisoblayveradi. Bir necha daqiqadan so'ng o'yin obyektlari 10 000 taga etib, o'yin butunlay qotib qoladi. Buni **Memory Leak (Xotira sizib chiqishi)** deyiladi.</p>
<h3>O'chirishning to'g'ri algoritmi:</h3>
<p>Elementni butunlay yo'q qilish uchun ikkita qadam bajariladi:</p>
<ol>
    <li><strong>Sahnadan o'chirish va GPU xotirasini tozalash:</strong> <code>bullet.destroy({ texture: true });</code></li>
    <li><strong>JavaScript massividan o'chirish:</strong> <code>array.splice(index, 1);</code></li>
</ol>
<h3>Xavfsiz massiv aylanib chiqish va o'chirish (Tepaga qarab sikl)</h3>
<p><strong>Diqqat!</strong> Agar massivni aylanib chiqishda elementlarni o'chirsangiz, oddiy <code>0</code> dan <code>N</code> gacha bo'lgan siklda o'chirilgan element tufayli indekslar siljib ketadi va keyingi element tashlab ketiladi.
Buning oldini olish uchun massiv oxiridan boshlab boshiga qarab (teskari) sikl yoziladi:</p>
<pre><code class="language-javascript">app.ticker.add((ticker) => {
    // Teskari tartibda sikl (oxiridan boshiga qarab)
    for (let i = bullets.length - 1; i >= 0; i--) {
        const bullet = bullets[i];
        bullet.y -= 5 * ticker.deltaTime; // Yuqoriga harakat
        
        // Agar o'q ekrandan butunlay chiqib ketsa
        if (bullet.y < -50) {
            // 1. GPU xotirasini bo'shatamiz va sahnadan o'chiramiz
            bullet.destroy(); 
            
            // 2. Massivdan butunlay olib tashlaymiz
            bullets.splice(i, 1);
            
            console.log("O'q o'chirildi. Qolgan o'qlar:", bullets.length);
        }
    }
});</code></pre>
    `,
    code: `// Elementni to'g'ri o'chirish va xotirani tozalash
const app = new PIXI.Application();
await app.init({ width: 600, height: 400, backgroundColor: 0x111 });
document.body.appendChild(app.canvas);
const list = [];
// Har soniyada aylana qo'shish
setInterval(() => {
    const c = new PIXI.Graphics().circle(0, 0, 10).fill(0xff3333);
    c.x = Math.random() * 600;
    c.y = 50;
    app.stage.addChild(c);
    list.push(c);
}, 1000);
app.ticker.add((ticker) => {
    // Teskari sikl bilan tozalash
    for (let i = list.length - 1; i >= 0; i--) {
        list[i].y += 4 * ticker.deltaTime;
        
        // Agar pastga tushib ketsa
        if (list[i].y > 420) {
            list[i].destroy(); // 1. GPU tozalash
            list.splice(i, 1);  // 2. JS massivdan o'chirish
        }
    }
});`,
    mockupType: "removal"
  },
  {
    id: 6,
    title: "6-dars: Optimallashtirish: Bullet Pooling (O'qlar Puli)",
    description: "Eng muhim optimallashtirish turi: elementlarni qayta-qayta yaratib yo'q qilmasdan, oldindan tayyorlab qo'yilgan obyektdan qayta foydalanish.",
    content: `
<h3>Continuous Instantiation (Doimiy yaratish) muammosi</h3>
<p>O'tgan darsda ko'rganimizdek, yangi elementlarni yaratish (<code>new PIXI.Graphics()</code> yoki <code>new PIXI.Sprite()</code>) va keyin ularni yo'q qilish (<code>destroy()</code>) xotira boshqaruvchisi (Garbage Collector)ga katta og'irlik soladi. O'yinda har safar yangi element o'chirilganda, kadrlar soni soniyali sakrash bilan sekinlashadi (stuttering).</p>
<h3>Object Pooling (Obyektlar Puli) yechimi</h3>
<p><strong>Object Pooling</strong> uslubida biz hech narsani o'chirmaymiz va yangidan yaratmaymiz. Biz o'yin boshida cheklangan miqdordagi (masalan 30 ta) o'qlarni yaratib, ularni ko'rinmas qilib (<code>visible = false</code>) massivga solib qo'yamiz.
O'q otish kerak bo'lganda, massiv ichidan faol bo'lmagan birinchi o'qni olib, koordinatasini to'g'rilab, uni ko'rsatamiz (<code>visible = true</code>). Ekrardan chiqib ketganda esa shunchaki yana ko'rinmas qilib qo'yamiz.</p>
<h3>Pooling Kod Namunasi:</h3>
<pre><code class="language-javascript">const bulletPool = [];
const maxBullets = 20;
// O'yin boshida o'qlarni yaratib tayyorlash
for (let i = 0; i < maxBullets; i++) {
    const bullet = new PIXI.Graphics();
    bullet.rect(-2, -8, 4, 16);
    bullet.fill(0xffcc00);
    bullet.visible = false; // Boshida ko'rinmas
    
    app.stage.addChild(bullet);
    bulletPool.push({
        sprite: bullet,
        active: false // Hozircha faol emas
    });
}
// O'q otish kerak bo'lganda (Fire)
function fireBullet(x, y) {
    // Pul ichidan faol bo'lmagan o'qni qidiramiz
    const bullet = bulletPool.find(b => !b.active);
    
    if (bullet) {
        bullet.sprite.x = x;
        bullet.sprite.y = y;
        bullet.sprite.visible = true; // Ko'rsatamiz
        bullet.active = true;         // Faol qilamiz
    }
}
// Har kadrda faqat faol o'qlarni harakatlantiramiz
app.ticker.add((ticker) => {
    bulletPool.forEach(b => {
        if (b.active) {
            b.sprite.y -= 8 * ticker.deltaTime;
            
            // Ekrandan chiqib ketsa o'chirmaymiz, faol holatdan chiqaramiz!
            if (b.sprite.y < -20) {
                b.sprite.visible = false; // Yana yashiramiz
                b.active = false;         // Pulga qaytarildi
            }
        }
    });
});</code></pre>
<p><strong>Natijada:</strong> CPU va GPU xotirasida yangi obyekt umuman yaratilmaydi va o'chirilmaydi. O'yin 60 FPS tezlikda toshdek barqaror ishlaydi.</p>
    `,
    code: `// Bullet Pooling optimallashtirish namunasi
const app = new PIXI.Application();
await app.init({ width: 600, height: 400, backgroundColor: 0x111 });
document.body.appendChild(app.canvas);
// O'qlar hovuzi (Pool)
const bulletPool = [];
const POOL_SIZE = 15;
for (let i = 0; i < POOL_SIZE; i++) {
    const b = new PIXI.Graphics().rect(-2, -8, 4, 16).fill(0x00ffcc);
    b.visible = false;
    app.stage.addChild(b);
    bulletPool.push({ sprite: b, active: false });
}
// Sichqoncha bosilganda o'q otish
app.stage.eventMode = 'static';
app.stage.hitArea = app.screen;
app.stage.on('pointerdown', (e) => {
    const readyBullet = bulletPool.find(b => !b.active);
    if (readyBullet) {
        readyBullet.sprite.x = e.global.x;
        readyBullet.sprite.y = e.global.y;
        readyBullet.sprite.visible = true;
        readyBullet.active = true;
    }
});
app.ticker.add((ticker) => {
    bulletPool.forEach(b => {
        if (b.active) {
            b.sprite.y -= 6 * ticker.deltaTime;
            if (b.sprite.y < -20) {
                b.sprite.visible = false;
                b.active = false; // Pulga qaytarish
            }
        }
    });
});`,
    mockupType: "pooling"
  },
  {
    id: 7,
    title: "7-dars: Animatsiyalar: Kadrma-kadr (AnimatedSprite)",
    description: "Bir nechta alohida rasmlar to'plamidan PixiJS-da AnimatedSprite yaratish va uni boshqarish.",
    content: `
<h3>PIXI.AnimatedSprite Sinfi</h3>
<p>O'yin qahramonining yurishi, portlashi yoki yugurishini ko'rsatish uchun bir nechta rasmlarni ketma-ket almashtirib turish kerak. PixiJS-da bu vazifani <code>PIXI.AnimatedSprite</code> bajaradi.</p>
<h3>Yaratish bosqichlari:</h3>
<ol>
    <li>Barcha animatsiya kadrlari teksturalarini massivga yig'ish: <code>const textures = [...];</code></li>
    <li>Ushbu teksturalar bilan AnimatedSprite-ni yaratish.</li>
    <li>Sahnaga qo'shish va <code>play()</code> metodini chaqirish.</li>
</ol>
<h3>Kodni yozish:</h3>
<pre><code class="language-javascript">// 1. Tasvirlar massividan teksturalar yaratamiz
const texture1 = await PIXI.Assets.load('frame1.png');
const texture2 = await PIXI.Assets.load('frame2.png');
const texture3 = await PIXI.Assets.load('frame3.png');
const frames = [texture1, texture2, texture3];
// 2. Animatsiyalangan sprite-ni yaratamiz
const anim = new PIXI.AnimatedSprite(frames);
anim.x = 200;
anim.y = 150;
anim.anchor.set(0.5);
// 3. Tezligini belgilaymiz (0 dan 1 gacha foizda)
// Masalan 0.1 kadr tezligi sekundiga ~6 kadr almashishini ta'minlaydi
anim.animationSpeed = 0.15; 
// 4. Animatsiyani boshlash
anim.play();
app.stage.addChild(anim);</code></pre>
<h3>Animatsiyani Boshqarish Metodlari:</h3>
<ul>
    <li><code>anim.stop();</code> — Animatsiyani vaqtinchalik to'xtatish.</li>
    <li><code>anim.gotoAndPlay(kadrIndex);</code> — Belgilangan kadr indeksidan boshlab animatsiyani davom ettirish.</li>
    <li><code>anim.loop = false;</code> — Animatsiya bir marta tugagach, to'xtashi (masalan portlash effekti uchun qulay).</li>
</ul>
    `,
    code: `// AnimatedSprite yaratish haqida namuna
// - Rasmlarni yuklash
// - Massivga yig'ish
// - animationSpeed va play() metodlari orqali ishga tushirish`,
    mockupType: "animations"
  },
  {
    id: 8,
    title: "8-dars: Animatsiyalar: Dasturiy Animatsiya (Tween/Lerp)",
    description: "Kutubxonalarsiz, sof matematika va Ticker yordamida obyektlarni silliq tebranishi va harakatlarini yaratish.",
    content: `
<h3>Dasturiy (Algoritmik) Animatsiya</h3>
<p>Har doim ham obyektlarni harakatlantirish uchun tayyor rasmlar kerak emas. Ba'zan obyektning o'lchamini silliq kattalashtirish (Pop-up), shaffofligini o'zgartirish (Fade) yoki uni bir nuqtadan ikkinchi nuqtaga silliq siljitish talab qilinadi.</p>
<h3>1. Lerp (Linear Interpolation) - Silliq yaqinlashish</h3>
<p><strong>Lerp</strong> formulasi obyektni belgilangan nuqtaga o'ta silliqlik bilan yaqinlashtiradi.
Formula: <code>HozirgiValue += (MaqsadValue - HozirgiValue) * Tezlik</code>.</p>
<pre><code class="language-javascript">let targetX = 400;
app.ticker.add((ticker) => {
    // Har kadrda kema sichqoncha koordinatasiga silliq yaqinlashadi
    sprite.x += (targetX - sprite.x) * 0.1 * ticker.deltaTime;
});</code></pre>
<h3>2. Sinus va Kosinus orqali tebranish</h3>
<p>Sinus (<code>Math.sin</code>) to'lqinsimon qiymat qaytaradi (doimo -1 dan 1 gacha). Undan foydalanib obyektlarni suvda suzgandek yoki havoda turgandek tebratish mumkin:</p>
<pre><code class="language-javascript">let time = 0;
app.ticker.add((ticker) => {
    time += 0.05 * ticker.deltaTime;
    
    // Y-o'qi bo'yicha yuqoriga va pastga silliq suzish
    sprite.y = 200 + Math.sin(time) * 20; 
    
    // Nafas olish effekti (Scale kattalashib kichrayishi)
    sprite.scale.set(1 + Math.sin(time) * 0.05);
});</code></pre>
    `,
    code: `// Lerp va Sinusoid animatsiyalar yaratish
const app = new PIXI.Application();
await app.init({ width: 600, height: 400, backgroundColor: 0x0f0f1a });
document.body.appendChild(app.canvas);
const ball = new PIXI.Graphics().circle(0, 0, 20).fill(0xe84118);
ball.position.set(300, 200);
app.stage.addChild(ball);
let elapsed = 0;
app.ticker.add((ticker) => {
    elapsed += 0.04 * ticker.deltaTime;
    
    // 1. Suvda suzish effekti
    ball.y = 200 + Math.sin(elapsed) * 30;
    
    // 2. Hajm o'zgarishi
    ball.scale.set(1 + Math.cos(elapsed) * 0.1);
    
    // 3. Shaffoflik o'zgarishi
    ball.alpha = 0.8 + Math.sin(elapsed) * 0.2;
});`,
    mockupType: "tween"
  },
  {
    id: 9,
    title: "9-dars: Spritesheets (Tekstura Atlaslari)",
    description: "Tasvirlarni bitta katta rasmga birlashtirish va GPU-ni yuklamasdan undan foydalanish tizimi.",
    content: `
<h3>Spritesheet (Rasm to'plami atlaslari) afzalligi</h3>
<p>Agar o'yiningizda 30 xil rasm bo'lsa, ularni alohida-alohida fayl shaklida brauzerdan yuklash brauzer va GPU uchun og'ir hisoblanadi. O'yin sanoatida barcha rasmlar bitta katta rasm kartasiga birlashtiriladi va u **Spritesheet** deb ataladi.</p>
<p>PixiJS bu rasmning qaysi koordinatasida qaysi rasm turganini maxsus <strong>JSON metadata</strong> orqali bilib oladi.</p>
<h3>JSON + Rasm ulanishi va kod:</h3>
<pre><code class="language-javascript">// Spritesheet JSON ma'lumotlarini yuklash
const sheet = await PIXI.Assets.load('assets/game_sprites.json');
// Istalgan rasmni uning JSON kaliti (nomi) bo'yicha olamiz
const playerTexture = sheet.textures['player_ship.png'];
const player = new PIXI.Sprite(playerTexture);
app.stage.addChild(player);</code></pre>
<h3>Qo'lda kesib olish (Texture.from)</h3>
<p>Agar sizda JSON fayli bo'lmasa, bitta rasmning ma'lum bir qismini kod orqali kesib olib ham tekstura yaratish mumkin:</p>
<pre><code class="language-javascript">// Katta rasmni yuklaymiz
const baseTexture = await PIXI.Assets.load('assets/sheet.png');
// Kesish koordinatasini belgilaymiz (Rectangle)
const frame = new PIXI.Rectangle(0, 0, 64, 64); // x, y, w, h
// Kesilgan qismdan yangi tekstura yaratamiz
const subTexture = new PIXI.Texture({
    source: baseTexture,
    frame: frame
});
const sprite = new PIXI.Sprite(subTexture);
app.stage.addChild(sprite);</code></pre>
    `,
    code: `// Spritesheet yoki Kesilgan tekstura namunasi
// const base = await PIXI.Assets.load('atlas.png');
// const rect = new PIXI.Rectangle(0, 0, 32, 32);
// const texture = new PIXI.Texture({ source: base, frame: rect });`,
    mockupType: "spritesheet"
  },
  {
    id: 10,
    title: "10-dars: O'yin Kamera va Culling (Qirqish)",
    description: "Sahnadagi ekrandan tashqarida turgan minglab obyektlarni renderlash jarayonidan olib tashlash orqali tezlikni oshirish.",
    content: `
<h3>Culling (Ko'rinmaydiganlarni qirqish) nima?</h3>
<p>Siz o'yin xaritasini juda katta yaratgan bo'lishingiz mumkin (masalan 5000 ga 5000 piksel). Unda 2000 ta dushman va daraxtlar turibdi. Lekin brauzer ekrani faqat 800 ga 600 pikselni ko'rsata oladi.</p>
<p>PixiJS standart holatda ekran tashqarisidagi obyektlarni ham hisoblab chizaveradi, bu esa o'yinni judayam sekinlashtiradi.
**Culling** – bu ekranga sig'maydigan (ko'rinmaydigan) obyektlarning <code>visible</code> xususiyatini <code>false</code> qilib qo'yishdir. Shunda GPU ularni chizishga umuman kuch sarflamaydi.</p>
<h3>Culling Kod Namunasi:</h3>
<pre><code class="language-javascript">const camera = { x: 0, y: 0, width: 800, height: 600 };
const objects = []; // Minglab obyektlar
app.ticker.add((ticker) => {
    // Har kadrda barcha obyektlarni tekshiramiz
    for (const obj of objects) {
        // Agar obyekt kamera ramkasidan tashqarida bo'lsa
        if (obj.x < camera.x - 50 || 
            obj.x > camera.x + camera.width + 50 ||
            obj.y < camera.y - 50 || 
            obj.y > camera.y + camera.height + 50) {
            
            obj.visible = false; // GPU buni render qilmaydi!
        } else {
            obj.visible = true;  // Faqat ekrandagilarni chizadi
        }
    }
});</code></pre>
<p><strong>Natijada:</strong> Bir vaqtning o'zida sahnada 5000 ta daraxt bo'lsa ham, faqat ekrandagi 50 tasi chiziladi va o'yin mutlaqo qotmaydi.</p>
    `,
    code: `// Culling va Kamera optimalligi namunasi
const app = new PIXI.Application();
await app.init({ width: 600, height: 400, backgroundColor: 0x111 });
document.body.appendChild(app.canvas);
// O'yin xaritasi balandligi 2000 piksel
const objects = [];
for (let i = 0; i < 500; i++) {
    const obj = new PIXI.Graphics().circle(0,0,10).fill(0xffcc00);
    obj.x = Math.random() * 600;
    obj.y = Math.random() * 2000; // Ekrandan ancha pastda ham bor
    app.stage.addChild(obj);
    objects.push(obj);
}
let cameraY = 0;
app.ticker.add((ticker) => {
    cameraY += 2 * ticker.deltaTime; // Kamera pastga siljiydi
    if (cameraY > 1600) cameraY = 0;
    
    objects.forEach(obj => {
        // Obyekt Y koordinatasini kameraga nisbatan siljitish
        obj.y -= 2 * ticker.deltaTime;
        if (obj.y < 0) obj.y = 2000; // Qayta pastga tushirish
        
        // CULLING tekshiruvi: faqat ekrandagi 0-400 oraliqdagi elementlar ko'rinadi
        if (obj.y < -20 || obj.y > 420) {
            obj.visible = false; // Yashirish
        } else {
            obj.visible = true;  // Ko'rsatish
        }
    });
});`,
    mockupType: "culling"
  },
  {
    id: 11,
    title: "11-dars: ParticleContainer va 10,000+ Zarralar",
    description: "Zarralar tizimi (Particles) bilan ishlash va ularni ParticleContainer yordamida tezkor renderlash.",
    content: `
<h3>Zarralar (Particles) nima?</h3>
<p>O'yinlardagi olov, portlashlar, qor yog'ishi yoki sehrli changlar yuzlab va minglab mayda elementlar (Particles) orqali yasaladi.
Buning uchun oddiy <code>PIXI.Container</code> ishlatsak, kadrlar soni (FPS) darhol tushib ketadi.</p>
<h3>ParticleContainer (Tezkor zarralar konteyneri)</h3>
<p><code>PIXI.ParticleContainer</code> faqatgina bir xil teksturadagi spritelarni renderlashga moslashtirilgan o'ta yuqori tezlikdagi konteynerdir. U barcha elementlarni bitta **Batch (grafik paket)** orqali GPU-ga yuboradi.</p>
<pre><code class="language-javascript">// 1. ParticleContainer yaratish (Maksimal 10,000 zarra)
const particleContainer = new PIXI.ParticleContainer(10000, {
    position: true,  // Koordinatalarni o'zgartirishga ruxsat
    scale: true,     // Kattalikni o'zgartirishga ruxsat
    rotation: true,  // Burilishga ruxsat
    alpha: true      // Shaffoflikni o'zgartirishga ruxsat
});
app.stage.addChild(particleContainer);
// 2. Zarralarni qo'shish (Ular hammasi bitta umumiy teksturadan foydalanadi)
const snowTexture = await PIXI.Assets.load('snow.png');
for (let i = 0; i < 1000; i++) {
    const flake = new PIXI.Sprite(snowTexture);
    flake.x = Math.random() * 800;
    flake.y = Math.random() * 600;
    
    particleContainer.addChild(flake);
}</code></pre>
<p><strong>Cheklovlar:</strong> Tezlikka erishish uchun ushbu konteyner ichidagi spritelarning ba'zi xususiyatlari (masalan maska, murakkab bolalar, filtrlar) cheklangan bo'ladi.</p>
    `,
    code: `// ParticleContainer namunaviy kodi
const pContainer = new PIXI.ParticleContainer(5000, {
    position: true,
    scale: true,
    alpha: true
});
app.stage.addChild(pContainer);`,
    mockupType: "particles"
  },
  {
    id: 12,
    title: "12-dars: Katta Loyiha: Space Shooter Pro",
    description: "Object Pooling, elementlarni targeted o'chirish, to'qnashuvlar va animatsiyalar jamlangan to'liq optimal o'yin loyihasi.",
    content: `
<h3>Space Shooter Pro: Professional O'yin</h3>
<p>Ushbu o'yin biz o'rgangan barcha ilg'or optimallashtirish usullarini o'zida jamlagan. O'qlar oldindan yaratilgan puldan (Pooling) olinadi, dushmanlar va zarralar ekrandan chiqib ketganda massivdan va grafik xotiradan to'g'ri tozalanadi.</p>
<p>Kodni nusxalab olib, bitta HTML fayl sifatida saqlang va brauzerda oching:</p>
<pre><code class="language-html">&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
    &lt;script src="https://pixijs.download/v8.2.6/pixi.min.js"&gt;&lt;/script&gt;
    &lt;style&gt;
        body { margin: 0; background: #000; display: flex; justify-content: center; }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;script&gt;
        const app = new PIXI.Application();
        
        async function start() {
            await app.init({ width: 600, height: 600, backgroundColor: 0x050510 });
            document.body.appendChild(app.canvas);
            // 1. O'yinchi kemasi
            const player = new PIXI.Graphics().moveTo(0, -15).lineTo(12, 12).lineTo(-12, 12).closePath().fill(0x00d2d3);
            player.position.set(300, 520);
            app.stage.addChild(player);
            const keys = {};
            const enemies = [];
            const particles = [];
            let score = 0;
            // 2. BULLET POOL (O'Q HUVUZI - OPTIMIZATSIYA)
            const bulletPool = [];
            const POOL_SIZE = 25;
            for (let i = 0; i < POOL_SIZE; i++) {
                const b = new PIXI.Graphics().rect(-1.5, -8, 3, 16).fill(0xffd200);
                b.visible = false;
                app.stage.addChild(b);
                bulletPool.push({ sprite: b, active: false });
            }
            // O'q otish
            function fire() {
                const b = bulletPool.find(item => !item.active);
                if (b) {
                    b.sprite.x = player.x;
                    b.sprite.y = player.y - 15;
                    b.sprite.visible = true;
                    b.active = true;
                }
            }
            window.addEventListener('keydown', e => {
                keys[e.code] = true;
                if (e.code === 'Space') fire();
            });
            window.addEventListener('keyup', e => keys[e.code] = false);
            // Dushmanlarni yaratish
            setInterval(() => {
                const e = new PIXI.Graphics().rect(-15, -15, 30, 30).fill(0xff4757);
                e.position.set(Math.random() * 560 + 20, -20);
                app.stage.addChild(e);
                enemies.push(e);
            }, 800);
            // Portlash zarralari funksiyasi
            function explode(x, y) {
                for (let i = 0; i < 15; i++) {
                    const p = new PIXI.Graphics().circle(0, 0, Math.random() * 3 + 1).fill(0xff7f50);
                    p.x = x;
                    p.y = y;
                    p.vx = (Math.random() - 0.5) * 6;
                    p.vy = (Math.random() - 0.5) * 6;
                    p.alpha = 1;
                    app.stage.addChild(p);
                    particles.push(p);
                }
            }
            app.ticker.add((ticker) => {
                // Kema harakati
                if (keys['ArrowLeft'] && player.x > 20) player.x -= 5 * ticker.deltaTime;
                if (keys['ArrowRight'] && player.x < 580) player.x += 5 * ticker.deltaTime;
                // O'qlar harakati
                bulletPool.forEach(b => {
                    if (b.active) {
                        b.sprite.y -= 8 * ticker.deltaTime;
                        if (b.sprite.y < -20) {
                            b.sprite.visible = false;
                            b.active = false; // Pulga qaytarish
                        }
                    }
                });
                // Zarralar harakati (Targeted removal)
                for (let i = particles.length - 1; i >= 0; i--) {
                    const p = particles[i];
                    p.x += p.vx * ticker.deltaTime;
                    p.y += p.vy * ticker.deltaTime;
                    p.alpha -= 0.03 * ticker.deltaTime;
                    if (p.alpha <= 0) {
                        p.destroy();
                        particles.splice(i, 1);
                    }
                }
                // Dushmanlar harakati (To'qnashuv va Targeted removal)
                for (let i = enemies.length - 1; i >= 0; i--) {
                    const e = enemies[i];
                    e.y += 3 * ticker.deltaTime;
                    if (e.y > 620) {
                        e.destroy();
                        enemies.splice(i, 1);
                        continue;
                    }
                    // O'yinchi to'qnashuvi
                    if (Math.abs(player.x - e.x) < 25 && Math.abs(player.y - e.y) < 25) {
                        alert("Game Over! Ochko: " + score);
                        location.reload();
                    }
                    // O'qlar to'qnashuvi
                    bulletPool.forEach(b => {
                        if (b.active && Math.abs(b.sprite.x - e.x) < 20 && Math.abs(b.sprite.y - e.y) < 20) {
                            explode(e.x, e.y);
                            e.destroy();
                            enemies.splice(i, 1);
                            b.sprite.visible = false;
                            b.active = false; // O'q pulga qaytdi
                            score += 10;
                        }
                    });
                }
            });
        }
        start();
    &script>
&lt;/body&gt;
&lt;/html&gt;</code></pre>
    `,
    code: `// Space Shooter Pro optimallashtirilgan o'yin arxitekturasi:
// - Bullet pooling: 60 FPS saqlaydi.
// - Zarralar va dushmanlar o'chirilganda .destroy() chaqiriladi.
// - GPU va CPU xotirasi doimo toza va bo'sh.`,
    mockupType: "game"
  },
  {
    id: 13,
    title: "13-dars: Xotira va Debugging (Memory Leaks)",
    description: "O'yiningizda xotira sizib chiqishini (Memory Leaks) topish va brauzer Chrome DevTools Memory tabidan foydalanish.",
    content: `
<h3>Memory Leak (Xotira Sizishi) nima?</h3>
<p>Siz spriteni sahnadan o'chirdingiz (<code>app.stage.removeChild(sprite)</code>), ammo u hanuz o'sha o'yinchi massivida saqlanib turibdi. Bunday holatda, JavaScript Garbage Collector (Axlat yig'uvchisi) uni xotiradan butunlay o'chira olmaydi, chunki unga qaratilgan faol havola (reference) mavjud. Natijada xotira hajmi vaqt o'tishi bilan o'sib boradi va o'yin qotadi.</p>
<h3>Chrome DevTools Memory orqali xotirani tekshirish:</h3>
<ol>
    <li>Brauzerda <code>F12</code> tugmasini bosib konsolni oching.</li>
    <li>Yuqori menyudan <strong>Memory</strong> tabini tanlang.</li>
    <li>**Heap snapshot**-ni tanlab, "Take snapshot" tugmasini bosing.</li>
    <li>O'yinni 1 daqiqa o'ynab, qaytadan snapshot oling va solishtiring.</li>
    <li>Agar **Constructor** ro'yxatida <code>PIXI.Sprite</code> yoki <code>PIXI.Graphics</code> soni cheksiz ko'payib borayotgan bo'lsa – demak sizda xotira sizishi bor!</li>
</ol>
<h3>Yechim: To'g'ri o'chirish qoidasi:</h3>
<p>Havolani butunlay o'chiring:</p>
<pre><code class="language-javascript">// 1. GPU dan o'chirish
sprite.destroy({ children: true, texture: true });
// 2. Massivdan o'chirish
const idx = array.indexOf(sprite);
if (idx > -1) {
    array.splice(idx, 1);
}
// 3. O'zgaruvchini bo'shatish (agar kerak bo'lsa)
sprite = null;</code></pre>
    `,
    code: `// Garbage Collection va Xotirani to'liq tozalash namunasi
function forceCleanup(entity, array) {
    // 1. Sahnadan va grafik protsessordan o'chirish
    entity.visual.destroy({
        children: true,
        texture: true
    });
    
    // 2. Massivdagi havolani o'chirish
    const index = array.indexOf(entity);
    if (index > -1) {
        array.splice(index, 1);
    }
    
    // 3. Model ichki havolalarini bo'shatish
    entity.visual = null;
    entity = null; 
}`,
    mockupType: "memory"
  }
];