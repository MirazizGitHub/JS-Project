// Professional PixiJS v2 - Navigation, Responsive Actions & Visual Renderers
let currentLessonIndex = 0;
// Initialize app when DOM loads
document.addEventListener('DOMContentLoaded', () => {
    renderLessonsMenu();
    loadLesson(0);
    setupMobileMenu();
});
// Setup Mobile Responsive Menu
function setupMobileMenu() {
    const toggleBtn = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    toggleBtn.addEventListener('click', (e) => {
        sidebar.classList.toggle('open');
        e.stopPropagation();
    });
    // Close sidebar when clicking outside of it (mobile)
    document.addEventListener('click', (e) => {
        if (window.innerWidth <= 1024) {
            if (!sidebar.contains(e.target) && e.target !== toggleBtn) {
                sidebar.classList.remove('open');
            }
        }
    });
}
// Render the sidebar lessons list
function renderLessonsMenu() {
    const listContainer = document.getElementById('lessonsList');
    listContainer.innerHTML = '';
    LESSONS.forEach((lesson, index) => {
        const item = document.createElement('div');
        item.className = `lesson-item ${index === currentLessonIndex ? 'active' : ''}`;
        item.onclick = () => {
            loadLesson(index);
            // Close sidebar on mobile after selecting a lesson
            if (window.innerWidth <= 1024) {
                document.getElementById('sidebar').classList.remove('open');
            }
        };
        item.innerHTML = `
            <div class="lesson-num">${lesson.id}</div>
            <div class="lesson-info">
                <h3>${lesson.title}</h3>
                <p>${lesson.description.substring(0, 50)}...</p>
            </div>
        `;
        listContainer.appendChild(item);
    });
}
// Load selected lesson
function loadLesson(index) {
    currentLessonIndex = index;
    const lesson = LESSONS[index];
    // Update active class in sidebar
    const items = document.querySelectorAll('.lesson-item');
    items.forEach((item, idx) => {
        if (idx === index) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });
    // Update main content details
    document.getElementById('lessonTitle').innerText = lesson.title;
    document.getElementById('lessonDesc').innerText = lesson.description;
    document.getElementById('lessonContent').innerHTML = lesson.content;
    // Update code block
    document.getElementById('codeDisplay').textContent = lesson.code;
    // Reset copy button state
    const btnCopy = document.getElementById('btnCopy');
    btnCopy.innerText = 'Nusxa olish';
    btnCopy.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
    // Load expected mockup visual representation
    loadVisualMockup(lesson.mockupType);
    
    // Scroll main content pane back to top
    document.getElementById('mainContent').scrollTop = 0;
}
// Render the custom schema/mockup illustrating the PixiJS output
function loadVisualMockup(type) {
    const canvas = document.getElementById('visualCanvas');
    canvas.innerHTML = '';
    let htmlContent = '';
    switch (type) {
        case 'intro':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-intro">
                        <div class="pixi-logo">P</div>
                        <h4>PixiJS Professional v2</h4>
                        <p>Dasturni yuqori darajada optimallashtirish va xotira boshqaruvi bo'limi.</p>
                    </div>
                </div>
            `;
            break;
        case 'arrays':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-arrays">
                        <div class="array-elements-wrapper">
                            <div class="array-item-box">
                                <div class="graphic-box-shape"></div>
                                <div class="array-index">enemies[0]</div>
                            </div>
                            <div class="array-item-box">
                                <div class="graphic-box-shape" style="background-color: #0abde3;"></div>
                                <div class="array-index">enemies[1]</div>
                            </div>
                            <div class="array-item-box">
                                <div class="graphic-box-shape" style="background-color: #ee5253;"></div>
                                <div class="array-index">enemies[2]</div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            break;
        case 'entities':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-entities">
                        <div class="entity-card">
                            <div class="entity-visual"></div>
                            <div class="entity-info-row"><span class="info-label">hp</span><span class="info-value">5</span></div>
                            <div class="entity-info-row"><span class="info-label">speedX</span><span class="info-value">2</span></div>
                            <div class="entity-info-row"><span class="info-label">speedY</span><span class="info-value">1.5</span></div>
                        </div>
                        <div class="entity-card" style="border-color: var(--accent);">
                            <div class="entity-visual" style="background-color: #00d2d3;"></div>
                            <div class="entity-info-row"><span class="info-label">hp</span><span class="info-value">3</span></div>
                            <div class="entity-info-row"><span class="info-label">speedX</span><span class="info-value">-2</span></div>
                            <div class="entity-info-row"><span class="info-label">speedY</span><span class="info-value">1.8</span></div>
                        </div>
                    </div>
                </div>
            `;
            break;
        case 'dynamic-add':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-dynamic-add">
                        <div class="spawn-ring"></div>
                        <div class="spawn-ring" style="background-color: rgba(238, 82, 83, 0.1); border-color: #ee5253;"></div>
                        <div class="spawn-ring" style="background-color: rgba(165, 94, 234, 0.1); border-color: #a55eea;"></div>
                        <div class="spawn-ring" style="background-color: rgba(255, 179, 0, 0.1); border-color: var(--warning);"></div>
                        <div class="pointer-cursor-sim">👆</div>
                        <div class="pointer-click-msg">Ekran bosilganda yangi shakl qo'shish</div>
                    </div>
                </div>
            `;
            break;
        case 'removal':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-removal">
                        <div class="removal-stage">
                            <div class="removal-circle">c</div>
                            <div class="removal-desc">Aktif element</div>
                        </div>
                        <span class="removal-arrow">➔</span>
                        <div class="removal-stage">
                            <div class="removal-circle deleted">c</div>
                            <div class="removal-desc">c.destroy() (VRAM toza)</div>
                        </div>
                        <span class="removal-arrow">➔</span>
                        <div class="removal-stage">
                            <div class="removal-desc" style="border: 1px dashed var(--danger); padding: 8px; border-radius: 4px; color: var(--danger);">
                                list.splice(i, 1)<br>(JS massivdan o'chdi)
                            </div>
                        </div>
                    </div>
                </div>
            `;
            break;
        case 'pooling':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-pooling">
                        <div class="pool-grid">
                            <div class="pool-item active">
                                <div class="pool-bullet"></div>
                                <span class="pool-status">Active</span>
                            </div>
                            <div class="pool-item active">
                                <div class="pool-bullet"></div>
                                <span class="pool-status">Active</span>
                            </div>
                            <div class="pool-item">
                                <div class="pool-bullet"></div>
                                <span class="pool-status">Idle</span>
                            </div>
                            <div class="pool-item">
                                <div class="pool-bullet"></div>
                                <span class="pool-status">Idle</span>
                            </div>
                            <div class="pool-item">
                                <div class="pool-bullet"></div>
                                <span class="pool-status">Idle</span>
                            </div>
                        </div>
                        <div class="pool-footer">
                            <span>Max hovuz o'lchami: 15</span>
                            <span style="color: var(--success);">FPS barqarorligi: 60.0</span>
                        </div>
                    </div>
                </div>
            `;
            break;
        case 'animations':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-animations">
                        <div class="anim-frame">Frame 0</div>
                        <div class="anim-frame current">Frame 1</div>
                        <div class="anim-frame">Frame 2</div>
                        <div class="anim-frame">Frame 3</div>
                    </div>
                </div>
            `;
            break;
        case 'tween':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-tween">
                        <div class="sine-wave-path"></div>
                        <div class="tween-ball" id="tweenBall"></div>
                    </div>
                </div>
            `;
            setTimeout(animateTweenBall, 100);
            break;
        case 'spritesheet':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-spritesheet">
                        <div class="atlas-grid">
                            <div class="atlas-cell">hero_walk1</div>
                            <div class="atlas-cell">hero_walk2</div>
                            <div class="atlas-cell">bullet</div>
                            <div class="atlas-cell">enemy_ufo</div>
                            <div class="atlas-cell">coin1</div>
                            <div class="atlas-cell">coin2</div>
                            <div class="atlas-cell">explosion</div>
                            <div class="atlas-cell">bg_stars</div>
                        </div>
                        <span style="font-size: 11px; text-align: center; color: var(--text-secondary);">
                            Bitta katta rasm kartasi + JSON atlas yuklanishi.
                        </span>
                    </div>
                </div>
            `;
            break;
        case 'culling':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-culling">
                        <div class="dot-element dot-1"></div>
                        <div class="dot-element dot-2"></div>
                        <div class="dot-element dot-3 culled"></div>
                        <div class="dot-element dot-4 culled"></div>
                        <div class="viewport-box"></div>
                        <span style="position: absolute; bottom: 8px; left: 16px; font-size: 9px; color: var(--text-secondary);">
                            *Kulrang elementlar visible = false qilib qirqilgan.
                        </span>
                    </div>
                </div>
            `;
            break;
        case 'particles':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-particles">
                        <div class="emitter-center"></div>
                        <div class="particle-spark"></div>
                        <div class="particle-spark"></div>
                        <div class="particle-spark"></div>
                        <div class="particle-spark"></div>
                        <div class="particle-spark"></div>
                        <div class="particle-spark"></div>
                    </div>
                </div>
            `;
            break;
        case 'game':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-game">
                        <div class="game-score">Ochko: 150 | Pooling: ON</div>
                        <div class="alien-enemy alien-1"></div>
                        <div class="alien-enemy alien-2"></div>
                        <div class="alien-enemy alien-3"></div>
                        <div class="laser-beam" style="left: calc(50% - 1.5px); bottom: 150px;"></div>
                        <div class="laser-beam" style="left: calc(50% - 1.5px); bottom: 280px;"></div>
                        <div class="player-ship"></div>
                    </div>
                </div>
            `;
            break;
        case 'memory':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-memory">
                        <div class="stats-box">
                            <div class="stats-row"><span>Sprite havolalari:</span><span class="stat-val red">2400 (Memory Leak)</span></div>
                            <div class="stats-row"><span>Active Sprites:</span><span class="stat-val green">30</span></div>
                            <div class="stats-row"><span>Xotira hajmi:</span><span class="stat-val red">240 MB (Kattalashmoqda)</span></div>
                        </div>
                        <div class="memory-leak-badge">Massivda havolalar tozalanishi shart!</div>
                    </div>
                </div>
            `;
            break;
        default:
            htmlContent = `<div style="color: var(--text-secondary)">Vizual sxema mavjud emas</div>`;
    }
    canvas.innerHTML = htmlContent;
}
// Copy Code function
function copyCode() {
    const codeText = document.getElementById('codeDisplay').textContent;
    navigator.clipboard.writeText(codeText).then(() => {
        const btnCopy = document.getElementById('btnCopy');
        btnCopy.innerText = 'Nusxalandi!';
        btnCopy.style.backgroundColor = 'var(--success)';
        
        setTimeout(() => {
            btnCopy.innerText = 'Nusxa olish';
            btnCopy.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
        }, 2000);
    }).catch(err => {
        console.error('Nusxalashda xatolik:', err);
    });
}
// Simple custom animation for the Tween mockup ball using pure JS/CSS
let tweenDir = 1;
let tweenVal = 0;
function animateTweenBall() {
    const ball = document.getElementById('tweenBall');
    if (!ball) return;
    
    tweenVal += 0.04 * tweenDir;
    if (tweenVal > 1 || tweenVal < -1) {
        tweenDir *= -1;
    }
    
    // Animate ball's position scale based on sine wave
    const yOffset = Math.sin(tweenVal * Math.PI) * 40;
    const scale = 1 + Math.cos(tweenVal * Math.PI) * 0.15;
    
    ball.style.transform = `translate(-50%, calc(-50% + ${yOffset}px)) scale(${scale})`;
    
    // Call next frame if this mockup is still active
    if (LESSONS[currentLessonIndex].mockupType === 'tween') {
        requestAnimationFrame(animateTweenBall);
    }
}