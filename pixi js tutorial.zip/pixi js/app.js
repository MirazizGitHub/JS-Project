// PixiJS Uzbek Tutorial Platform JS - Navigation & UI Controls
let currentLessonIndex = 0;
// Initialize app when DOM loads
document.addEventListener('DOMContentLoaded', () => {
    renderLessonsMenu();
    loadLesson(0);
});
// Render the sidebar lessons list
function renderLessonsMenu() {
    const listContainer = document.getElementById('lessonsList');
    listContainer.innerHTML = '';
    LESSONS.forEach((lesson, index) => {
        const item = document.createElement('div');
        item.className = `lesson-item ${index === currentLessonIndex ? 'active' : ''}`;
        item.onclick = () => loadLesson(index);
        item.innerHTML = `
            <div class="lesson-num">${lesson.id}</div>
            <div class="lesson-info">
                <h3>${lesson.title}</h3>
                <p>${lesson.description.substring(0, 50)}...</p>
            </div>
        `;
        listContainer.appendChild(item);
    });
}
// Load selected lesson
function loadLesson(index) {
    currentLessonIndex = index;
    const lesson = LESSONS[index];
    // Update active class in sidebar
    const items = document.querySelectorAll('.lesson-item');
    items.forEach((item, idx) => {
        if (idx === index) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });
    // Update main content details
    document.getElementById('lessonTitle').innerText = lesson.title;
    document.getElementById('lessonDesc').innerText = lesson.description;
    document.getElementById('lessonContent').innerHTML = lesson.content;
    // Update code block
    document.getElementById('codeDisplay').textContent = lesson.code;
    // Reset copy button state
    const btnCopy = document.getElementById('btnCopy');
    btnCopy.innerText = 'Nusxa olish';
    btnCopy.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
    // Load expected mockup visual
    loadVisualMockup(lesson.mockupType);
    
    // Scroll content to top
    document.getElementById('mainContent').scrollTop = 0;
}
// Load correct HTML mockup representing the PixiJS output
function loadVisualMockup(type) {
    const canvas = document.getElementById('visualCanvas');
    canvas.innerHTML = '';
    let htmlContent = '';
    switch (type) {
        case 'intro':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-intro">
                        <div class="pixi-logo">P</div>
                        <h4>PixiJS v8.2.6</h4>
                        <p>Kutubxona yuklandi va PIXI global obyekti ishga tushishga tayyor.</p>
                    </div>
                </div>
            `;
            break;
        case 'canvas-init':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-canvas-init">
                        <span class="app-badge">PIXI.Application</span>
                        <div class="gpu-text">WebGL2 Renderer faol</div>
                        <div class="canvas-dims">600 x 400</div>
                    </div>
                </div>
            `;
            break;
        case 'coords':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-coords">
                        <div class="axis-x"></div>
                        <div class="axis-y"></div>
                        <div class="rotated-box"></div>
                        <div class="center-dot"></div>
                        <div class="coordinate-label">(300, 200)</div>
                        <div class="origin-text">Anchor: 0.5, 0.5 (Markaz)</div>
                    </div>
                </div>
            `;
            break;
        case 'graphics':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-graphics">
                        <div class="rect-shape"></div>
                        <div class="circle-shape"></div>
                        <div class="poly-shape"></div>
                    </div>
                </div>
            `;
            break;
        case 'sprites':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-sprites">
                        <div class="bunny-card">
                            <div class="bunny-icon"><div class="bunny-face"></div></div>
                        </div>
                        <div class="bunny-card">
                            <div class="bunny-icon"><div class="bunny-face"></div></div>
                        </div>
                        <div class="bunny-card">
                            <div class="bunny-icon"><div class="bunny-face"></div></div>
                        </div>
                        <div class="bunny-card">
                            <div class="bunny-icon"><div class="bunny-face"></div></div>
                        </div>
                    </div>
                </div>
            `;
            break;
        case 'texts':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-texts">
                        <div class="gradient-text-mock">PIXIJS DARS</div>
                    </div>
                </div>
            `;
            break;
        case 'containers':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-containers">
                        <div class="container-border">
                            <div class="tree-element">
                                <div class="tree-leaves"></div>
                                <div class="tree-trunk"></div>
                            </div>
                            <div class="tree-element">
                                <div class="tree-leaves"></div>
                                <div class="tree-trunk"></div>
                            </div>
                            <div class="tree-element">
                                <div class="tree-leaves"></div>
                                <div class="tree-trunk"></div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            break;
        case 'ticker':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-ticker">
                        <span class="arrow-indicator arrow-left">◀</span>
                        <div class="movement-path">
                            <div class="anim-box" id="animBox"></div>
                        </div>
                        <span class="arrow-indicator arrow-right">▶</span>
                        <div class="speed-display">app.ticker.add() animatsiyasi</div>
                    </div>
                </div>
            `;
            // Simple mockup timer interaction since we don't want animated heavy stuff, we can just do a very basic CSS animation directly bound or leave it clean. Let's keep it static but visually clear as per user's preference.
            break;
        case 'events':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-events">
                        <div class="interactive-circle" id="interactiveCircle" onclick="simulateClick()">KLIK!</div>
                        <div class="cursor-sim">btn.eventMode = 'static'</div>
                    </div>
                </div>
            `;
            break;
        case 'filters':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-filters">
                        <div class="filter-box"></div>
                        <div class="filter-ring"></div>
                        <div class="filter-label">BlurFilter (blur = 5)</div>
                    </div>
                </div>
            `;
            break;
        case 'game':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-game">
                        <div class="game-score">Score: 120</div>
                        <div class="alien-enemy alien-1"></div>
                        <div class="alien-enemy alien-2"></div>
                        <div class="alien-enemy alien-3"></div>
                        <div class="laser-beam" style="left: calc(50% - 2px); bottom: 180px;"></div>
                        <div class="laser-beam" style="left: calc(50% - 2px); bottom: 320px;"></div>
                        <div class="player-ship"></div>
                    </div>
                </div>
            `;
            break;
        case 'optimization':
            htmlContent = `
                <div class="mockup-container">
                    <div class="mockup-optimization">
                        <div class="stats-box">
                            <div class="stats-row"><span>FPS:</span><span class="stat-val green">60.0</span></div>
                            <div class="stats-row"><span>Draw Calls:</span><span class="stat-val green">1 (ParticleContainer)</span></div>
                            <div class="stats-row"><span>Sprites:</span><span class="stat-val cyan">10,000</span></div>
                            <div class="stats-row"><span>VRAM:</span><span class="stat-val green">12 MB</span></div>
                        </div>
                        <div class="optimization-badge">Optimal ishlash</div>
                    </div>
                </div>
            `;
            break;
        default:
            htmlContent = `<div style="color: var(--text-secondary)">Vizual natija mavjud emas</div>`;
    }
    canvas.innerHTML = htmlContent;
}
// Copy Code function
function copyCode() {
    const codeText = document.getElementById('codeDisplay').textContent;
    navigator.clipboard.writeText(codeText).then(() => {
        const btnCopy = document.getElementById('btnCopy');
        btnCopy.innerText = 'Nusxalandi!';
        btnCopy.style.backgroundColor = 'var(--success)';
        
        setTimeout(() => {
            btnCopy.innerText = 'Nusxa olish';
            btnCopy.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
        }, 2000);
    }).catch(err => {
        console.error('Nusxalashda xatolik:', err);
    });
}
// Interactive circle click simulator (mini mock interaction)
function simulateClick() {
    const circle = document.getElementById('interactiveCircle');
    if (circle) {
        circle.style.backgroundColor = '#00d2d3';
        circle.innerText = 'BOSILDI!';
        setTimeout(() => {
            circle.style.backgroundColor = '#4cd137';
            circle.innerText = 'KLIK!';
        }, 600);
    }
}