const LESSONS = [
  {
    id: 1,
    title: "1-dars: Kirish va O'rnatish",
    description: "PixiJS nima va uni jQuery kabi oddiy CDN orqali HTML faylga qanday ulashni o'rganamiz.",
    content: `
<h3>PixiJS Nima?</h3>
<p>PixiJS – bu veb-brauzerda 2D grafika va o'yinlar yaratish uchun eng tezkor va ommabop 2D renderlash dvigatelidir. U orqa fonda <strong>WebGL (WebGL 2)</strong> texnologiyasidan foydalanadi, agar brauzer WebGL-ni qo'llab-quvvatlamasa, avtomatik ravishda oddiy HTML5 Canvas rejimiga o'tadi.</p>
<p><strong>Muhim eslatma:</strong> PixiJS bu o'yin dvigateli (game engine) emas (masalan, unda tayyor fizika yoki ovoz tizimi yo'q), u faqat <strong>renderlash dvigateli (renderer)</strong> hisoblanadi. U ekranga tasvirlarni o'ta tezkor tezlikda chizishga ixtisoslashgan.</p>
<h3>Nega Node.js-siz o'rganamiz?</h3>
<p>Ko'plab darsliklar PixiJS-ni <code>npm</code>, <code>webpack</code>, yoki <code>vite</code> kabi murakkab asboblar yordamida o'rgatadi. Ammo PixiJS-ning go'zalligi shundaki, uni xuddi <strong>jQuery</strong> kabi oddiygina bitta <code>&lt;script&gt;</code> tegi orqali HTML-ga ulab ishlatish mumkin. Bu usul boshlang'ich o'rganuvchilar uchun juda oson va ortiqcha sozlamalarni talab qilmaydi.</p>
<h3>CDN orqali ulash</h3>
<p>PixiJS kutubxonasini ulash uchun quyidagi CDN havolasini HTML faylingizning <code>&lt;head&gt;</code> qismiga qo'shasiz:</p>
<pre><code class="language-html">&lt;script src="https://pixijs.download/v8.2.6/pixi.min.js"&gt;&lt;/script&gt;</code></pre>
<h3>Birinchi HTML Fayl Shabloni</h3>
<p>Quyida PixiJS-ni ulash uchun to'liq va tayyor HTML shablon keltirilgan:</p>
<pre><code class="language-html">&lt;!DOCTYPE html&gt;
&lt;html lang="uz"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;PixiJS Birinchi Qadam&lt;/title&gt;
    &lt;!-- PixiJS-ni CDN orqali ulash --&gt;
    &lt;script src="https://pixijs.download/v8.2.6/pixi.min.js"&gt;&lt;/script&gt;
    &lt;style&gt;
        body {
            margin: 0;
            padding: 0;
            background-color: #2c3e50;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        canvas {
            box-shadow: 0 10px 25px rgba(0,0,0,0.5);
            border-radius: 8px;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;script&gt;
        // Bu erda PixiJS kodimiz yoziladi
        console.log("PIXI obyekti yuklandi:", PIXI);
    &lt;/script>
&lt;/body&gt;
&lt;/html&gt;</code></pre>
    `,
    code: `<!DOCTYPE html>
<html>
<head>
    <script src="https://pixijs.download/v8.2.6/pixi.min.js"></script>
</head>
<body>
    <script>
        // Brauzer konsolida PIXI obyekti borligini tekshirish
        console.log("PixiJS Versiyasi:", PIXI.VERSION);
    </script>
</body>
</html>`,
    mockupType: "intro"
  },
  {
    id: 2,
    title: "2-dars: Application (Ilova) yaratish",
    description: "PixiJS ilovasini (Application) qanday e'lon qilishni va sahna (stage) sozlamalarini boshqarishni ko'rib chiqamiz.",
    content: `
<h3>Application Nima?</h3>
<p>PixiJS ilovasi bu chizish maydoni (Canvas element) hamda renderlash jarayonini boshqaradigan asosiy obyekt hisoblanadi. U osongina <code>PIXI.Application</code> orqali yaratiladi.</p>
<p><strong>PixiJS v8 yangilanishi:</strong> PixiJS-ning eng so'nggi 8-versiyasida ilovani yaratish <strong>asinxron (async/await)</strong> tarzda amalga oshiriladi. Bu grafik protsessor (GPU) bilan ishlashni tezlashtiradi.</p>
<h3>Asosiy Metodlar va Sozlamalar</h3>
<p>Ilovani yaratish ikki bosqichdan iborat:</p>
<ol>
    <li><code>const app = new PIXI.Application();</code> — Ilova nusxasini yaratish.</li>
    <li><code>await app.init({ ... })</code> — Ilovani sozlamalar bilan ishga tushirish (kengligi, balandligi, fon rangi va h.z.).</li>
</ol>
<h3>Muhim Sozlama Xususiyatlari:</h3>
<ul>
    <li><code>width</code> (kenglik): Canvasning kengligi (pikselda).</li>
    <li><code>height</code> (balandlik): Canvasning balandligi (pikselda).</li>
    <li><code>backgroundColor</code> (fon rangi): 16-lik tizimdagi rang (masalan, <code>0x1099bb</code>).</li>
    <li><code>antialias</code> (silliqlash): Shakllarning chetlarini silliq qilish (<code>true</code> yoki <code>false</code>).</li>
    <li><code>resolution</code> (aniqlik): Ekran piksellar zichligi. Odatda Retina ekranlar uchun <code>window.devicePixelRatio</code> beriladi.</li>
</ul>
<h3>Kodni yozish tartibi:</h3>
<pre><code class="language-javascript">// 1. Ilovani yaratish
const app = new PIXI.Application();
// 2. Ilovani asinxron ishga tushirish
async function startApp() {
    await app.init({
        width: 800,
        height: 600,
        backgroundColor: 0x1099bb,
        antialias: true
    });
    // 3. Yaratilgan Canvas-ni HTML sahifaga (body) qo'shish
    document.body.appendChild(app.canvas);
    
    console.log("PixiJS ishga tushdi!");
}
startApp();</code></pre>
<p><strong>Tushuntirish:</strong> <code>app.canvas</code> – bu PixiJS yaratgan va HTML-ga qo'shilishi kerak bo'lgan tayyor <code>&lt;canvas&gt;</code> elementidir. (Eski PixiJS versiyalarida u <code>app.view</code> deb atalardi).</p>
    `,
    code: `// PixiJS v8 da Application yaratish shabloni
const app = new PIXI.Application();
(async () => {
    await app.init({
        width: 600,
        height: 400,
        backgroundColor: 0x1a1a2e, // To'q ko'k fon
        antialias: true
    });
    
    document.body.appendChild(app.canvas);
})();`,
    mockupType: "canvas-init"
  },
  {
    id: 3,
    title: "3-dars: Koordinatalar va Transformatsiya",
    description: "PixiJS sahna koordinatalari, obyektlarning joylashishi, burilishi, o'lchamlari va Anchor (langar) tushunchasi.",
    content: `
<h3>PixiJS Koordinata Tizimi</h3>
<p>PixiJS-da koordinata boshi (0, 0) nuqta ekraning <strong>chap yuqori burchagida</strong> joylashgan bo'ladi.
<ul>
    <li><strong>X o'qi:</strong> chapdan o'ngga qarab o'sib boradi.</li>
    <li><strong>Y o'qi:</strong> tepadan pastga qarab o'sib boradi.</li>
</ul>
</p>
<h3>Anchor (Langar nuqtasi) nima?</h3>
<p>Odatda, biror obyektni sahnaga joylashtirib uni bursangiz yoki o'lchamini o'zgartirsangiz, bu o'zgarishlar obyektning chap yuqori burchagiga (0, 0) nisbatan sodir bo'ladi. Bu boshqarishni qiyinlashtiradi.</p>
<p><code>anchor</code> xususiyati obyektning "markaziy nuqtasi"ni belgilaydi. U 0 dan 1 gacha bo'lgan foiz qiymatlarini oladi:</p>
<ul>
    <li><code>sprite.anchor.set(0, 0)</code> — Chap yuqori burchak (standart).</li>
    <li><code>sprite.anchor.set(0.5, 0.5)</code> — Obyektning qoq markazi (eng ko'p ishlatiladigan usul).</li>
    <li><code>sprite.anchor.set(1, 1)</code> — O'ng pastki burchak.</li>
</ul>
<h3>Pivot (Tayanch nuqta)</h3>
<p><code>anchor</code> faqat rasmlar (Sprites) uchun ishlaydi. Boshqa grafik shakllar va konteynerlar uchun <code>pivot</code> ishlatiladi. Pivot piksel o'lchamida beriladi (masalan, <code>pivot.set(50, 50)</code>).</p>
<h3>Obyekt transformatsiyalari</h3>
<p>Har qanday PixiJS obyektini quyidagi xususiyatlar orqali boshqarish mumkin:</p>
<ul>
    <li><strong>Position (Joylashuv):</strong>
        <pre><code class="language-javascript">sprite.x = 200;
sprite.y = 150;
// yoki bitta kodda:
sprite.position.set(200, 150);</code></pre>
    </li>
    <li><strong>Scale (Kattalashtirish/Kichiklashtirish):</strong>
        <pre><code class="language-javascript">sprite.scale.x = 1.5; // Kengligini 1.5 barobar kattalashtirish
sprite.scale.y = 1.5;
// yoki:
sprite.scale.set(1.5);</code></pre>
    </li>
    <li><strong>Rotation (Burish):</strong>
        PixiJS-da burish burchagi <strong>Radian</strong> o'lchov birligida hisoblanadi. Oddiy burchak darajasini radianga o'tkazish formulasi: <code>radian = daraja * (Math.PI / 180)</code>.
        <pre><code class="language-javascript">sprite.rotation = 45 * (Math.PI / 180); // 45 darajaga burish</code></pre>
    </li>
</ul>
    `,
    code: `// Obyektni markazga joylash va burish namunasi
const app = new PIXI.Application();
await app.init({ width: 600, height: 400, backgroundColor: 0x222 });
document.body.appendChild(app.canvas);
// (Tasavvur qiling rasm yuklangan)
const sprite = new PIXI.Sprite(someTexture);
sprite.position.set(300, 200); // Ekranning markazi (600/2, 400/2)
// Obyekt markaziga nisbatan aylanishi uchun:
sprite.anchor.set(0.5, 0.5); 
// 45 darajaga burish
sprite.rotation = Math.PI / 4; 
app.stage.addChild(sprite);`,
    mockupType: "coords"
  },
  {
    id: 4,
    title: "4-dars: Geometrik Shakllar (Graphics)",
    description: "PixiJS da dasturlash orqali to'rtburchaklar, aylanalar, chiziqlar va boshqa geometrik shakllar chizishni o'rganamiz.",
    content: `
<h3>PIXI.Graphics Sinfi</h3>
<p>Agar sizga tayyor rasmlar emas, balki oddiy shakllar (aylana, kvadrat, chiziqlar, tugma fonlari) kerak bo'lsa, PixiJS-dagi <code>PIXI.Graphics</code> sinfi yordamga keladi. U orqali chizilgan shakllar juda tez renderlanadi va xotirani kam egallaydi.</p>
<h3>Chizishning Asosiy Algoritmi:</h3>
<ol>
    <li>Graphics obyektini yaratish: <code>const graphics = new PIXI.Graphics();</code></li>
    <li>Rang va chiziq uslubini tanlash.</li>
    <li>Shakl geometriyasini belgilash (masalan to'rtburchak yoki aylana).</li>
    <li>Sahnaga qo'shish: <code>app.stage.addChild(graphics);</code></li>
</ol>
<h3>Asosiy Shakllar va Kodlar:</h3>
<h4>1. To'rtburchak (Kvadrat) chizish:</h4>
<pre><code class="language-javascript">const rect = new PIXI.Graphics();
rect.rect(50, 50, 150, 100); // x, y, kenglik, balandlik
rect.fill(0xff0000);         // Qizil rangga bo'yash
app.stage.addChild(rect);</code></pre>
<h4>2. Aylana chizish:</h4>
<pre><code class="language-javascript">const circle = new PIXI.Graphics();
circle.circle(300, 200, 50); // markaziy_x, markaziy_y, radius
circle.fill(0x00ff00);       // Yashil rang
app.stage.addChild(circle);</code></pre>
<h4>3. Chegarali (Stroke) shakl chizish:</h4>
<p>PixiJS v8-da chiziq chizish uchun shakldan keyin yoki oldin <code>stroke()</code> metodini chaqiramiz:</p>
<pre><code class="language-javascript">const borderRect = new PIXI.Graphics();
borderRect.rect(100, 100, 200, 100);
borderRect.fill(0x333333); // Ichki rang to'q kulrang
borderRect.stroke({ width: 4, color: 0xffffff }); // 4px oq chegara
app.stage.addChild(borderRect);</code></pre>
<h4>4. Chiziq chizish (Erkin chizish):</h4>
<pre><code class="language-javascript">const line = new PIXI.Graphics();
line.moveTo(50, 50);   // Chizish boshlanish nuqtasi
line.lineTo(250, 150); // Ushbu nuqtagacha chiziq tortish
line.stroke({ width: 5, color: 0xffaa00 });
app.stage.addChild(line);</code></pre>
<h4>5. Shakllarni tozalash (Chizilgan shaklni o'chirish):</h4>
<p>Agar chizilgan shaklni o'zgartirmoqchi bo'lsangiz yoki o'chirmoqchi bo'lsangiz: <code>graphics.clear()</code> metodini chaqirasiz.</p>
    `,
    code: `// Rang-barang geometrik shakllar yaratish
const app = new PIXI.Application();
await app.init({ width: 600, height: 400, backgroundColor: 0x111 });
document.body.appendChild(app.canvas);
const g = new PIXI.Graphics();
// To'q sariq dumaloq to'rtburchak
g.roundRect(50, 50, 150, 100, 15);
g.fill(0xff9f43);
g.stroke({ width: 3, color: 0xffffff });
// Ko'k aylana
g.circle(400, 150, 60);
g.fill(0x0abde3);
// Uchburchak
g.moveTo(250, 300);
g.lineTo(300, 200);
g.lineTo(350, 300);
g.closePath();
g.fill(0xee5253);
app.stage.addChild(g);`,
    mockupType: "graphics"
  },
  {
    id: 5,
    title: "5-dars: Sprite va Rasm Yuklash",
    description: "Tashqi rasmlarni PixiJS-ga yuklash, Sprite obyekti yaratish va ularni ekranda aks ettirish.",
    content: `
<h3>Sprite Nima?</h3>
<p><strong>Sprite</strong> – bu ekranda ko'rsatiladigan har qanday 2D tasvirdir (masalan, o'yin qahramoni, dushman, daraxt, yoki fon rasmi). Sprite-ning orqasida har doim <strong>Texture (Tekstura)</strong> yotadi.</p>
<h3>Assets Loader (Yuklovchi) yordamida rasmlarni yuklash</h3>
<p>PixiJS v8-da tasvirlarni yuklash uchun eng to'g'ri va xavfsiz usul – bu yangi <code>PIXI.Assets</code> tizimidir. U asinxron ishlaydi va rasm to'liq yuklanguncha kutib turadi:</p>
<pre><code class="language-javascript">// 1. Rasmni yuklab olib, tekstura yaratamiz
const texture = await PIXI.Assets.load('https://pixijs.com/assets/bunny.png');
// 2. Ushbu tekstura asosida Sprite yaratamiz
const bunny = new PIXI.Sprite(texture);
// 3. O'lchamlarini va joylashuvini o'rnatamiz
bunny.x = 100;
bunny.y = 100;
bunny.scale.set(2); // 2 barobar kattalashtirish
// 4. Sahnaga qo'shamiz
app.stage.addChild(bunny);</code></pre>
<h3>Tezkor yuklash usuli (Texture.from)</h3>
<p>Agar sizga asinxron yuklashni kutish shart bo'lmasa, quyidagi usuldan foydalanish mumkin:</p>
<pre><code class="language-javascript">// Rasm manbasidan to'g'ridan-to'g'ri Sprite yaratish
const character = PIXI.Sprite.from('assets/player.png');
character.position.set(200, 150);
app.stage.addChild(character);</code></pre>
<h3>Sprite Xususiyatlari:</h3>
<ul>
    <li><code>sprite.visible = false;</code> — Sprite-ni yashirish.</li>
    <li><code>sprite.alpha = 0.5;</code> — Shaffoflik (0 dan 1 gacha).</li>
    <li><code>sprite.tint = 0xff0000;</code> — Rasmni tus rangga bo'yash.</li>
</ul>
    `,
    code: `// Rasmni yuklash va sahnaga qo'shish namunasi
const app = new PIXI.Application();
await app.init({ width: 600, height: 400, backgroundColor: 0x2c3e50 });
document.body.appendChild(app.canvas);
// Quyoncha rasmini yuklaymiz
const bunnyTexture = await PIXI.Assets.load('https://pixijs.com/assets/bunny.png');
// 5 ta quyoncha sprite-ni har xil joyga qo'yamiz
for (let i = 0; i < 5; i++) {
    const bunny = new PIXI.Sprite(bunnyTexture);
    bunny.x = 80 + i * 100;
    bunny.y = 200;
    bunny.anchor.set(0.5);
    bunny.scale.set(1.5 + i * 0.3); // O'lcham
    bunny.alpha = 1 - (i * 0.15);    // Shaffoflik
    
    app.stage.addChild(bunny);
}`,
    mockupType: "sprites"
  },
  {
    id: 6,
    title: "6-dars: Matnlar (Text va TextStyle)",
    description: "Matnlarni ekranga chizish, shriftlarni sozlash, chiroyli gradient va soyali matn uslublarini yaratish.",
    content: `
<h3>PIXI.Text va PIXI.TextStyle</h3>
<p>PixiJS sahnasida matn ko'rsatish ikki elementdan iborat:</p>
<ol>
    <li><code>PIXI.TextStyle</code> — Matn ko'rinishini belgilaydigan sozlamalar.</li>
    <li><code>PIXI.Text</code> — Matn tarkibini va uslubini ekranga chizuvchi obyekt.</li>
</ol>
<h3>Uslub berilgan professional matn yaratish:</h3>
<pre><code class="language-javascript">const style = new PIXI.TextStyle({
    fontFamily: 'Arial',          // Shrift turi
    fontSize: 36,                 // Shrift o'lchami (px)
    fontWeight: 'bold',           // Qalin matn
    fill: ['#ffffff', '#00ff99'], // Gradient ranglar
    stroke: '#4a1850',            // Harflar chegarasi rangi
    strokeThickness: 5,           // Chegara qalinligi
    dropShadow: true,             // Soya qo'shish
    dropShadowColor: '#000000',   // Soya rangi
    dropShadowBlur: 4,            // Soyaning tarqalishi
    dropShadowAngle: Math.PI / 6, // Soya burchagi
    dropShadowDistance: 6,        // Soya uzoqligi
});
const richText = new PIXI.Text({
    text: 'PixiJS-da chiroyli gradient matn!',
    style: style
});
richText.x = 50;
richText.y = 150;
app.stage.addChild(richText);</code></pre>
<h3>Matn mazmunini dinamik o'zgartirish</h3>
<p>O'yin davomida ochko yoki soniyalarni yangilab turish uchun:</p>
<pre><code class="language-javascript">let score = 0;
const scoreText = new PIXI.Text({ text: 'Ochkolar: ' + score });
app.stage.addChild(scoreText);
// Yangilash
score += 10;
scoreText.text = 'Ochkolar: ' + score;</code></pre>
    `,
    code: `// Gradient va soyali matn yaratish
const app = new PIXI.Application();
await app.init({ width: 600, height: 400, backgroundColor: 0x111116 });
document.body.appendChild(app.canvas);
const textStyle = new PIXI.TextStyle({
    fontFamily: 'Impact, sans-serif',
    fontSize: 48,
    fill: ['#ff9900', '#ff5500'],
    stroke: '#ffffff',
    strokeThickness: 3,
    dropShadow: true,
    dropShadowColor: '#ff0000',
    dropShadowBlur: 10,
    dropShadowDistance: 0,
    letterSpacing: 2
});
const myText = new PIXI.Text({
    text: 'PIXIJS DARS',
    style: textStyle
});
myText.anchor.set(0.5);
myText.position.set(300, 200);
app.stage.addChild(myText);`,
    mockupType: "texts"
  },
  {
    id: 7,
    title: "7-dars: Konteynerlar (Containers)",
    description: "Konteynerlar yordamida sahna obyektlarini guruhlash va murakkab kompozitsiyalar yaratish.",
    content: `
<h3>Container Nima?</h3>
<p><strong>Container</strong> – bu ko'rinmas quti bo'lib, o'z ichiga boshqa obyektlarni jamlay oladi. Konteynerni siljitsangiz, uning ichidagi barcha obyektlar ham birgalikda siljiydi.</p>
<h3>Konteyner yaratish va element qo'shish</h3>
<pre><code class="language-javascript">// 1. Konteyner yaratamiz
const myContainer = new PIXI.Container();
// 2. Unga bir nechta obyekt qo'shamiz
const sprite1 = PIXI.Sprite.from('assets/part1.png');
sprite1.x = 0;
sprite1.y = 0;
const sprite2 = PIXI.Sprite.from('assets/part2.png');
sprite2.x = 50; 
sprite2.y = 50;
myContainer.addChild(sprite1);
myContainer.addChild(sprite2);
// 3. Konteynerni o'zini sahna (stage)-ga qo'shamiz
app.stage.addChild(myContainer);
// 4. Konteyner joylashuvini o'zgartiramiz
myContainer.x = 300;
myContainer.y = 200;</code></pre>
<h3>Konteynerning xususiyatlari:</h3>
<ul>
    <li>Oila munosabati: Konteyner siljisa, kattalashsa yoki burilsa, uning barcha ichki elementlari ham o'z mutanosibligini saqlab, birgalikda o'zgaradi.</li>
    <li><code>container.removeChild(child)</code> — Obyektni konteynerdan o'chirish.</li>
    <li><code>container.removeChildren()</code> — Konteyner ichini to'liq tozalash.</li>
</ul>
    `,
    code: `// Konteyner guruhlash namunasi
const app = new PIXI.Application();
await app.init({ width: 600, height: 400, backgroundColor: 0x111 });
document.body.appendChild(app.canvas);
// O'rmon konteyneri
const forest = new PIXI.Container();
forest.position.set(100, 100);
// Daraxt shakllari
for (let i = 0; i < 3; i++) {
    const tree = new PIXI.Graphics();
    
    // Tana
    tree.rect(i * 120 + 20, 80, 20, 60);
    tree.fill(0x8B4513);
    
    // Barglar
    tree.circle(i * 120 + 30, 70, 40);
    tree.fill(0x228B22);
    
    forest.addChild(tree);
}
app.stage.addChild(forest);
forest.scale.set(1.2);`,
    mockupType: "containers"
  },
  {
    id: 8,
    title: "8-dars: Animatsiya va Ticker",
    description: "Ticker orqali o'yin siklini (Game Loop) tashkil etish va obyektlarni uzluksiz harakatlantirish.",
    content: `
<h3>O'yin Sikli (Game Loop) nima?</h3>
<p>PixiJS-da uzluksiz animatsiyalarni amalga oshirish uchun <strong>Ticker</strong> obyekti ishlatiladi. Ticker soniyasiga 60 marta (60 FPS) ishlaydi.</p>
<h3>Ticker-dan foydalanish usuli:</h3>
<pre><code class="language-javascript">// app.ticker orqali funksiyani o'yin sikliga qo'shamiz
app.ticker.add((ticker) => {
    // Ushbu kod doimiy chaqiriladi
    // 'ticker.deltaTime' - o'tgan kadrlar orasidagi vaqt farqi
    
    sprite.rotation += 0.02 * ticker.deltaTime;
    sprite.x += 1 * ticker.deltaTime;
});</code></pre>
<h3>Delta Time ahamiyati</h3>
<p>Delta time (<code>ticker.deltaTime</code>) turli xil kompyuterlarda o'yin tezligi har xil bo'lib ketmasligini ta'minlaydi (masalan, kadrlar soni qotib tushganda, delta time kattalashadi va obyekt tezroq harakatlanadi).</p>
    `,
    code: `// Ticker animatsiyasi
const app = new PIXI.Application();
await app.init({ width: 600, height: 400, backgroundColor: 0x1e272e });
document.body.appendChild(app.canvas);
const box = new PIXI.Graphics();
box.rect(-25, -25, 50, 50);
box.fill(0xffdd59);
box.position.set(300, 200);
app.stage.addChild(box);
let speed = 2;
app.ticker.add((ticker) => {
    box.rotation += 0.03 * ticker.deltaTime;
    box.x += speed * ticker.deltaTime;
    
    if (box.x > 500 || box.x < 100) {
        speed = -speed; // Yo'nalishni qaytarish
    }
});`,
    mockupType: "ticker"
  },
  {
    id: 9,
    title: "9-dars: Interaktivlik va Hodisalar",
    description: "Sichqoncha va sensorli bosishlar bilan ishlash, obyektlarni bosiladigan tugmalarga aylantirish.",
    content: `
<h3>PixiJS-da Interaktivlik</h3>
<p>Grafik obyektlarni sichqoncha va sensorli hodisalarga javob beradigan qilish uchun:</p>
<ol>
    <li>Obyektning <code>eventMode</code> xususiyatini <code>'static'</code> rejimiga sozlash kerak.</li>
    <li>Obyekt ustiga kelganda ko'rsatkich qo'lcha ko'rinishiga o'tishi uchun: <code>sprite.cursor = 'pointer';</code> yoziladi.</li>
</ol>
<h3>Eng ko'p ishlatiladigan hodisalar:</h3>
<ul>
    <li><code>'pointerdown'</code> — Sichqoncha bosilganda yoki ekranga barmoq tekkanda.</li>
    <li><code>'pointerup'</code> — Bosish tugatilganda.</li>
    <li><code>'pointerover'</code> — Sichqoncha ustiga kelganda (hover).</li>
    <li><code>'pointerout'</code> — Sichqoncha tark etganda.</li>
</ul>
<h3>Kodni yozish:</h3>
<pre><code class="language-javascript">const button = new PIXI.Graphics();
button.rect(0, 0, 150, 50);
button.fill(0x3498db);
button.eventMode = 'static';
button.cursor = 'pointer';
button.on('pointerdown', () => {
    button.tint = 0x2980b9; // Bosilgandagi rang tusi
    console.log("Kliklandi!");
});
app.stage.addChild(button);</code></pre>
    `,
    code: `// Tugma yaratish va interaktivlik
const app = new PIXI.Application();
await app.init({ width: 600, height: 400, backgroundColor: 0xf5f6fa });
document.body.appendChild(app.canvas);
const btn = new PIXI.Graphics();
btn.circle(300, 200, 60);
btn.fill(0x4cd137);
btn.stroke({ width: 4, color: 0xffffff });
btn.eventMode = 'static';
btn.cursor = 'pointer';
btn.on('pointerover', () => btn.tint = 0xdcdde1);
btn.on('pointerout', () => btn.tint = 0xffffff);
btn.on('pointerdown', () => btn.scale.set(0.9));
btn.on('pointerup', () => btn.scale.set(1.0));
btn.on('pointerupoutside', () => btn.scale.set(1.0));
app.stage.addChild(btn);`,
    mockupType: "events"
  },
  {
    id: 10,
    title: "10-dars: Maskalash va Filtrlar",
    description: "Rasmlarni shakl ichiga qirqib joylashtirish (Masking) va vizual effektlarni (Filters) ishlatish.",
    content: `
<h3>Maskalash (Masking)</h3>
<p>Maskalash orqali grafik obyektning faqat belgilangan shakl (maska) ichidagi qismigina ekranda ko'rsatiladi. Burchaklarni yumaloqlash yoki tasvirlarni qirqib olish uchun ishlatiladi.</p>
<pre><code class="language-javascript">// 1. Sprite yaratish
const photo = PIXI.Sprite.from('assets/avatar.jpg');
// 2. Maska shakli
const maskCircle = new PIXI.Graphics();
maskCircle.circle(100, 100, 50);
maskCircle.fill(0xffffff);
app.stage.addChild(maskCircle);
// 3. Maska bog'lash
photo.mask = maskCircle;</code></pre>
<h3>Filtrlar (Filters)</h3>
<p>PixiJS-da tayyor shader effektlarni qo'llash juda oson:</p>
<pre><code class="language-javascript">// Blur (xiralashtirish) filtri
const blurFilter = new PIXI.BlurFilter();
blurFilter.blur = 10;
// Filtrni obyektga qo'llash (massiv shaklida)
mySprite.filters = [blurFilter];</code></pre>
    `,
    code: `// Blur va Maska namunasi
const app = new PIXI.Application();
await app.init({ width: 600, height: 400, backgroundColor: 0x222 });
document.body.appendChild(app.canvas);
const gMask = new PIXI.Graphics();
gMask.circle(300, 200, 100);
gMask.fill(0xffffff);
app.stage.addChild(gMask);
const bg = new PIXI.Graphics();
bg.rect(100, 50, 400, 300);
bg.fill(0x341f97);
app.stage.addChild(bg);
bg.mask = gMask;
const blur = new PIXI.BlurFilter();
blur.blur = 5;
bg.filters = [blur];`,
    mockupType: "filters"
  },
  {
    id: 11,
    title: "11-dars: Kosmik Otishma O'yini",
    description: "O'rgangan barcha bilimlarimizni jamlab, noldan tayyor o'yin kodini yozamiz. Klaviatura orqali boshqarish va to'qnashuvlar.",
    content: `
<h3>Katta Loyiha: Kosmik Otishma O'yini</h3>
<p>Bu o'yin klaviaturadagi <strong>Chap/O'ng (Arrow keys)</strong> tugmalari yordamida kemani boshqarish va <strong>Probel (Space)</strong> orqali o'q otishga asoslangan.</p>
<p>Kodni nusxalab olib, HTML fayl sifatida saqlashingiz va brauzerda ochib o'ynashingiz mumkin. Barcha obyektlar (kema, o'q, dushmanlar) <code>PIXI.Graphics</code> yordamida chizilgan, shuning uchun hech qanday rasm fayli yuklash talab qilinmaydi va CORS xatosi kelib chiqmaydi!</p>
    `,
    code: `<!DOCTYPE html>
<html>
<head>
    <script src="https://pixijs.download/v8.2.6/pixi.min.js"></script>
</head>
<body>
    <script>
        const app = new PIXI.Application();
        
        async function start() {
            await app.init({ width: 600, height: 600, backgroundColor: 0x0c0c1e });
            document.body.appendChild(app.canvas);
            // Kema
            const player = new PIXI.Graphics();
            player.moveTo(0, -20).lineTo(15, 15).lineTo(-15, 15).closePath().fill(0x00ffcc);
            player.position.set(300, 520);
            app.stage.addChild(player);
            const keys = {};
            const bullets = [];
            const enemies = [];
            let score = 0;
            const scoreText = new PIXI.Text({ text: 'Score: 0', style: { fill: '#fff', fontSize: 18 } });
            app.stage.addChild(scoreText);
            window.addEventListener('keydown', e => keys[e.code] = true);
            window.addEventListener('keyup', e => keys[e.code] = false);
            window.addEventListener('keydown', e => {
                if (e.code === 'Space') {
                    const bullet = new PIXI.Graphics().rect(-2, -8, 4, 12).fill(0xffcc00);
                    bullet.position.set(player.x, player.y - 15);
                    app.stage.addChild(bullet);
                    bullets.push(bullet);
                }
            });
            setInterval(() => {
                const enemy = new PIXI.Graphics().rect(-15, -15, 30, 30).fill(0xff3366);
                enemy.position.set(Math.random() * 560 + 20, -20);
                app.stage.addChild(enemy);
                enemies.push(enemy);
            }, 1000);
            app.ticker.add((ticker) => {
                if (keys['ArrowLeft'] && player.x > 20) player.x -= 4 * ticker.deltaTime;
                if (keys['ArrowRight'] && player.x < 580) player.x += 4 * ticker.deltaTime;
                bullets.forEach((b, bIdx) => {
                    b.y -= 7 * ticker.deltaTime;
                    if (b.y < -20) {
                        app.stage.removeChild(b);
                        bullets.splice(bIdx, 1);
                    }
                });
                enemies.forEach((e, eIdx) => {
                    e.y += 2.5 * ticker.deltaTime;
                    if (e.y > 620) {
                        app.stage.removeChild(e);
                        enemies.splice(eIdx, 1);
                    }
                    // Kema bilan to'qnashuv
                    if (Math.abs(player.x - e.x) < 30 && Math.abs(player.y - e.y) < 30) {
                        alert("Game Over! Score: " + score);
                        location.reload();
                    }
                    // O'qlar bilan to'qnashuv
                    bullets.forEach((b, bIdx) => {
                        if (Math.abs(b.x - e.x) < 20 && Math.abs(b.y - e.y) < 20) {
                            app.stage.removeChild(e);
                            app.stage.removeChild(b);
                            enemies.splice(eIdx, 1);
                            bullets.splice(bIdx, 1);
                            score += 10;
                            scoreText.text = 'Score: ' + score;
                        }
                    });
                });
            });
        }
        start();
    </script>
</body>
</html>`,
    mockupType: "game"
  },
  {
    id: 12,
    title: "12-dars: Optimallashtirish va Xatoliklar",
    description: "PixiJS ilovangizda kadrlar soni (FPS) tushib ketishining oldini olish va eng ko'p uchraydigan CORS xatolarini tuzatish.",
    content: `
<h3>1. CORS Xatoligi (Rasm yuklanmay qolishi)</h3>
<p>Agar siz rasmlarni o'z kompyuteringizdan (<code>file:///C:/...</code>) yuklasangiz, brauzer havfsizlik yuzasidan buni bloklaydi va konsolda CORS xatoligi ko'rinadi.</p>
<p><strong>Yechim:</strong> Rasmlarni internetdagi havfsiz serverga yuklab havola berish (masalan, <code>https://pixijs.com/assets/...</code>) yoki mahalliy veb-server (Live Server) ishga tushirish.</p>
<h3>2. Minglab zarralar uchun: ParticleContainer</h3>
<p>Agar ekranga 10 000 ta qor parchasi yoki o'q chizmoqchi bo'lsangiz, oddiy Container o'rniga <strong>ParticleContainer</strong> ishlatish zarur:</p>
<pre><code class="language-javascript">const particles = new PIXI.ParticleContainer(10000, {
    scale: true,
    position: true,
    rotation: true,
    alpha: true
});
app.stage.addChild(particles);</code></pre>
<h3>3. Xotirani tozalash</h3>
<p>Sahnadan obyektlarni <code>removeChild</code> qilish grafik xotirani butunlay tozalamaydi. Xotirani tejash uchun ularni butunlay o'chiring:</p>
<pre><code class="language-javascript">sprite.destroy({ children: true, texture: true });</code></pre>
    `,
    code: `// Xotirani to'g'ri tozalash namunasi
function cleanUpElement(element) {
    app.stage.removeChild(element);
    
    // Obyekt va unga bog'liq rasmlarni VRAM dan o'chirish
    element.destroy({
        children: true, 
        texture: true
    });
}`,
    mockupType: "optimization"
  }
];
