const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
canvas.width = 1200;
canvas.height = 800;

const objCountEl = document.getElementById('objCount');
const fpsEl = document.getElementById('fps');

// Settings
const GRAVITY = 1.5;
const RESTITUTION = 0.2; // Bounciness reduced
const FRICTION = 0.1; // Friction increased
const ANGULAR_DAMPING = 1.0; // Remove artificial damping
const LINEAR_DAMPING = 1.0;
const CELL_SIZE = 100; // Size of spatial hash grid cells

// Math Vector2
class Vec2 {
    constructor(x = 0, y = 0) { this.x = x; this.y = y; }
    add(v) { return new Vec2(this.x + v.x, this.y + v.y); }
    sub(v) { return new Vec2(this.x - v.x, this.y - v.y); }
    mult(s) { return new Vec2(this.x * s, this.y * s); }
    dot(v) { return this.x * v.x + this.y * v.y; }
    cross(v) { return this.x * v.y - this.y * v.x; }
    magSq() { return this.x * this.x + this.y * this.y; }
    mag() { return Math.sqrt(this.magSq()); }
    normalize() {
        let len = this.mag();
        if (len > 0) { this.x /= len; this.y /= len; }
        return this;
    }
    normal() { return new Vec2(-this.y, this.x).normalize(); }
    copy() { return new Vec2(this.x, this.y); }
}

function crossScalar(s, v) { return new Vec2(-s * v.y, s * v.x); }
function crossVec(v, s) { return new Vec2(s * v.y, -s * v.x); }
function clamp(val, min, max) { return Math.max(min, Math.min(max, val)); }

// Rotational Matrix
class Mat2 {
    constructor(angle) {
        let c = Math.cos(angle), s = Math.sin(angle);
        this.m00 = c; this.m01 = -s;
        this.m10 = s; this.m11 = c;
    }
    mul(v) { return new Vec2(this.m00 * v.x + this.m01 * v.y, this.m10 * v.x + this.m11 * v.y); }
    transposeMul(v) { return new Vec2(this.m00 * v.x + this.m10 * v.y, this.m01 * v.x + this.m11 * v.y); }
}

// Bodies
const BODIES = [];

class Body {
    constructor(x, y, m) {
        this.pos = new Vec2(x, y);
        this.vel = new Vec2(0, 0);
        this.angle = 0;
        this.angVel = 0;
        this.force = new Vec2(0, 0);
        this.torque = 0;
        
        this.mass = m;
        this.invMass = m === 0 ? 0 : 1 / m;
        this.inertia = 0;
        this.invInertia = 0;
        
        this.type = "body"; // "circle" or "box"
        this.color = `hsl(${Math.random()*360}, 70%, 60%)`;
        this.bounds = { minX: 0, minY: 0, maxX: 0, maxY: 0 };
        BODIES.push(this);
    }
    
    update(dt) {
        if (this.invMass === 0) return; // Static body
        
        // Add gravity
        this.force.y += this.mass * GRAVITY * 60; 

        // Integrate velocity
        this.vel = this.vel.add(this.force.mult(this.invMass * dt));
        this.angVel += this.torque * this.invInertia * dt;
        
        // Damping
        this.vel = this.vel.mult(LINEAR_DAMPING);
        this.angVel *= ANGULAR_DAMPING;

        // Integrate position
        this.pos = this.pos.add(this.vel.mult(dt));
        this.angle += this.angVel * dt;

        this.force = new Vec2(0, 0);
        this.torque = 0;
        
        this.updateAABB();
    }
    updateAABB() {}
    draw(ctx) {}
}

class Circle extends Body {
    constructor(x, y, r, m) {
        super(x, y, m);
        this.type = "circle";
        this.r = r;
        if (m !== 0) {
            this.inertia = 0.5 * m * r * r;
            this.invInertia = 1 / this.inertia;
        }
        this.updateAABB();
    }
    updateAABB() {
        this.bounds.minX = this.pos.x - this.r;
        this.bounds.minY = this.pos.y - this.r;
        this.bounds.maxX = this.pos.x + this.r;
        this.bounds.maxY = this.pos.y + this.r;
    }
    draw(ctx) {
        ctx.beginPath();
        ctx.arc(this.pos.x, this.pos.y, this.r, 0, Math.PI * 2);
        ctx.fillStyle = this.color;
        ctx.fill();
        ctx.stroke();
        // Line to show rotation
        ctx.beginPath();
        ctx.moveTo(this.pos.x, this.pos.y);
        ctx.lineTo(this.pos.x + Math.cos(this.angle) * this.r, this.pos.y + Math.sin(this.angle) * this.r);
        ctx.stroke();
    }
}

class Box extends Body {
    constructor(x, y, w, h, m) {
        super(x, y, m);
        this.type = "box";
        this.hw = w / 2; // half-width
        this.hh = h / 2; // half-height
        if (m !== 0) {
            this.inertia = (m * (w * w + h * h)) / 12;
            this.invInertia = 1 / this.inertia;
        }
        this.updateAABB();
    }
    getVertices() {
        let mat = new Mat2(this.angle);
        let v1 = this.pos.add(mat.mul(new Vec2(-this.hw, -this.hh)));
        let v2 = this.pos.add(mat.mul(new Vec2(this.hw, -this.hh)));
        let v3 = this.pos.add(mat.mul(new Vec2(this.hw, this.hh)));
        let v4 = this.pos.add(mat.mul(new Vec2(-this.hw, this.hh)));
        return [v1, v2, v3, v4];
    }
    updateAABB() {
        let maxRadius = Math.sqrt(this.hw * this.hw + this.hh * this.hh);
        this.bounds.minX = this.pos.x - maxRadius;
        this.bounds.minY = this.pos.y - maxRadius;
        this.bounds.maxX = this.pos.x + maxRadius;
        this.bounds.maxY = this.pos.y + maxRadius;
    }
    draw(ctx) {
        ctx.save();
        ctx.translate(this.pos.x, this.pos.y);
        ctx.rotate(this.angle);
        ctx.fillStyle = this.color;
        ctx.fillRect(-this.hw, -this.hh, this.hw * 2, this.hh * 2);
        ctx.strokeRect(-this.hw, -this.hh, this.hw * 2, this.hh * 2);
        ctx.restore();
    }
}

// Spatial Hash for Broad-phase (The secret to running 500+ objects smoothly)
class SpatialHash {
    constructor(cellSize) {
        this.cellSize = cellSize;
        this.grid = new Map();
    }
    clear() { this.grid.clear(); }
    insert(body) {
        const minCellX = Math.floor(body.bounds.minX / this.cellSize);
        const minCellY = Math.floor(body.bounds.minY / this.cellSize);
        const maxCellX = Math.floor(body.bounds.maxX / this.cellSize);
        const maxCellY = Math.floor(body.bounds.maxY / this.cellSize);
        for (let y = minCellY; y <= maxCellY; y++) {
            for (let x = minCellX; x <= maxCellX; x++) {
                const key = `${x},${y}`;
                if (!this.grid.has(key)) this.grid.set(key, []);
                this.grid.get(key).push(body);
            }
        }
    }
    getPairs() {
        const pairs = new Set();
        for (let [key, cell] of this.grid.entries()) {
            for (let i = 0; i < cell.length; i++) {
                for (let j = i + 1; j < cell.length; j++) {
                    let idA = BODIES.indexOf(cell[i]);
                    let idB = BODIES.indexOf(cell[j]);
                    let pairId = idA < idB ? `${idA}-${idB}` : `${idB}-${idA}`;
                    pairs.add(pairId);
                }
            }
        }
        return Array.from(pairs).map(pair => {
            let [a, b] = pair.split('-');
            return [BODIES[parseInt(a)], BODIES[parseInt(b)]];
        });
    }
}

// Collision Manifold
class Manifold {
    constructor(a, b) {
        this.a = a;
        this.b = b;
        this.normal = new Vec2(0, 1);
        this.penetration = 0;
        this.contact = new Vec2(0, 0);
    }
}

// Narrow-phase Collision Detection
function collideCircleCircle(m) {
    let a = m.a, b = m.b;
    let n = b.pos.sub(a.pos);
    let distSq = n.magSq();
    let radiusSum = a.r + b.r;
    if (distSq >= radiusSum * radiusSum) return false;
    
    let dist = Math.sqrt(distSq);
    if (dist === 0) {
        m.penetration = a.r;
        m.normal = new Vec2(1, 0);
        m.contact = a.pos;
    } else {
        m.penetration = radiusSum - dist;
        m.normal = n.mult(1 / dist); // normalize
        m.contact = a.pos.add(m.normal.mult(a.r - m.penetration/2));
    }
    return true;
}

function collideBoxBox(m) {
    let a = m.a, b = m.b;
    let n = b.pos.sub(a.pos);
    let matA = new Mat2(a.angle);
    let matB = new Mat2(b.angle);
    
    // Convert to A's local space
    let nA = matA.transposeMul(n);
    // Find half extents sum in A's space
    let faceA = new Vec2(Math.abs(matA.transposeMul(matB.mul(new Vec2(1,0))).x) * b.hw + Math.abs(matA.transposeMul(matB.mul(new Vec2(0,1))).x) * b.hh,
                         Math.abs(matA.transposeMul(matB.mul(new Vec2(1,0))).y) * b.hw + Math.abs(matA.transposeMul(matB.mul(new Vec2(0,1))).y) * b.hh);
    let overlapX = a.hw + faceA.x - Math.abs(nA.x);
    if (overlapX <= 0) return false;
    let overlapY = a.hh + faceA.y - Math.abs(nA.y);
    if (overlapY <= 0) return false;

    // Convert to B's local space
    let nB = matB.transposeMul(n.mult(-1));
    let faceB = new Vec2(Math.abs(matB.transposeMul(matA.mul(new Vec2(1,0))).x) * a.hw + Math.abs(matB.transposeMul(matA.mul(new Vec2(0,1))).x) * a.hh,
                         Math.abs(matB.transposeMul(matA.mul(new Vec2(1,0))).y) * a.hw + Math.abs(matB.transposeMul(matA.mul(new Vec2(0,1))).y) * a.hh);
    let overlapBX = b.hw + faceB.x - Math.abs(nB.x);
    if (overlapBX <= 0) return false;
    let overlapBY = b.hh + faceB.y - Math.abs(nB.y);
    if (overlapBY <= 0) return false;

    // Find axis of least penetration
    let minOverlap = Math.min(overlapX, overlapY, overlapBX, overlapBY);
    if (minOverlap === overlapX) {
        m.normal = matA.mul(new Vec2(nA.x > 0 ? 1 : -1, 0));
        m.penetration = overlapX;
    } else if (minOverlap === overlapY) {
        m.normal = matA.mul(new Vec2(0, nA.y > 0 ? 1 : -1));
        m.penetration = overlapY;
    } else if (minOverlap === overlapBX) {
        m.normal = matB.mul(new Vec2(nB.x > 0 ? -1 : 1, 0));
        m.penetration = overlapBX;
    } else {
        m.normal = matB.mul(new Vec2(0, nB.y > 0 ? -1 : 1));
        m.penetration = overlapBY;
    }
    
    // Calculate precise contact point by finding overlapping vertices
    let contacts = [];
    let vertsA = a.getVertices();
    for (let v of vertsA) {
        let localV = matB.transposeMul(v.sub(b.pos));
        if (Math.abs(localV.x) <= b.hw + 0.01 && Math.abs(localV.y) <= b.hh + 0.01) {
            contacts.push(v);
        }
    }
    let vertsB = b.getVertices();
    for (let v of vertsB) {
        let localV = matA.transposeMul(v.sub(a.pos));
        if (Math.abs(localV.x) <= a.hw + 0.01 && Math.abs(localV.y) <= a.hh + 0.01) {
            contacts.push(v);
        }
    }
    
    if (contacts.length > 0) {
        let sum = new Vec2(0, 0);
        for (let c of contacts) sum = sum.add(c);
        m.contact = sum.mult(1 / contacts.length);
    } else {
        m.contact = a.pos.add(b.pos).mult(0.5); // Fallback
    }
    
    return true;
}

function collideCircleBox(m, isReversed) {
    let circle = isReversed ? m.b : m.a;
    let box = isReversed ? m.a : m.b;
    
    let n = circle.pos.sub(box.pos);
    let matBox = new Mat2(box.angle);
    
    // Convert circle center to box's local space
    let localCirclePos = matBox.transposeMul(n);
    
    // Find closest point on box
    let closestX = clamp(localCirclePos.x, -box.hw, box.hw);
    let closestY = clamp(localCirclePos.y, -box.hh, box.hh);
    
    let isInside = false;
    if (Math.abs(localCirclePos.x) < box.hw && Math.abs(localCirclePos.y) < box.hh) {
        isInside = true;
        // Clamp to closest edge
        if (Math.abs(localCirclePos.x) > Math.abs(localCirclePos.y)) {
            closestX = closestX > 0 ? box.hw : -box.hw;
        } else {
            closestY = closestY > 0 ? box.hh : -box.hh;
        }
    }
    
    let closestPt = new Vec2(closestX, closestY);
    let distVec = localCirclePos.sub(closestPt);
    let distSq = distVec.magSq();
    
    if (!isInside && distSq > circle.r * circle.r) return false;
    
    let dist = Math.sqrt(distSq);
    let localNormal;
    
    if (isInside) {
        localNormal = distVec.mult(-1).normalize();
        m.penetration = circle.r + dist;
    } else {
        localNormal = distVec.normalize();
        m.penetration = circle.r - dist;
    }
    
    let globalNormal = matBox.mul(localNormal);
    m.normal = isReversed ? globalNormal : globalNormal.mult(-1);
    m.contact = box.pos.add(matBox.mul(closestPt));
    return true;
}

// Apply Physics Impulses
function resolveCollision(m) {
    let a = m.a, b = m.b;
    
    // Positional correction (Prevent sinking)
    const percent = 0.8; // 20-80%
    const slop = 0.05; // allow small penetration
    let correction = m.normal.mult(Math.max(m.penetration - slop, 0) / (a.invMass + b.invMass) * percent);
    a.pos = a.pos.sub(correction.mult(a.invMass));
    b.pos = b.pos.add(correction.mult(b.invMass));
    
    // Velocities at contact
    let rA = m.contact.sub(a.pos);
    let rB = m.contact.sub(b.pos);
    
    let rvA = a.vel.add(crossScalar(a.angVel, rA));
    let rvB = b.vel.add(crossScalar(b.angVel, rB));
    let rv = rvB.sub(rvA); // Relative velocity
    
    let velAlongNormal = rv.dot(m.normal);
    if (velAlongNormal > 0) return; // Moving apart
    
    let e = Math.min(RESTITUTION, RESTITUTION);
    
    let rA_cross_n = rA.cross(m.normal);
    let rB_cross_n = rB.cross(m.normal);
    
    let invMassSum = a.invMass + b.invMass + (rA_cross_n*rA_cross_n)*a.invInertia + (rB_cross_n*rB_cross_n)*b.invInertia;
    
    let j = -(1 + e) * velAlongNormal / invMassSum;
    let impulse = m.normal.mult(j);
    
    // Apply Normal Impulse
    a.vel = a.vel.sub(impulse.mult(a.invMass));
    b.vel = b.vel.add(impulse.mult(b.invMass));
    a.angVel -= rA_cross_n * j * a.invInertia;
    b.angVel += rB_cross_n * j * b.invInertia;
    
    // Friction (Tangential) Impulse
    rvA = a.vel.add(crossScalar(a.angVel, rA));
    rvB = b.vel.add(crossScalar(b.angVel, rB));
    rv = rvB.sub(rvA);
    
    let tangent = rv.sub(m.normal.mult(rv.dot(m.normal)));
    if (tangent.magSq() > 0.0001) {
        tangent.normalize();
        
        let jt = -rv.dot(tangent);
        let rA_cross_t = rA.cross(tangent);
        let rB_cross_t = rB.cross(tangent);
        let invMassSumT = a.invMass + b.invMass + (rA_cross_t*rA_cross_t)*a.invInertia + (rB_cross_t*rB_cross_t)*b.invInertia;
        jt = jt / invMassSumT;
        
        // Coulomb friction
        let frictionImpulse;
        if (Math.abs(jt) < j * FRICTION) {
            frictionImpulse = tangent.mult(jt);
        } else {
            frictionImpulse = tangent.mult(-j * FRICTION);
        }
        
        a.vel = a.vel.sub(frictionImpulse.mult(a.invMass));
        b.vel = b.vel.add(frictionImpulse.mult(b.invMass));
        a.angVel -= rA.cross(frictionImpulse) * a.invInertia;
        b.angVel += rB.cross(frictionImpulse) * b.invInertia;
    }
}

// Add Boundary Walls
const padding = 50;
let walls = [
    new Box(canvas.width/2, canvas.height + padding, canvas.width*2, padding*2, 0), // Floor
    new Box(-padding, canvas.height/2, padding*2, canvas.height*2, 0), // Left
    new Box(canvas.width + padding, canvas.height/2, padding*2, canvas.height*2, 0), // Right
];
walls.forEach(w => w.color = "#555");

// Broadphase spatial grid
const grid = new SpatialHash(CELL_SIZE);

// Game Loop
let lastTime = 0;
let frameCount = 0;
let lastFpsTime = 0;

function loop(time) {
    let dt = 1/60; // Fixed timestep for stability
    
    // Calculate FPS
    frameCount++;
    if (time - lastFpsTime >= 1000) {
        fpsEl.innerText = frameCount;
        frameCount = 0;
        lastFpsTime = time;
    }
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    const subSteps = 8;
    const subDt = dt / subSteps;
    
    for(let step = 0; step < subSteps; step++) {
        // Broadphase insertion
        grid.clear();
        for (let body of BODIES) {
            body.update(subDt);
            grid.insert(body);
        }
        
        // Retrieve potential collision pairs and test
        let pairs = grid.getPairs();
        for (let pair of pairs) {
            let [a, b] = pair;
            if (a.invMass === 0 && b.invMass === 0) continue; // Two static bodies don't collide
            
            let m = new Manifold(a, b);
            let hasCollision = false;
            
            if (a.type === "circle" && b.type === "circle") {
                hasCollision = collideCircleCircle(m);
            } else if (a.type === "box" && b.type === "box") {
                hasCollision = collideBoxBox(m);
            } else if (a.type === "circle" && b.type === "box") {
                hasCollision = collideCircleBox(m, false);
            } else if (a.type === "box" && b.type === "circle") {
                hasCollision = collideCircleBox(m, true);
            }
            
            if (hasCollision) {
                resolveCollision(m);
            }
        }
    }
    
    // Draw
    for (let body of BODIES) {
        body.draw(ctx);
    }
    
    objCountEl.innerText = BODIES.length;
    requestAnimationFrame(loop);
}

// User Interaction (Spawn bodies)
let isSpawning = false;
function spawnRandom() {
    let x = Math.random() * (canvas.width - 100) + 50;
    let y = Math.random() * 200 + 50;
    let size = Math.random() * 20 + 10;
    let mass = size;
    
    if (Math.random() > 0.5) {
        new Circle(x, y, size, mass);
    } else {
        new Box(x, y, size * 2, size * 2, mass);
    }
}

window.addEventListener('mousedown', () => isSpawning = true);
window.addEventListener('mouseup', () => isSpawning = false);
window.addEventListener('mousemove', (e) => {
    if (isSpawning) {
        if (Math.random() > 0.7) { // limit spawn rate slightly
            let size = Math.random() * 15 + 10;
            if (Math.random() > 0.5) new Circle(e.clientX, e.clientY, size, size);
            else new Box(e.clientX, e.clientY, size*1.5, size*1.5, size);
        }
    }
});

// Spawn initial bodies
for(let i=0; i<20; i++) spawnRandom();

requestAnimationFrame(loop);
