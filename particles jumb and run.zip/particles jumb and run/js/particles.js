
class Particles {
	constructor(x, y, width, height, vx, vy, color) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.vx = vx;
		this.vy = vy;
		this.color = color;
		this.prev_number = 0.1;
		this.vy_numb = vy;
	}
	physics() {
		this.x += this.vx;
		this.y += this.vy;
	}
	update() {
		this.pos_x = this.x;
		this.pos_y = this.y;
		this.physics();
	}
	draw() {
		ctx.beginPath();
		ctx.lineWidth = 2;
		ctx.fillStyle = this.color;
		ctx.fillRect(this.x, this.y, this.width, this.height);
		ctx.closePath();
	}
}


