
function controller() {
	document.addEventListener('keydown', (e) => {
		if (e.keyCode === 32) {
			space = true;
		}
		if (e.keyCode === 37) {
			arrowLeft = true;
		}
		if (e.keyCode === 38) {
			arrowTop = true;
		}
		if (e.keyCode === 39) {
			arrowRight = true;
		}
		if (e.keyCode === 40) {
			arrowBottom = true;
		}
	});
	document.addEventListener('keyup', (e) => {
		if (e.keyCode === 32) {
			space = false;
		}
		if (e.keyCode === 37) {
			arrowLeft = false;
		}
		if (e.keyCode === 38) {
			arrowTop = false;
		}
		if (e.keyCode === 39) {
			arrowRight = false;
		}
		if (e.keyCode === 40) {
			arrowBottom = false;
		}
	});
}