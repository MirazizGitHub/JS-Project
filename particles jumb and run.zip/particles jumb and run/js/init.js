
function init() {
	objects.forEach(obj => {
		obj.physics();
		obj.draw();
	});
	player.update();
	player.control();
	player.draw();
	particles.forEach((element, index) => {
		element.update();
		element.draw();
		if (element.width >= 0) { element.width -= element.prev_number; }
		if (element.height >= 0) { element.height -= element.prev_number; }
		if (element.width < 1) {
			particles.splice(1, index);
		}
	});
}


