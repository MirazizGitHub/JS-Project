
class Player {
	constructor() {
		this.x = 100;
		this.y = 100;
		this.width = 30;
		this.height = 30;
		this.color = 'red';
		this.grav = 0.005;
		this.vel = { x: 0, y: 0 }
		this.speed = 3;
		this.jumpSeed = 3;
		this.onGround = false;
		this.vx = 3;
		this.acc_x = 0;
		this.friction = 0.5;
		this.deltaTime = 30;
		/*   */
		this.hue_color = 0;
		/*   */
	}
	physics() {
		this.hue_color += 1;
		if (this.hue_color >= 360) { this.hue_color = 0; }
		this.vel.x += this.acc_x;
		this.vel.x *= (1 - this.friction);
		this.vel.y += this.grav * this.deltaTime;
		this.x += this.vel.x;
		this.y += this.vel.y * this.speed;
		this.onGround = false;
	}
	update() {
		this.pos_x = this.x;
		this.pos_y = this.y;
		this.physics();
		/* Collision start */
		objects.forEach(obj => {
			/* Bottom collision rectangle */
			if (this.pos_y + this.height <= obj.y && overlapsWith(this, obj)) {
				this.y = (obj.y - this.height);
				this.vel.y = 0;
				this.onGround = true;
            }
            /* Top collision rectangle */
            if (this.pos_y >= obj.y + obj.height && overlapsWith(this, obj)) {
            	this.y = (obj.y + obj.height);
            	this.vel.y = 0;
            }
            /* Left collision rectangle */
            if (this.pos_x + this.width <= obj.x && overlapsWith(this, obj)) {
            	this.x = (obj.x - this.width);
            	this.vel.x = 0;
            }
            /* Right collisio rectangle */
            if (this.pos_x >= obj.x + obj.width && overlapsWith(this, obj)) {
            	this.x = (obj.x + obj.width);
            	this.vel.x = 0;
            }
		});
		/* Collision end */
		if ((this.y + this.height) >= canvas.height) {
            this.y = canvas.height - this.height;
            this.vel.y = 0;
            this.onGround = true;
        }
        if ((this.x + this.width) >= canvas.width) {
        	this.x = canvas.width - this.width;
        	this.vel.x *= -2;
        }
        if (this.x <= 0) {
        	this.x = 0;
        	this.vel.x *= -2;
        }
	}
	control() {
		/*  */
		this.parti_x = Math.random() * 1 - 0.5;
		this.parti_y = Math.random() * 1 - 0.5;
		/*  */
		if (arrowTop) {
			if (this.onGround) {
				this.vel.y -= this.jumpSeed;
				this.onGround = false;
			}
			particles.push(new Particles(this.x+(this.width/2)-5, this.y+this.height, 10,10, this.parti_x, 2, `rgb(0, 255, 0, 0.5)`));
		}
		if (arrowLeft) {
			this.acc_x = -this.vx;
			particles.push(new Particles(this.x + this.width, this.y+(this.height/2)-5, 10,10, 2, this.parti_y, `rgb(0, 0, 0, 0.5)`));
		}
		if (arrowRight) {
			this.acc_x = this.vx;
			particles.push(new Particles(this.x - 10, this.y+(this.height/2)-5, 10,10, -2, this.parti_y, `rgb(0, 0, 0, 0.5)`));
		}
		if (!arrowLeft && !arrowRight) {
			this.acc_x = 0;
		}
		/*  */
        if (space) {
			if (this.y >= 30) {
        		this.vel.y = -0.5;
			}
        	particles.push(new Particles(this.x+(this.width/2)-5, this.y+this.height, 10,10, this.parti_x, 2, `rgb(40, 0, 255, 0.5)`));
        	particles.forEach((el, index) => {
        	});
        }
        /*  */

	}
	draw() {
		ctx.beginPath();
		ctx.fillStyle = this.color;
		ctx.fillRect(this.x, this.y, this.width, this.height);
		ctx.fill();
		ctx.closePath();
	}
}


