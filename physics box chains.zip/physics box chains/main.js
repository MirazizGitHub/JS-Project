const { min, max, abs, cos, sin, sqrt, PI } = Math;

class Contact {
	constructor(world) {
		this.bA = null;
		this.bB = null;
		this.px = 0; this.py = 0;
		this.nx = 0; this.ny = 0;
		this.Pn = 0; this.Pt = 0;
		this.r1x = 0; this.r1y = 0;
		this.r2x = 0; this.r2y = 0;
		this.rvx = 0; this.rvy = 0;
		this.separation = 0;
		this.massNormal = 0;
		this.massTangent = 0;
		this.bias = 0;
		this.friction = 0;
		this.allowedPenetration = world.allowedPenetration;
		this.biasFactor = -world.biasFactor * world.invDT;
	}

	update(bA, bB, separation, nx, ny, friction, px, py) {
		this.bA = bA; this.bB = bB;
		this.separation = separation;
		this.nx = nx; this.ny = ny;
		this.Pn = 0; this.Pt = 0;
		this.friction = friction;
		this.px = px; this.py = py;

		this.r1x = px - bA.px; this.r1y = py - bA.py;
		this.r2x = px - bB.px; this.r2y = py - bB.py;

		let rn1 = this.r1x * nx + this.r1y * ny;
		let rn2 = this.r2x * nx + this.r2y * ny;
		this.massNormal = 1.0 / (
			bA.iM + bB.iM +
			bA.iI * (this.r1x * this.r1x + this.r1y * this.r1y - rn1 * rn1) +
			bB.iI * (this.r2x * this.r2x + this.r2y * this.r2y - rn2 * rn2)
		);
		let rt1 = this.r1x * ny - this.r1y * nx;
		let rt2 = this.r2x * ny - this.r2y * nx;
		this.massTangent = 1.0 / (
			bA.iM + bB.iM +
			bA.iI * (this.r1x * this.r1x + this.r1y * this.r1y - rt1 * rt1) +
			bB.iI * (this.r2x * this.r2x + this.r2y * this.r2y - rt2 * rt2)
		);
		this.bias = this.biasFactor * min(0.0, separation + this.allowedPenetration);
	}

	relativeVelocity() {
		this.rvx = this.bB.vx - this.bB.va * this.r2y - this.bA.vx + this.bA.va * this.r1y;
		this.rvy = this.bB.vy + this.bB.va * this.r2x - this.bA.vy - this.bA.va * this.r1x;
	}

	impulse(px, py) {
		this.bA.vx -= this.bA.iM * px;
		this.bA.vy -= this.bA.iM * py;
		this.bA.va -= this.bA.iI * (this.r1x * py - this.r1y * px);
		this.bB.vx += this.bB.iM * px;
		this.bB.vy += this.bB.iM * py;
		this.bB.va += this.bB.iI * (this.r2x * py - this.r2y * px);
	}

	applyImpulse() {
		let dPn, Pn0, maxPt;
		this.relativeVelocity();
		dPn = this.massNormal * (-(this.rvx * this.nx + this.rvy * this.ny) + this.bias);
		Pn0 = this.Pn;
		this.Pn = max(Pn0 + dPn, 0.0);
		dPn = this.Pn - Pn0;
		this.impulse(this.nx * dPn, this.ny * dPn);
		this.relativeVelocity();
		dPn = -this.massTangent * (this.rvx * this.ny - this.rvy * this.nx);
		maxPt = this.friction * this.Pn;
		Pn0 = this.Pt;
		this.Pt = max(-maxPt, min(Pn0 + dPn, maxPt));
		dPn = this.Pt - Pn0;
		this.impulse(this.ny * dPn, -this.nx * dPn);
	}

	draw() {
		ctx.beginPath();
		ctx.arc(this.px, this.py, 1.5, 0, 2 * PI);
		ctx.fillStyle = "#F00";
		ctx.fill();
	}
}

class Body {
	constructor(world, setup) {
		let w = setup.w || 1.0;
		let h = setup.h || 1.0;
		this.px = setup.x || 0.0;
		this.py = setup.y || 0.0;
		this.vx = setup.vx || 0.0;
		this.vy = setup.vy || 0.0;
		this.hw = w * 0.5;
		this.hh = h * 0.5;
		this.rd = sqrt(this.hw * this.hw + this.hh * this.hh);
		this.va = setup.angularVelocity || 0.0;
		this.ra = setup.rotation || 0.0;
		this.cos = cos(this.ra);
		this.sin = sin(this.ra);
		this.friction = setup.friction === undefined ? world.friction : setup.friction;
		let mass = setup.mass || Infinity;
		this.color = setup.color || "aqua";
		this.visible = setup.visible === undefined ? true : setup.visible;
		if (mass < Infinity) {
			this.iM = 1.0 / mass;
			this.iI = 1.0 / (mass * (w * w + h * h) / 12);
		} else {
			this.iM = 0.0;
			this.iI = 0.0;
		}
		this.dt = world.timeStep;
		this.gravity = setup.gravity || world.gravity;
	}

	integrate() {
		if (this.iM) {
			this.px += this.vx * this.dt;
			this.py += this.vy * this.dt;
			this.ra += this.va * this.dt;
			this.vy += this.gravity * this.dt;
			this.cos = cos(this.ra);
			this.sin = sin(this.ra);
		}
	}

	draw() {
		if (!this.visible) return;
		let chw = this.cos * this.hw, shw = this.sin * this.hw;
		let chh = this.cos * this.hh, shh = this.sin * this.hh;
		ctx.beginPath();
		ctx.moveTo(this.px - chw + shh, this.py - shw - chh);
		ctx.lineTo(this.px + chw + shh, this.py + shw - chh);
		ctx.lineTo(this.px + chw - shh, this.py + shw + chh);
		ctx.lineTo(this.px - chw - shh, this.py - shw + chh);
		ctx.closePath();
		ctx.strokeStyle = this.color;
		ctx.stroke();
	}
}

class Joint {
	constructor(world, setup) {
		this.bA = setup.b1;
		this.bB = setup.b2;
		let c, s, x, y;
		c = this.bA.cos; s = this.bA.sin;
		x = setup.ax - this.bA.px; y = setup.ay - this.bA.py;
		this.a1x = c * x + s * y;
		this.a1y = -s * x + c * y;
		c = this.bB.cos; s = this.bB.sin;
		x = setup.ax - this.bB.px; y = setup.ay - this.bB.py;
		this.a2x = c * x + s * y;
		this.a2y = -s * x + c * y;
		this.m00 = 0; this.m01 = 0; this.m11 = 0;
		this.r1x = 0; this.r1y = 0;
		this.r2x = 0; this.r2y = 0;
		this.bsx = 0; this.bsy = 0;
		this.aix = 0; this.aiy = 0;
		let bias = setup.biasFactor || world.biasFactor;
		this.biasFactor = -bias * world.invDT;
		this.softness = setup.softness || 0.0;
		this.iM = this.bA.iM + this.bB.iM + this.softness;
		this.color = setup.color || "#888";
	}

	preStep() {
		let bA = this.bA, bB = this.bB;
		this.r1x = bA.cos * this.a1x - bA.sin * this.a1y;
		this.r1y = bA.sin * this.a1x + bA.cos * this.a1y;
		this.r2x = bB.cos * this.a2x - bB.sin * this.a2y;
		this.r2y = bB.sin * this.a2x + bB.cos * this.a2y;

		let Km00 = this.iM + bA.iI * this.r1y * this.r1y + bB.iI * this.r2y * this.r2y;
		let Km01 = -bA.iI * this.r1x * this.r1y - bB.iI * this.r2x * this.r2y;
		let Km11 = this.iM + bA.iI * this.r1x * this.r1x + bB.iI * this.r2x * this.r2x;
		let det = 1.0 / (Km00 * Km11 - Km01 * Km01);
		this.m00 = det * Km11;
		this.m01 = -det * Km01;
		this.m11 = det * Km00;

		this.bsx = (bB.px + this.r2x - bA.px - this.r1x) * this.biasFactor;
		this.bsy = (bB.py + this.r2y - bA.py - this.r1y) * this.biasFactor;

		bA.vx -= this.aix * bA.iM;
		bA.vy -= this.aiy * bA.iM;
		bA.va -= bA.iI * (this.r1x * this.aiy - this.r1y * this.aix);
		bB.vx += this.aix * bB.iM;
		bB.vy += this.aiy * bB.iM;
		bB.va += bB.iI * (this.r2x * this.aiy - this.r2y * this.aix);
	}

	applyImpulse() {
		let bA = this.bA, bB = this.bB;
		let bx = this.bsx - (bB.vx - bB.va * this.r2y - bA.vx + bA.va * this.r1y) - this.aix * this.softness;
		let by = this.bsy - (bB.vy + bB.va * this.r2x - bA.vy - bA.va * this.r1x) - this.aiy * this.softness;
		let ix = this.m00 * bx + this.m01 * by;
		let iy = this.m01 * bx + this.m11 * by;
		bA.vx -= ix * bA.iM;
		bA.vy -= iy * bA.iM;
		bA.va -= bA.iI * (this.r1x * iy - this.r1y * ix);
		bB.vx += ix * bB.iM;
		bB.vy += iy * bB.iM;
		bB.va += bB.iI * (this.r2x * iy - this.r2y * ix);
		this.aix += ix;
		this.aiy += iy;
	}

	draw() {
		ctx.beginPath();
		ctx.strokeStyle = this.color;
		ctx.setLineDash([2, 2]);
		ctx.moveTo(this.bA.px, this.bA.py);
		ctx.lineTo(this.bA.px + this.r1x, this.bA.py + this.r1y);
		ctx.stroke();
		ctx.setLineDash([]);
	}
}

class World {
	constructor(setup) {
		this.gravity = setup.gravity || 50;
		this.iterations = setup.iterations || 10;
		this.timeStep = setup.timeStep || 1 / 30;
		this.invDT = 1 / this.timeStep;
		this.friction = setup.friction || 0.2;
		this.allowedPenetration = setup.allowedPenetration || 0.01;
		this.biasFactor = setup.biasFactor || 0.2;
		this.relativeTol = setup.relativeTol || 0.95;
		this.absoluteTol = setup.absoluteTol || 0.01;
		this.bodies = [];
		this.joints = [];
		this.contacts = [];
		this.numContacts = 0;
		this.maxContacts = 0;
		this.ie = [0, 0, 0, 0];
		this.c1 = [0, 0, 0, 0];
		this.c2 = [0, 0, 0, 0];
	}

	addBody(setup) {
		let body = new Body(this, setup);
		this.bodies.push(body);
		return body;
	}

	addJoint(setup) {
		let joint = new Joint(this, setup);
		this.joints.push(joint);
		return joint;
	}

	step() {
		let i, j, bi, bj, dx, dy, d;
		const bodies = this.bodies, joints = this.joints;
		const bLen = bodies.length, jLen = joints.length;

		this.numContacts = 0;

		for (i = 0; i < bLen; ++i) {
			bi = bodies[i];
			for (j = i + 1; j < bLen; ++j) {
				bj = bodies[j];
				if (bi.iM || bj.iM) {
					dx = bj.px - bi.px;
					dy = bj.py - bi.py;
					d = bi.rd + bj.rd;
					if (dx * dx + dy * dy < d * d) {
						this.collide(bi, bj, dx, dy);
					}
				}
			}
		}

		for (i = 0; i < jLen; ++i) joints[i].preStep();

		for (j = 0; j < this.iterations; ++j) {
			for (i = 0; i < this.numContacts; ++i) this.contacts[i].applyImpulse();
			for (i = 0; i < jLen; ++i) joints[i].applyImpulse();
		}

		for (i = 0; i < bLen; ++i) bodies[i].integrate();
		for (i = 0; i < jLen; ++i) joints[i].draw();
		for (i = 0; i < bLen; ++i) bodies[i].draw();
	}

	collide(bA, bB, dpx, dpy) {
		let dax = bA.cos * dpx + bA.sin * dpy;
		let day = -bA.sin * dpx + bA.cos * dpy;
		let dbx = bB.cos * dpx + bB.sin * dpy;
		let dby = -bB.sin * dpx + bB.cos * dpy;

		let m00 = abs(bA.cos * bB.cos + bA.sin * bB.sin);
		let m01 = abs(-bA.sin * bB.cos + bA.cos * bB.sin);
		let m10 = abs(-bA.cos * bB.sin + bA.sin * bB.cos);
		let m11 = abs(bA.sin * bB.sin + bA.cos * bB.cos);

		let fAx = abs(dax) - bA.hw - (m00 * bB.hw + m10 * bB.hh);
		let fAy = abs(day) - bA.hh - (m01 * bB.hw + m11 * bB.hh);
		if (fAx > 0 || fAy > 0) return;

		let fBx = abs(dbx) - bB.hw - (m00 * bA.hw + m01 * bA.hh);
		let fBy = abs(dby) - bB.hh - (m10 * bA.hw + m11 * bA.hh);
		if (fBx > 0 || fBy > 0) return;

		let nx, ny, axis = 0, separation = fAx;
		if (dax > 0) { nx = bA.cos; ny = bA.sin; }
		else { nx = -bA.cos; ny = -bA.sin; }

		if (fAy > this.relativeTol * separation + this.absoluteTol * bA.hh) {
			axis = 1; separation = fAy;
			if (day > 0) { nx = -bA.sin; ny = bA.cos; }
			else { nx = bA.sin; ny = -bA.cos; }
		}

		if (fBx > this.relativeTol * separation + this.absoluteTol * bB.hw) {
			axis = 2; separation = fBx;
			if (dbx > 0) { nx = bB.cos; ny = bB.sin; }
			else { nx = -bB.cos; ny = -bB.sin; }
		}

		if (fBy > this.relativeTol * separation + this.absoluteTol * bB.hh) {
			axis = 3; separation = fBy;
			if (dby > 0) { nx = -bB.sin; ny = bB.cos; }
			else { nx = bB.sin; ny = -bB.cos; }
		}

		let fnx, fny, snx, sny, front, negSide, posSide, side;

		switch (axis) {
			case 0:
				fnx = nx; fny = ny;
				front = bA.px * fnx + bA.py * fny + bA.hw;
				snx = -bA.sin; sny = bA.cos;
				side = bA.px * snx + bA.py * sny;
				negSide = -side + bA.hh; posSide = side + bA.hh;
				this.computeIncidentEdge(this.ie, bB, fnx, fny);
				break;
			case 1:
				fnx = nx; fny = ny;
				front = bA.px * fnx + bA.py * fny + bA.hh;
				snx = bA.cos; sny = bA.sin;
				side = bA.px * snx + bA.py * sny;
				negSide = -side + bA.hw; posSide = side + bA.hw;
				this.computeIncidentEdge(this.ie, bB, fnx, fny);
				break;
			case 2:
				fnx = -nx; fny = -ny;
				front = bB.px * fnx + bB.py * fny + bB.hw;
				snx = -bB.sin; sny = bB.cos;
				side = bB.px * snx + bB.py * sny;
				negSide = -side + bB.hh; posSide = side + bB.hh;
				this.computeIncidentEdge(this.ie, bA, fnx, fny);
				break;
			case 3:
				fnx = -nx; fny = -ny;
				front = bB.px * fnx + bB.py * fny + bB.hh;
				snx = bB.cos; sny = bB.sin;
				side = bB.px * snx + bB.py * sny;
				negSide = -side + bB.hw; posSide = side + bB.hw;
				this.computeIncidentEdge(this.ie, bA, fnx, fny);
				break;
		}

		if (this.clipSegmentToLine(this.c1, this.ie, -snx, -sny, negSide) < 2) return;
		if (this.clipSegmentToLine(this.c2, this.c1, snx, sny, posSide) < 2) return;

		let cpx, cpy, ct;
		let friction = sqrt(bA.friction * bB.friction);

		for (let i = 0; i < 2; ++i) {
			cpx = this.c2[i * 2];
			cpy = this.c2[i * 2 + 1];
			separation = fnx * cpx + fny * cpy - front;
			if (separation < 0) {
				if (this.numContacts < this.maxContacts) {
					ct = this.contacts[this.numContacts];
				} else {
					ct = new Contact(this);
					this.contacts.push(ct);
					this.maxContacts++;
				}
				ct.update(bA, bB, separation, nx, ny, friction,
					cpx - fnx * separation, cpy - fny * separation);
				this.numContacts++;
			}
		}
	}

	clipSegmentToLine(vO, vI, nx, ny, offset) {
		let numOut = 0;
		let distance0 = nx * vI[0] + ny * vI[1] - offset;
		let distance1 = nx * vI[2] + ny * vI[3] - offset;
		if (distance0 <= 0) { vO[0] = vI[0]; vO[1] = vI[1]; numOut++; }
		if (distance1 <= 0) { vO[numOut * 2] = vI[2]; vO[numOut * 2 + 1] = vI[3]; numOut++; }
		if (distance0 * distance1 < 0) {
			let interp = distance0 / (distance0 - distance1);
			vO[numOut * 2] = vI[0] + interp * (vI[2] - vI[0]);
			vO[numOut * 2 + 1] = vI[1] + interp * (vI[3] - vI[1]);
			++numOut;
		}
		return numOut;
	}

	computeIncidentEdge(ie, b, nx, ny) {
		let nrx = -(b.cos * nx + b.sin * ny);
		let nry = -(-b.sin * nx + b.cos * ny);
		if (abs(nrx) > abs(nry)) {
			if (nrx > 0) { ie[0] = b.hw; ie[1] = -b.hh; ie[2] = b.hw; ie[3] = b.hh; }
			else { ie[0] = -b.hw; ie[1] = b.hh; ie[2] = -b.hw; ie[3] = -b.hh; }
		} else {
			if (nry > 0) { ie[0] = b.hw; ie[1] = b.hh; ie[2] = -b.hw; ie[3] = b.hh; }
			else { ie[0] = -b.hw; ie[1] = -b.hh; ie[2] = b.hw; ie[3] = -b.hh; }
		}
		let x, y;
		x = ie[0]; y = ie[1];
		ie[0] = b.px + b.cos * x - b.sin * y;
		ie[1] = b.py + b.sin * x + b.cos * y;
		x = ie[2]; y = ie[3];
		ie[2] = b.px + b.cos * x - b.sin * y;
		ie[3] = b.py + b.sin * x + b.cos * y;
	}
}

class Canvas {
	constructor(resx, resy) {
		this.elem = document.createElement("canvas");
		this.resx = resx;
		this.resy = resy;
		this.left = 0;
		this.top = 0;
		this.ctx = this.elem.getContext("2d");
		document.body.appendChild(this.elem);
		this.resize();
		window.addEventListener("resize", () => this.resize(), false);
		if (!this.ctx.setLineDash) this.ctx.setLineDash = function () { };
	}

	resize() {
		let o = this.elem;
		this.width = this.elem.width = this.resx;
		this.height = this.elem.height = this.resy;
		for ((this.left = 0), (this.top = 0); o != null; o = o.offsetParent) {
			this.left += o.offsetLeft;
			this.top += o.offsetTop;
		}
	}
}

class Pointer {
	constructor(canvas) {
		this.x = 0; this.y = 0;
		this.canvas = canvas;
		window.addEventListener("mousemove", e => this.move(e), false);
		canvas.elem.addEventListener("touchmove", e => this.move(e), false);
	}

	move(e) {
		let touchMode = e.targetTouches, pointer;
		if (touchMode) { e.preventDefault(); pointer = touchMode[0]; }
		else pointer = e;
		this.x = (-this.canvas.left + pointer.clientX) * this.canvas.resx / this.canvas.elem.offsetWidth;
		this.y = (-this.canvas.top + pointer.clientY) * this.canvas.resy / this.canvas.elem.offsetHeight;
	}
}

let canvas = new Canvas(1200, 600);
let ctx = canvas.ctx;
let pointer = new Pointer(canvas);

function run() {
	requestAnimationFrame(run);
	ctx.clearRect(0, 0, canvas.width, canvas.height);
	ctx.lineWidth = 3;
	world.step();
}

function init() {
	let timeStep = 1 / 30;
	world = new World({
		gravity: 40,
		iterations: 20,
		timeStep,
		friction: 0.3,
		allowedPenetration: 0.05,
		biasFactor: 0.2,
		relativeTol: 0.95,
		absoluteTol: 0.01
	});

	let ground = world.addBody({ x: 600, y: 649, w: 1200, h: 100, mass: Infinity, friction: 3.8, visible: false });

	let numPlanks = 5, mass = 50.0, frequencyHz = 0.8, dampingRatio = 0.7;
	let omega = 2.0 * PI * frequencyHz;
	let d = 2.0 * mass * dampingRatio * omega;
	let k = mass * omega * omega;
	let softness = 1.0 / (d + timeStep * k);
	let biasFactor = timeStep * k / (d + timeStep * k);

	let box1 = world.addBody({ x: 500, y: 150, w: 10, h: 20, mass: 10 });
	let box2 = world.addBody({ x: 500, y: 200, w: 10, h: 20, mass: 10 });
	let box3 = world.addBody({ x: 500, y: 250, w: 10, h: 20, mass: 10 });
	world.addJoint({ b1: box1, b2: ground, ax: 500, ay: 100 });
	world.addJoint({ b1: box2, b2: box1, ax: 500, ay: 150 });
	world.addJoint({ b1: box2, b2: box2, ax: 500, ay: 200 });
}

let world;
init();
run();

window.addEventListener("pointerdown", e => down(e), false);

function down(e) {
	pointer.move(e);
	e.preventDefault();
	world.addBody({ x: pointer.x, y: pointer.y, w: boxSize, h: boxSize, mass, gravity: grav, color });
}

let boxSize, color, grav, mass;
radio(document.getElementById("large"));

function radio(b) {
	switch (b.value) {
		case "large": boxSize = 50; color = "#FFF"; grav = 50; mass = 40; break;
		case "small": boxSize = 12; color = "green"; grav = 50; mass = 40; break;
		case "antigravity": boxSize = 100; color = "blue"; grav = -50; mass = 2000; break;
	}
	return false;
}