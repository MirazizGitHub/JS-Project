
// ===================== FIZIKA ENGINE (main.js) =====================

class FlatVector {
    static Zero = new FlatVector(0, 0);
    constructor(x, y) { this.X = x; this.Y = y; Object.freeze(this); }
    static zero() { return new FlatVector(0, 0); }
    static add(a, b) { return new FlatVector(a.X + b.X, a.Y + b.Y); }
    static sub(a, b) { return new FlatVector(a.X - b.X, a.Y - b.Y); }
    static neg(v) { return new FlatVector(-v.X, -v.Y); }
    static mul(v, s) { return new FlatVector(v.X * s, v.Y * s); }
    static div(v, s) { return new FlatVector(v.X / s, v.Y / s); }
    static transform(v, t) {
        return new FlatVector(
            t.Cos * v.X - t.Sin * v.Y + t.PositionX,
            t.Sin * v.X + t.Cos * v.Y + t.PositionY
        );
    }
    equals(o) { return this.X === o.X && this.Y === o.Y; }
}

class FlatTransform {
    static Zero = new FlatTransform(0, 0, 0);
    constructor(xOrPos, yOrAngle, angleOpt) {
        if (xOrPos instanceof FlatVector) {
            this.PositionX = xOrPos.X; this.PositionY = xOrPos.Y;
            this.Sin = Math.sin(yOrAngle); this.Cos = Math.cos(yOrAngle);
        } else {
            this.PositionX = xOrPos; this.PositionY = yOrAngle;
            this.Sin = Math.sin(angleOpt); this.Cos = Math.cos(angleOpt);
        }
        Object.freeze(this);
    }
}

class FlatMath {
    static VerySmallAmount = 0.0005;
    static clamp(v, mn, mx) { return Math.max(mn, Math.min(mx, v)); }
    static lengthSquared(v) { return v.X * v.X + v.Y * v.Y; }
    static length(v) { return Math.sqrt(v.X * v.X + v.Y * v.Y); }
    static distanceSquared(a, b) { let dx = a.X - b.X, dy = a.Y - b.Y; return dx * dx + dy * dy; }
    static distance(a, b) { return Math.sqrt(FlatMath.distanceSquared(a, b)); }
    static normalize(v) { let l = FlatMath.length(v); return l > 0 ? new FlatVector(v.X / l, v.Y / l) : FlatVector.Zero; }
    static dot(a, b) { return a.X * b.X + a.Y * b.Y; }
    static cross(a, b) { return a.X * b.Y - a.Y * b.X; }
    static nearlyEqual(a, b) {
        if (typeof a === "number" && typeof b === "number") return Math.abs(a - b) < FlatMath.VerySmallAmount;
        return FlatMath.distanceSquared(a, b) < FlatMath.VerySmallAmount * FlatMath.VerySmallAmount;
    }
    static nearlyEqualVec(a, b) { return FlatMath.distanceSquared(a, b) < FlatMath.VerySmallAmount * FlatMath.VerySmallAmount; }
}

class FlatAABB {
    constructor(minOrX, minY, maxX, maxY) {
        if (minOrX instanceof FlatVector) { this.Min = minOrX; this.Max = minY; }
        else { this.Min = new FlatVector(minOrX, minY); this.Max = new FlatVector(maxX, maxY); }
        Object.freeze(this);
    }
}

const ShapeType = { Circle: 0, Box: 1 };

class FlatBody {
    constructor(density, mass, inertia, restitution, area, isStatic, radius, width, height, vertices, shapeType) {
        this.position = FlatVector.zero();
        this.linearVelocity = FlatVector.zero();
        this.angle = 0;
        this.angularVelocity = 0;
        this.force = FlatVector.zero();
        this.ShapeType = shapeType;
        this.Density = density; this.Mass = mass;
        this.InvMass = mass > 0 ? 1 / mass : 0;
        this.Inertia = inertia;
        this.InvInertia = inertia > 0 ? 1 / inertia : 0;
        this.Restitution = restitution; this.Area = area;
        this.IsStatic = isStatic; this.Radius = radius;
        this.Width = width; this.Height = height;
        this.StaticFriction = 0.6; this.DynamicFriction = 0.4;
        if (this.ShapeType === ShapeType.Box) {
            this.vertices = vertices;
            this.transformedVertices = new Array(vertices.length);
        } else { this.vertices = null; this.transformedVertices = null; }
        this.transformUpdateRequired = true;
        this.aabbUpdateRequired = true;
        this.aabb = null;
        // color for rendering
        this.color = `hsl(${Math.random() * 360 | 0}, 70%, 60%)`;
    }
    get Position() { return this.position; }
    get LinearVelocity() { return this.linearVelocity; }
    set LinearVelocity(v) { this.linearVelocity = v; }
    get Angle() { return this.angle; }
    get AngularVelocity() { return this.angularVelocity; }
    set AngularVelocity(v) { this.angularVelocity = v; }

    static CreateBoxVertices(w, h) {
        let l = -w / 2, r = l + w, b = -h / 2, t = b + h;
        return [new FlatVector(l, t), new FlatVector(r, t), new FlatVector(r, b), new FlatVector(l, b)];
    }

    getTransformedVertices() {
        if (this.transformUpdateRequired) {
            let tf = new FlatTransform(this.position, this.angle);
            for (let i = 0; i < this.vertices.length; i++)
                this.transformedVertices[i] = FlatVector.transform(this.vertices[i], tf);
        }
        this.transformUpdateRequired = false;
        return this.transformedVertices;
    }

    getAABB() {
        if (this.aabbUpdateRequired) {
            let mnX = Infinity, mnY = Infinity, mxX = -Infinity, mxY = -Infinity;
            if (this.ShapeType === ShapeType.Box) {
                for (let v of this.getTransformedVertices()) {
                    if (v.X < mnX) mnX = v.X; if (v.X > mxX) mxX = v.X;
                    if (v.Y < mnY) mnY = v.Y; if (v.Y > mxY) mxY = v.Y;
                }
            } else {
                mnX = this.position.X - this.Radius; mnY = this.position.Y - this.Radius;
                mxX = this.position.X + this.Radius; mxY = this.position.Y + this.Radius;
            }
            this.aabb = new FlatAABB(mnX, mnY, mxX, mxY);
        }
        this.aabbUpdateRequired = false;
        return this.aabb;
    }

    step(time, gravity, iterations) {
        if (this.IsStatic) return;
        time /= iterations;
        this.linearVelocity = FlatVector.add(this.linearVelocity, FlatVector.mul(gravity, time));
        this.position = FlatVector.add(this.position, FlatVector.mul(this.linearVelocity, time));
        this.angle += this.angularVelocity * time;
        this.force = FlatVector.zero();
        this.transformUpdateRequired = true;
        this.aabbUpdateRequired = true;
    }
    move(a) { this.position = FlatVector.add(this.position, a); this.transformUpdateRequired = true; this.aabbUpdateRequired = true; }
    moveTo(p) { this.position = p; this.transformUpdateRequired = true; this.aabbUpdateRequired = true; }
    rotate(a) { this.angle += a; this.transformUpdateRequired = true; this.aabbUpdateRequired = true; }
    addForce(a) { this.force = a; }

    static CreateCircleBody(radius, density, isStatic, restitution) {
        let area = radius * radius * Math.PI;
        if (area < FlatWorld.MinBodySize) return { body: null, error: 'Radius juda kichik.' };
        if (area > FlatWorld.MaxBodySize) return { body: null, error: 'Radius juda katta.' };
        if (density < FlatWorld.MinDensity) return { body: null, error: 'Zichlik juda kichik.' };
        if (density > FlatWorld.MaxDensity) return { body: null, error: 'Zichlik juda katta.' };
        restitution = FlatMath.clamp(restitution, 0, 1);
        let mass = 0, inertia = 0;
        if (!isStatic) { mass = area * density; inertia = 0.5 * mass * radius * radius; }
        return { body: new FlatBody(density, mass, inertia, restitution, area, isStatic, radius, 0, 0, null, ShapeType.Circle), error: null };
    }

    static CreateBoxBody(width, height, density, isStatic, restitution) {
        let area = width * height;
        if (area < FlatWorld.MinBodySize) return { body: null, error: 'Alan juda kichik.' };
        if (area > FlatWorld.MaxBodySize) return { body: null, error: 'Alan juda katta.' };
        if (density < FlatWorld.MinDensity) return { body: null, error: 'Zichlik juda kichik.' };
        if (density > FlatWorld.MaxDensity) return { body: null, error: 'Zichlik juda katta.' };
        restitution = FlatMath.clamp(restitution, 0, 1);
        let mass = 0, inertia = 0;
        if (!isStatic) { mass = area * density; inertia = (1 / 12) * mass * (width * width + height * height); }
        let verts = FlatBody.CreateBoxVertices(width, height);
        return { body: new FlatBody(density, mass, inertia, restitution, area, isStatic, 0, width, height, verts, ShapeType.Box), error: null };
    }
}

class FlatManifold {
    constructor(bodyA, bodyB, normal, depth, contact1, contact2, contactCount) {
        this.BodyA = bodyA; this.BodyB = bodyB; this.Normal = normal; this.Depth = depth;
        this.Contact1 = contact1; this.Contact2 = contact2; this.ContactCount = contactCount;
        Object.freeze(this);
    }
}

class Collisions {
    static PointSegmentDistance(p, a, b) {
        let ab = FlatVector.sub(b, a), ap = FlatVector.sub(p, a);
        let proj = FlatMath.dot(ap, ab), abLenSq = FlatMath.lengthSquared(ab), d = proj / abLenSq;
        let cp;
        if (d <= 0) cp = a;
        else if (d >= 1) cp = b;
        else cp = FlatVector.add(a, FlatVector.mul(ab, d));
        return { distanceSquared: FlatMath.distanceSquared(p, cp), cp };
    }

    static IntersectAABBs(a, b) {
        return !(a.Max.X <= b.Min.X || b.Max.X <= a.Min.X || a.Max.Y <= b.Min.Y || b.Max.Y <= a.Min.Y);
    }

    static IntersectCircles(cA, rA, cB, rB) {
        let dist = FlatMath.distance(cA, cB), radii = rA + rB;
        if (dist >= radii) return { collided: false, normal: FlatVector.Zero, depth: 0 };
        return { collided: true, normal: FlatMath.normalize(FlatVector.sub(cB, cA)), depth: radii - dist };
    }

    static IntersectCirclePolygon(circleCenter, circleRadius, polyCenter, polyVerts) {
        let normal = FlatVector.Zero, depth = Infinity, axis, axisDepth, minA, maxA, minB, maxB;
        for (let i = 0; i < polyVerts.length; i++) {
            let va = polyVerts[i], vb = polyVerts[(i + 1) % polyVerts.length];
            let edge = FlatVector.sub(vb, va);
            axis = FlatMath.normalize(new FlatVector(-edge.Y, edge.X));
            let rA = Collisions._projectVerts(polyVerts, axis);
            let rB = Collisions._projectCircle(circleCenter, circleRadius, axis);
            if (rA.min >= rB.max || rB.min >= rA.max) return { collided: false, normal: FlatVector.Zero, depth: 0 };
            axisDepth = Math.min(rB.max - rA.min, rA.max - rB.min);
            if (axisDepth < depth) { depth = axisDepth; normal = axis; }
        }
        let cpIdx = Collisions._findClosestPolyVertex(circleCenter, polyVerts);
        let cp = polyVerts[cpIdx];
        axis = FlatMath.normalize(FlatVector.sub(cp, circleCenter));
        let rA2 = Collisions._projectVerts(polyVerts, axis);
        let rB2 = Collisions._projectCircle(circleCenter, circleRadius, axis);
        if (rA2.min >= rB2.max || rB2.min >= rA2.max) return { collided: false, normal: FlatVector.Zero, depth: 0 };
        axisDepth = Math.min(rB2.max - rA2.min, rA2.max - rB2.min);
        if (axisDepth < depth) { depth = axisDepth; normal = axis; }
        let dir = FlatVector.sub(polyCenter, circleCenter);
        if (FlatMath.dot(dir, normal) < 0) normal = FlatVector.neg(normal);
        return { collided: true, normal, depth };
    }

    static IntersectPolygons(centerA, vertsA, centerB, vertsB) {
        let normal = FlatVector.Zero, depth = Infinity;
        for (let verts of [vertsA, vertsB]) {
            for (let i = 0; i < verts.length; i++) {
                let edge = FlatVector.sub(verts[(i + 1) % verts.length], verts[i]);
                let axis = FlatMath.normalize(new FlatVector(-edge.Y, edge.X));
                let rA = Collisions._projectVerts(vertsA, axis);
                let rB = Collisions._projectVerts(vertsB, axis);
                if (rA.min >= rB.max || rB.min >= rA.max) return { collided: false, normal: FlatVector.Zero, depth: 0 };
                let ad = Math.min(rB.max - rA.min, rA.max - rB.min);
                if (ad < depth) { depth = ad; normal = axis; }
            }
        }
        let dir = FlatVector.sub(centerB, centerA);
        if (FlatMath.dot(dir, normal) < 0) normal = FlatVector.neg(normal);
        return { collided: true, normal, depth };
    }

    static _projectVerts(verts, axis) {
        let min = Infinity, max = -Infinity;
        for (let v of verts) { let p = FlatMath.dot(v, axis); if (p < min) min = p; if (p > max) max = p; }
        return { min, max };
    }
    static _projectCircle(center, radius, axis) {
        let dir = FlatMath.normalize(axis), p = FlatMath.dot(center, axis);
        return { min: p - radius, max: p + radius };
    }
    static _findClosestPolyVertex(point, verts) {
        let minDist = Infinity, idx = 0;
        for (let i = 0; i < verts.length; i++) {
            let d = FlatMath.distance(point, verts[i]);
            if (d < minDist) { minDist = d; idx = i; }
        }
        return idx;
    }

    static Collide(bodyA, bodyB) {
        if (bodyA.ShapeType === ShapeType.Box) {
            if (bodyB.ShapeType === ShapeType.Box)
                return Collisions.IntersectPolygons(bodyA.Position, bodyA.getTransformedVertices(), bodyB.Position, bodyB.getTransformedVertices());
            else {
                let r = Collisions.IntersectCirclePolygon(bodyB.Position, bodyB.Radius, bodyA.Position, bodyA.getTransformedVertices());
                r.normal = FlatVector.neg(r.normal); return r;
            }
        } else {
            if (bodyB.ShapeType === ShapeType.Box)
                return Collisions.IntersectCirclePolygon(bodyA.Position, bodyA.Radius, bodyB.Position, bodyB.getTransformedVertices());
            else
                return Collisions.IntersectCircles(bodyA.Position, bodyA.Radius, bodyB.Position, bodyB.Radius);
        }
    }

    static FindContactPoints(bodyA, bodyB) {
        let c1 = FlatVector.zero(), c2 = FlatVector.zero(), cnt = 0;
        if (bodyA.ShapeType === ShapeType.Box) {
            if (bodyB.ShapeType === ShapeType.Box) return Collisions.FindPolygonsContactPoints(bodyA.getTransformedVertices(), bodyB.getTransformedVertices());
            else { c1 = Collisions.FindCirclePolygonContactPoint(bodyB.Position, bodyB.Radius, bodyA.Position, bodyA.getTransformedVertices()); cnt = 1; }
        } else {
            if (bodyB.ShapeType === ShapeType.Box) { c1 = Collisions.FindCirclePolygonContactPoint(bodyA.Position, bodyA.Radius, bodyB.Position, bodyB.getTransformedVertices()); cnt = 1; }
            else { c1 = Collisions.FindCirclesContactPoint(bodyA.Position, bodyA.Radius, bodyB.Position); cnt = 1; }
        }
        return { contact1: c1, contact2: c2, contactCount: cnt };
    }

    static FindPolygonsContactPoints(vA, vB) {
        let c1 = FlatVector.zero(), c2 = FlatVector.zero(), cnt = 0, minDist = Infinity;
        for (let verts of [vA, vB]) {
            let other = verts === vA ? vB : vA;
            for (let i = 0; i < verts.length; i++) {
                let p = verts[i];
                for (let j = 0; j < other.length; j++) {
                    let { distanceSquared: d, cp } = Collisions.PointSegmentDistance(p, other[j], other[(j + 1) % other.length]);
                    if (FlatMath.nearlyEqual(d, minDist)) { if (!FlatMath.nearlyEqualVec(cp, c1)) { c2 = cp; cnt = 2; } }
                    else if (d < minDist) { minDist = d; cnt = 1; c1 = cp; }
                }
            }
        }
        return { contact1: c1, contact2: c2, contactCount: cnt };
    }

    static FindCirclePolygonContactPoint(cc, cr, pc, pv) {
        let cp = FlatVector.zero(), minD = Infinity;
        for (let i = 0; i < pv.length; i++) {
            let { distanceSquared: d, cp: c } = Collisions.PointSegmentDistance(cc, pv[i], pv[(i + 1) % pv.length]);
            if (d < minD) { minD = d; cp = c; }
        }
        return cp;
    }

    static FindCirclesContactPoint(cA, rA, cB) {
        return FlatVector.add(cA, FlatVector.mul(FlatMath.normalize(FlatVector.sub(cB, cA)), rA));
    }
}

class FlatWorld {
    static TransformCount = 0;
    static NoTransformCount = 0;
    static MinBodySize = 0.01 * 0.01;
    static MaxBodySize = 64 * 64;
    static MinDensity = 0.5;
    static MaxDensity = 21.4;
    static MinIterations = 1;
    static MaxIterations = 128;

    constructor() {
        this.gravity = new FlatVector(0, -9.81);
        this.bodyList = [];
        this.contactPairs = [];
        this.contactList = [FlatVector.Zero, FlatVector.Zero];
        this.impulseList = [FlatVector.Zero, FlatVector.Zero];
        this.raList = [FlatVector.Zero, FlatVector.Zero];
        this.rbList = [FlatVector.Zero, FlatVector.Zero];
        this.frictionImpulseList = [FlatVector.Zero, FlatVector.Zero];
        this.jList = [0, 0];
    }

    get BodyCount() { return this.bodyList.length; }
    addBody(b) { this.bodyList.push(b); }
    removeBody(b) { let i = this.bodyList.indexOf(b); if (i !== -1) this.bodyList.splice(i, 1); }

    step(time, totalIterations) {
        totalIterations = FlatMath.clamp(totalIterations, FlatWorld.MinIterations, FlatWorld.MaxIterations);
        for (let i = 0; i < totalIterations; i++) {
            this.contactPairs.length = 0;
            this._stepBodies(time, totalIterations);
            this._broadPhase();
            this._narrowPhase();
        }
    }

    _stepBodies(time, iter) { for (let b of this.bodyList) b.step(time, this.gravity, iter); }

    _broadPhase() {
        for (let i = 0; i < this.bodyList.length - 1; i++) {
            let bA = this.bodyList[i], aabbA = bA.getAABB();
            for (let j = i + 1; j < this.bodyList.length; j++) {
                let bB = this.bodyList[j], aabbB = bB.getAABB();
                if (bA.IsStatic && bB.IsStatic) continue;
                if (!Collisions.IntersectAABBs(aabbA, aabbB)) continue;
                this.contactPairs.push([i, j]);
            }
        }
    }

    _narrowPhase() {
        for (let [i, j] of this.contactPairs) {
            let bA = this.bodyList[i], bB = this.bodyList[j];
            let res = Collisions.Collide(bA, bB);
            if (res && res.collided) {
                this._separateBodies(bA, bB, FlatVector.mul(res.normal, res.depth));
                let contacts = Collisions.FindContactPoints(bA, bB);
                let manifold = new FlatManifold(bA, bB, res.normal, res.depth, contacts.contact1, contacts.contact2, contacts.contactCount);
                this._resolveCollision(manifold);
            }
        }
    }

    _separateBodies(bA, bB, mtv) {
        if (bA.IsStatic) bB.move(mtv);
        else if (bB.IsStatic) bA.move(FlatVector.neg(mtv));
        else { bA.move(FlatVector.div(FlatVector.neg(mtv), 2)); bB.move(FlatVector.div(mtv, 2)); }
    }

    _resolveCollision(contact) {
        let bA = contact.BodyA, bB = contact.BodyB, n = contact.Normal, cnt = contact.ContactCount;
        let e = Math.min(bA.Restitution, bB.Restitution);
        let sf = (bA.StaticFriction + bB.StaticFriction) * 0.5;
        let df = (bA.DynamicFriction + bB.DynamicFriction) * 0.5;
        this.contactList[0] = contact.Contact1; this.contactList[1] = contact.Contact2;
        for (let i = 0; i < cnt; i++) { this.impulseList[i] = FlatVector.Zero; this.raList[i] = FlatVector.Zero; this.rbList[i] = FlatVector.Zero; this.frictionImpulseList[i] = FlatVector.Zero; this.jList[i] = 0; }
        for (let i = 0; i < cnt; i++) {
            let ra = FlatVector.sub(this.contactList[i], bA.Position), rb = FlatVector.sub(this.contactList[i], bB.Position);
            this.raList[i] = ra; this.rbList[i] = rb;
            let raP = new FlatVector(-ra.Y, ra.X), rbP = new FlatVector(-rb.Y, rb.X);
            let avA = FlatVector.mul(raP, bA.AngularVelocity), avB = FlatVector.mul(rbP, bB.AngularVelocity);
            let rv = FlatVector.sub(FlatVector.add(bB.LinearVelocity, avB), FlatVector.add(bA.LinearVelocity, avA));
            let cv = FlatMath.dot(rv, n); if (cv > 0) continue;
            let raPdN = FlatMath.dot(raP, n), rbPdN = FlatMath.dot(rbP, n);
            let denom = bA.InvMass + bB.InvMass + (raPdN * raPdN) * bA.InvInertia + (rbPdN * rbPdN) * bB.InvInertia;
            let j = -(1 + e) * cv / denom / cnt;
            this.jList[i] = j; this.impulseList[i] = FlatVector.mul(n, j);
        }
        for (let i = 0; i < cnt; i++) {
            let imp = this.impulseList[i], ra = this.raList[i], rb = this.rbList[i];
            bA.LinearVelocity = FlatVector.add(bA.LinearVelocity, FlatVector.mul(FlatVector.neg(imp), bA.InvMass));
            bA.AngularVelocity += -FlatMath.cross(ra, imp) * bA.InvInertia;
            bB.LinearVelocity = FlatVector.add(bB.LinearVelocity, FlatVector.mul(imp, bB.InvMass));
            bB.AngularVelocity += FlatMath.cross(rb, imp) * bB.InvInertia;
        }
        for (let i = 0; i < cnt; i++) {
            let ra = FlatVector.sub(this.contactList[i], bA.Position), rb = FlatVector.sub(this.contactList[i], bB.Position);
            let raP = new FlatVector(-ra.Y, ra.X), rbP = new FlatVector(-rb.Y, rb.X);
            let avA = FlatVector.mul(raP, bA.AngularVelocity), avB = FlatVector.mul(rbP, bB.AngularVelocity);
            let rv = FlatVector.sub(FlatVector.add(bB.LinearVelocity, avB), FlatVector.add(bA.LinearVelocity, avA));
            let proj = FlatMath.dot(rv, n), tangent = FlatVector.sub(rv, FlatVector.mul(n, proj));
            if (FlatMath.nearlyEqual(FlatMath.lengthSquared(tangent), 0)) continue;
            tangent = FlatMath.normalize(tangent);
            let raPdT = FlatMath.dot(raP, tangent), rbPdT = FlatMath.dot(rbP, tangent);
            let denom = bA.InvMass + bB.InvMass + (raPdT * raPdT) * bA.InvInertia + (rbPdT * rbPdT) * bB.InvInertia;
            let jt = -FlatMath.dot(rv, tangent) / denom / cnt;
            let j = this.jList[i];
            let fi = Math.abs(jt) <= j * sf ? FlatVector.mul(tangent, jt) : FlatVector.mul(tangent, -j * df);
            this.frictionImpulseList[i] = fi;
        }
        for (let i = 0; i < cnt; i++) {
            let imp = this.frictionImpulseList[i], ra = this.raList[i], rb = this.rbList[i];
            bA.LinearVelocity = FlatVector.add(bA.LinearVelocity, FlatVector.mul(FlatVector.neg(imp), bA.InvMass));
            bA.AngularVelocity += -FlatMath.cross(ra, imp) * bA.InvInertia;
            bB.LinearVelocity = FlatVector.add(bB.LinearVelocity, FlatVector.mul(imp, bB.InvMass));
            bB.AngularVelocity += FlatMath.cross(rb, imp) * bB.InvInertia;
        }
    }
}

// ===================== CANVAS RENDERER =====================
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

// Physics world: 1 unit = 20 pixels, origin at bottom-left
const SCALE = 20;
const W = canvas.width, H = canvas.height;

// Convert world -> screen
function toScreen(x, y) { return { x: x * SCALE, y: H - y * SCALE }; }

const world = new FlatWorld();
let gravityOn = true;
let staticMode = false;
let fps = 0, lastTime = performance.now(), frameCount = 0;

// Add default floor and walls
function addFloor() {
    let { body } = FlatBody.CreateBoxBody(W / SCALE, 1, 1, true, 0.5);
    if (body) { body.moveTo(new FlatVector(W / SCALE / 2, 0.5)); body.color = '#4a4a6a'; world.addBody(body); }
    // Left wall
    let { body: lw } = FlatBody.CreateBoxBody(1, H / SCALE, 1, true, 0.3);
    if (lw) { lw.moveTo(new FlatVector(0.5, H / SCALE / 2)); lw.color = '#4a4a6a'; world.addBody(lw); }
    // Right wall
    let { body: rw } = FlatBody.CreateBoxBody(1, H / SCALE, 1, true, 0.3);
    if (rw) { rw.moveTo(new FlatVector(W / SCALE - 0.5, H / SCALE / 2)); rw.color = '#4a4a6a'; world.addBody(rw); }
}

function clearBodies() { world.bodyList.length = 0; }

function toggleGravity() {
    gravityOn = !gravityOn;
    world.gravity = gravityOn ? new FlatVector(0, -9.81) : FlatVector.Zero;
    document.querySelector('button[onclick="toggleGravity()"]').textContent =
        `🌍 Gravitatsiya: ${gravityOn ? 'ON' : 'OFF'}`;
}

function toggleStaticMode() {
    staticMode = !staticMode;
    let btn = document.getElementById('btnStatic');
    btn.textContent = `🧱 Statik rejim: ${staticMode ? 'ON' : 'OFF'}`;
    btn.className = staticMode ? 'active' : '';
}

function spawnRandom(n) {
    let shapes = ['circle', 'box'];
    for (let i = 0; i < n; i++) {
        let shape = shapes[Math.random() < 0.5 ? 0 : 1];
        let x = 2 + Math.random() * (W / SCALE - 4);
        let y = H / SCALE * 0.3 + Math.random() * H / SCALE * 0.5;
        spawnBody(shape, x, y, false);
    }
}

function spawnBody(shape, wx, wy, isStatic) {
    let body, err;
    if (shape === 'circle') {
        let r = 0.4 + Math.random() * 0.8;
        ({ body, error: err } = FlatBody.CreateCircleBody(r, 1.0, isStatic, 0.5));
    } else {
        let w = 0.6 + Math.random() * 1.5, h = 0.6 + Math.random() * 1.5;
        ({ body, error: err } = FlatBody.CreateBoxBody(w, h, 1.0, isStatic, 0.4));
    }
    if (body) {
        body.moveTo(new FlatVector(wx, wy));
        if (isStatic) body.color = '#6b7280';
        world.addBody(body);
    }
}

// Mouse events
canvas.addEventListener('click', (e) => {
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left, my = e.clientY - rect.top;
    const wx = mx / SCALE, wy = (H - my) / SCALE;
    const shape = document.getElementById('shapeSelect').value;
    spawnBody(shape, wx, wy, staticMode);
});

canvas.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left, my = e.clientY - rect.top;
    const wx = mx / SCALE, wy = (H - my) / SCALE;
    // Apply impulse to nearest body
    let nearest = null, minDist = Infinity;
    for (let b of world.bodyList) {
        if (b.IsStatic) continue;
        let d = FlatMath.distance(b.Position, new FlatVector(wx, wy));
        if (d < minDist) { minDist = d; nearest = b; }
    }
    if (nearest && minDist < 5) {
        let dir = FlatMath.normalize(FlatVector.sub(new FlatVector(wx, wy), nearest.Position));
        nearest.LinearVelocity = FlatVector.add(nearest.LinearVelocity, FlatVector.mul(dir, 15));
    }
});

// Keyboard
document.addEventListener('keydown', (e) => {
    if (e.key === 'c' || e.key === 'C') clearBodies();
    if (e.key === 'g' || e.key === 'G') toggleGravity();
    if (e.key === 'f' || e.key === 'F') addFloor();
});

// Draw
function drawBody(body) {
    ctx.save();
    if (body.ShapeType === ShapeType.Circle) {
        let s = toScreen(body.Position.X, body.Position.Y);
        let r = body.Radius * SCALE;
        ctx.beginPath();
        ctx.arc(s.x, s.y, r, 0, Math.PI * 2);
        ctx.fillStyle = body.IsStatic ? '#6b7280' : body.color;
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.3)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        // rotation indicator
        ctx.beginPath();
        let ex = s.x + Math.cos(-body.angle) * r * 0.8;
        let ey = s.y + Math.sin(-body.angle) * r * 0.8;
        ctx.moveTo(s.x, s.y);
        ctx.lineTo(ex, ey);
        ctx.strokeStyle = 'rgba(255,255,255,0.6)';
        ctx.lineWidth = 2;
        ctx.stroke();
    } else {
        let verts = body.getTransformedVertices();
        ctx.beginPath();
        let s0 = toScreen(verts[0].X, verts[0].Y);
        ctx.moveTo(s0.x, s0.y);
        for (let i = 1; i < verts.length; i++) {
            let s = toScreen(verts[i].X, verts[i].Y);
            ctx.lineTo(s.x, s.y);
        }
        ctx.closePath();
        ctx.fillStyle = body.IsStatic ? '#4a4a6a' : body.color;
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.25)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
    }
    ctx.restore();
}

// Remove bodies that fall out of bounds
function cleanup() {
    world.bodyList = world.bodyList.filter(b => {
        if (b.IsStatic) return true;
        return b.Position.Y > -10 && b.Position.X > -10 && b.Position.X < W / SCALE + 10;
    });
}

// Game loop
let lastCleanup = 0;
function loop(ts) {
    const dt = Math.min((ts - lastTime) / 1000, 0.05);
    lastTime = ts;
    frameCount++;
    if (ts - lastCleanup > 2000) { cleanup(); lastCleanup = ts; }

    // Physics step
    world.step(dt, 10);

    // Render
    ctx.clearRect(0, 0, W, H);

    // Background grid
    ctx.strokeStyle = '#ffffff08';
    ctx.lineWidth = 0.5;
    for (let x = 0; x < W; x += SCALE) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
    for (let y = 0; y < H; y += SCALE) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }

    for (let b of world.bodyList) drawBody(b);

    // FPS counter
    if (frameCount % 30 === 0) {
        fps = Math.round(30 / ((ts - lastTime + dt * 1000 * 30) / 1000));
        fps = Math.min(fps, 144);
    }
    document.getElementById('stats').textContent =
        `Jismlar: ${world.BodyCount} | FPS: ~60 | Bosing: jism qo'shish | RMB: itarish | C: tozalash | F: zamin`;

    requestAnimationFrame(loop);
}

// Init
addFloor();
// Spawn a few demo bodies
setTimeout(() => spawnRandom(5), 200);

requestAnimationFrame(loop);
