class Box {
    constructor(pos, size, color) {
        this.pos = [...pos];
        this.size = [...size];
        /*this.color = `hsl(${Math.random() * 361}, 100%, 50%)`;*/
        // this.bg_images = new Image();
        // this.bg_images.src = 'rectangle.png';
        this.color = color;
        this.level = null;
        this.sprite = null;
    }
    initPixi() {
        this.sprite = PIXI.Sprite.from('rectangle.png');
        this.sprite.width = this.size[0];
        this.sprite.height = this.size[1];
        if (this.color) {
            try {
                this.sprite.tint = new PIXI.Color(this.color).toNumber();
            } catch (e) {
                console.error("Color parsing failed for:", this.color, e);
                this.sprite.tint = 0xffffff;
            }
        }
        if (this.level && this.level.container) {
            this.level.container.addChild(this.sprite);
        }
    }
    update(deltaTime) {  }
    draw() {
        if (this.sprite) {
            this.sprite.x = this.pos[0];
            this.sprite.y = this.pos[1];
        }
    }
}