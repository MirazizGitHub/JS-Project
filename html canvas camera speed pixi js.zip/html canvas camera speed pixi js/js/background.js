

class Background {
    constructor() {
        this.pos = [ 0, -10 ]
        this.size = [ 0, 0 ];
        // this.bg_images = new Image();
        // this.bg_images.src = 'background-image.jpg';
        this.level = null;
        this.sprite = null;
    }
    initPixi() {
        this.sprite = PIXI.Sprite.from('background-image.jpg');
        if (this.level && this.level.container) {
            this.level.container.addChild(this.sprite);
        }
    }
    update(deltaTime) {
        this.size = [this.level.size[0], this.level.size[1]];
    }
    draw() {
        if (this.sprite) {
            this.sprite.x = this.pos[0];
            this.sprite.y = this.pos[1];
            this.sprite.width = this.size[0];
            this.sprite.height = this.size[1] + 70;
        }
    }
}