class Level {
    constructor(options) {
        this.objects = [];
        /* camera start */
        this.size = options.size || (window.canvas ? [canvas.width, canvas.height] : [2000, 1000]);
        this.cameraPos = options.cameraPos || [this.size[0] / 2, this.size[1] / 2];
        /**/
        this.bg = options.objects.backgroundEffect;
        this.player_array = options.objects.player;
        this.box = options.objects.box;
        this.player = null;

        this.cameraSpeed = 500;
        
        this.container = null;
        this.hudText = null;
        this.cameraPos__numb__x = 0;
        this.cameraPos__numb__y = 0;
    }
    initPixi() {
        this.container = new PIXI.Container();
        app.stage.addChild(this.container);

        this.hudText = new PIXI.Text({
            text: '',
            style: {
                fontFamily: 'Arial',
                fontSize: 30,
                fill: 'white',
            }
        });
        this.hudText.x = 50;
        this.hudText.y = 50;
        app.stage.addChild(this.hudText);

        this.bg.forEach(bgc => {
            bgc.level = this;
            bgc.initPixi();
        });
        this.box.forEach(obj => {
            obj.level = this;
            obj.initPixi();
        });
        this.player_array.forEach(pl => {
            pl.level = this;
            pl.initPixi();
            this.player = pl;
        });
    }
    updateCamera(deltaTime) {
        /**/
        this.bg.forEach(bgc => {
            bgc.level = this;
            bgc.update(deltaTime);
            bgc.draw();
        });
        this.box.forEach(obj => {
            obj.level = this;
            obj.update(deltaTime);
            obj.draw();
        });
        this.player_array.forEach(pl => {
            pl.level = this;
            pl.update(deltaTime);
            pl.draw();
            this.player = pl;
        });
        /**/
    }
    update(deltaTime) {
        /**/
        this.updateCamera(deltaTime);

        this.cameraPos__numb__x = minmax(
            (this.player.pos.x + this.player.size[0]) - canvas.width / 2,
            0,
            this.size[0] - canvas.width
        );

        this.cameraPos__numb__y = minmax(
            this.player.pos.y - canvas.height / 2,
            0,
            this.size[1] - canvas.height
        );

        const speed = this.cameraSpeed * deltaTime;
        this.cameraPos[0] += (this.cameraPos__numb__x - this.cameraPos[0]) * speed / 100;
        this.cameraPos[1] += (this.cameraPos__numb__y - this.cameraPos[1]) * speed / 100;

        let shakeX = 0;
        let shakeY = 0;
        if (shakeTime > 0) {
            shakeX = (Math.random() - 0.5) * shakePower;
            shakeY = (Math.random() - 0.5) * shakePower;
            shakeTime--;
        }

        if (this.container) {
            this.container.x = -this.cameraPos[0] + shakeX;
            this.container.y = -this.cameraPos[1] + shakeY;
        }
    }
    draw() {
        if (this.hudText) {
            this.hudText.text = `Camera player pos x: ${this.cameraPos__numb__x.toFixed(0)}, y: ${this.cameraPos__numb__y.toFixed(0)}`;
        }
    }
}
function minmax(val, min, max) {
    return Math.max(min, Math.min(max, val));
}