const canvas = document.getElementById('canvas');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight - 50;

// canvas.width = 800;
// canvas.height = 600;

const app = new PIXI.Application();

let arrowRight = false, arrowTop = false, arrowLeft = false;

let shakeTime = 0;
let shakePower = 0;

function explode(sh_time = 10) {
    shakeTime = sh_time;   // qancha frame davom etadi
    shakePower = 10;  // qancha kuchli qimirlash
}

console.log("main.js loaded");

async function start() {
    console.log("Starting Pixi initialization...");
    try {
        await app.init({
            canvas: canvas,
            width: canvas.width,
            height: canvas.height,
            background: '#111119',
            hello: true
        });
        console.log("Pixi initialized successfully:", app);
    } catch (e) {
        console.error("Pixi initialization failed:", e);
    }

    console.log("Preloading assets...");
    try {
        await PIXI.Assets.load([
            'background-image.jpg',
            'rectangle.png'
        ]);
        console.log("Assets preloaded successfully.");
    } catch (e) {
        console.error("Asset preloading failed:", e);
    }

    console.log("Initializing level1 Pixi objects...");
    try {
        level1.initPixi();
        console.log("level1 Pixi objects initialized.");
    } catch (e) {
        console.error("level1.initPixi failed:", e);
    }

    controller();

    console.log("Starting app ticker loop...");
    app.ticker.add((ticker) => {
        const deltaTime = ticker.elapsedMS / 1000;
        init(deltaTime);
    });
}

start();

function controller() {
    const buttons = document.querySelectorAll('.btn-item');

    // Keyboard
    document.addEventListener('keydown', function(event) {
        if (event.key === 'ArrowLeft') arrowLeft = true;
        if (event.key === 'ArrowUp') arrowTop = true;
        if (event.key === 'ArrowRight') arrowRight = true;
    });

    document.addEventListener('keyup', function(event) {
        if (event.key === 'ArrowLeft') arrowLeft = false;
        if (event.key === 'ArrowUp') arrowTop = false;
        if (event.key === 'ArrowRight') arrowRight = false;
    });

    // Button 0 = Left
    buttons[0].addEventListener('mousedown', () => arrowLeft = true);
    buttons[0].addEventListener('mouseup', () => arrowLeft = false);

    // Button 1 = Up
    buttons[1].addEventListener('mousedown', () => arrowTop = true);
    buttons[1].addEventListener('mouseup', () => arrowTop = false);

    // Button 2 = Right
    buttons[2].addEventListener('mousedown', () => arrowRight = true);
    buttons[2].addEventListener('mouseup', () => arrowRight = false);

    // Mobile
    buttons[0].addEventListener('touchstart', () => arrowLeft = true);
    buttons[0].addEventListener('touchend', () => arrowLeft = false);

    buttons[1].addEventListener('touchstart', () => arrowTop = true);
    buttons[1].addEventListener('touchend', () => arrowTop = false);

    buttons[2].addEventListener('touchstart', () => arrowRight = true);
    buttons[2].addEventListener('touchend', () => arrowRight = false);
}
