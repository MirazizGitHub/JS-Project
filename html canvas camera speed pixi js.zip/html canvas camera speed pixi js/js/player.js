class Player {
	constructor() {
		this.size = [40, 40];
		this.pos = { x: 1600, y: 750 }
		this.vel = { x: 0, y: 0 }
		this.acc = { x: 0, y: 0 }
		this.friction = 0.2;
		this.grav = 0.005;
		this.jump = 3.5;
		this.deltaTime = 30;
		this.speed = 5;
		this.color = 'white';
		this.onGround = false;
		this.level = null;
		this.game = 0;

		this.shake = true;
		this.sprite = null;
		this.winText = null;
	}
	initPixi() {
		this.sprite = PIXI.Sprite.from(PIXI.Texture.WHITE);
		this.sprite.width = this.size[0];
		this.sprite.height = this.size[1];
		if (this.color) {
			try {
				this.sprite.tint = new PIXI.Color(this.color).toNumber();
			} catch (e) {
				console.error("Color parsing failed for player:", this.color, e);
				this.sprite.tint = 0xffffff;
			}
		}
		if (this.level && this.level.container) {
			this.level.container.addChild(this.sprite);
		}

		this.winText = new PIXI.Text({
			text: 'Game wins',
			style: {
				fontFamily: 'Calibri',
				fontSize: 80,
				fill: 'gold',
				fontWeight: 'bold',
			}
		});
		this.winText.anchor.set(0.5);
		this.winText.x = canvas.width / 2;
		this.winText.y = canvas.height / 2;
		this.winText.visible = false;
		app.stage.addChild(this.winText);
	}
	physics(deltaTime) {
		const dt = Math.min(deltaTime, 0.1) * 60;
		this.vel.x += this.acc.x * 1 * dt;
		this.vel.x *= Math.pow(1 - this.friction, dt);
		this.vel.y += this.grav * this.deltaTime * dt;
		this.pos.x += this.vel.x * dt;
		this.pos.y += this.vel.y * this.speed * dt;
		this.onGround = false;
		this.box_length = null;
	}
	update(deltaTime) {
		this.ppos = [this.pos.x, this.pos.y];
		this.physics(deltaTime);
		/*  */
		this.box_length = this.level.box.length;
		this.level.box.forEach(obj => {
			if (this.ppos[1] + this.size[1] <= obj.pos[1] && overlapsWith(this, obj)) {
				this.pos.y = (obj.pos[1] - (this.size[1]));
				this.vel.y = 0;
				this.onGround = true;

				if (this.shake === true) {
					explode(5);
					this.shake = false;
				}
			}
			if (this.ppos[1] >= obj.pos[1] + obj.size[1] && overlapsWith(this, obj)) {
				this.pos.y = (obj.pos[1] + obj.size[1]);
				this.vel.y = 0;

				if (this.shake === true) {
					explode(5);
					this.shake = false;
				}
			}
			if (this.ppos[0] + this.size[0] <= obj.pos[0] && overlapsWith(this, obj)) {
				this.pos.x = (obj.pos[0] - this.size[0]);
				this.vel.x = 0;
			}
			if (this.ppos[0] >= obj.pos[0] + obj.size[0] && overlapsWith(this, obj)) {
				this.pos.x = (obj.pos[0] + obj.size[0]);
				this.vel.x = 0;
			}
		});
		if (this.pos.x >= this.level.size[0] - 100 && this.pos.y < 150) {
			const dt = Math.min(deltaTime, 0.1) * 60;
			this.game += dt;
			arrowRight = false;
			arrowTop = false;
			arrowLeft = false;
			if (this.winText) {
				this.winText.visible = true;
			}
			if (this.game >= 100) {
				this.pos.x = 85;
				this.pos.y = this.level.size[1] - 100;
				this.game = 0;
				if (this.winText) {
					this.winText.visible = false;
				}
			}

			explode();
		} else {
			if (this.game > 0) {
				this.game = 0;
				if (this.winText) {
					this.winText.visible = false;
				}
			}
		}
		/*  */
		if ((this.pos.y + this.size[1]) >= this.level.size[1]) {
			this.pos.y = (this.level.size[1] - this.size[1]);
			this.vel.y = 0;
			this.onGround = true;
			
			if (this.shake === true) {
				explode(5);
				this.shake = false;
			}
		}
		if ((this.pos.x + this.size[0]) >= this.level.size[0]) {
			this.pos.x = (this.level.size[0] - this.size[0]);
			this.vel.x *= -2;
		}
		this.control();
		this.draw();
	}
	control() {
		if (arrowTop) {
			if (this.onGround) {
				this.vel.y = -this.jump;
			}
			this.shake = true;
		}
		if (arrowRight) {
			this.acc.x = 1;
		}
		if (arrowLeft) {
			this.acc.x = -1;
		}
		if (!arrowLeft && !arrowRight) {
			this.acc.x = 0;
		}
		if (this.pos.x <= 0) {
			this.acc.x = 0;
			this.vel.x *= -1;
			this.pos.x = 0;
		}
	}
	draw() {
		if (this.sprite) {
			this.sprite.x = this.pos.x;
			this.sprite.y = this.pos.y;
		}
	}
}

function overlapsWith(player, obj) {
	return (
		player.pos.x <= (obj.pos[0] + obj.size[0]) &&
		(player.pos.x + player.size[0]) >= obj.pos[0] &&
		(player.pos.y + player.size[1]) >= obj.pos[1] &&
		player.pos.y <= (obj.pos[1] + obj.size[1])
	);
}

