//set up canvas
var canvasID = "mechcanvas"
var canvas = document.getElementById(canvasID);
var ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
ctx.textAlign = "center";
ctx.font = "17px Arial";
ctx.lineJoin = 'round';
ctx.lineCap = "round";

//get mouse postion
onmousemove = function (e) {
    mech.getMousePos(e.clientX, e.clientY);
}
//onmousedown = function(e) {    mech.getMousePos(e.clientX, e.clientY);  }
//looks for key presses and logs them
var keys = [];
document.body.addEventListener("keydown", function (e) {
    keys[e.keyCode] = true;
});
document.body.addEventListener("keyup", function (e) {
    keys[e.keyCode] = false;
});

var mechProto = function () {
    this.ground = window.innerHeight;
    this.height = 100; //can't be larger then about leglength1-5+leglength2-5+hip.x  //128 standing? 115 running?
    // this.heightGoal = 100;
    this.radius = 30;
    this.stroke = "#333"
    this.fill = "#eee"
    this.x = canvas.width - 200;
    this.y = this.ground - this.height;
    this.Vx = 0;
    this.VxMax = 6;
    this.Vy = 0;
    this.Ax = 0.4;
    this.friction = 0.93;
    this.angle = 0;
    this.walk_cycle = 0;
    this.flipLegs = -1;
    this.hip = {
        x: 12,
        y: 24,
    };
    this.knee = {
        x: 0,
        y: 0,
        x2: 0,
        y2: 0
    };
    this.foot = {
        x: 0,
        y: 0
    };
    this.legLength1 = 55;
    this.legLength2 = 45;
    this.mouse = {
        x: 100,
        y: 0
    };
    this.getMousePos = function (x, y) {
        this.mouse.x = x;
        this.mouse.y = y;
    };
    this.look = function () {
        this.angle = Math.atan2(this.mouse.y - this.y, this.mouse.x - this.x);
    };
    this.mouseControls = function () {
        if (this.x - this.radius * 1.5 > this.mouse.x) {
            this.Vx -= this.Ax;
        } else if (this.x + this.radius * 1.5 < this.mouse.x) {
            this.Vx += this.Ax;
        }
        //crouch
        this.height = this.ground - this.mouse.y;
        if (this.height < 70) {
            this.height = 70;
        } else if (this.height > 115) {
            this.height = 115;
        }
        this.y = this.ground - this.height;
    };
    this.keyControls = function () {
        if (keys[40] || keys[83]) { //down
            document.getElementById('s').setAttribute('fill', '#466');
            document.getElementById('w').setAttribute('fill', 'transparent');
            this.heightGoal = 75;
            this.VxMax = 2;
        } else if (keys[38] || keys[87]) { //up
            document.getElementById('w').setAttribute('fill', '#466');
            document.getElementById('s').setAttribute('fill', 'transparent');
            this.heightGoal = 115;
            this.VxMax = 4;
        } else {
            document.getElementById('w').setAttribute('fill', 'transparent');
            document.getElementById('s').setAttribute('fill', 'transparent');
            this.heightGoal = 100;
            this.VxMax = 6;
        }
        if (Math.abs(this.height - this.heightGoal) > 1) {
            this.height = this.height * 0.9 + this.heightGoal * 0.1;
        }
        this.y = this.ground - this.height;

        if (keys[37] || keys[65]) { //left
            this.Vx -= this.Ax;
            document.getElementById('a').setAttribute('fill', '#466');
            document.getElementById('d').setAttribute('fill', 'transparent');
        } else if (keys[39] || keys[68]) { //right
            this.Vx += this.Ax;
            document.getElementById('d').setAttribute('fill', '#466');
            document.getElementById('a').setAttribute('fill', 'transparent');
        } else {
            document.getElementById('d').setAttribute('fill', 'transparent');
            document.getElementById('a').setAttribute('fill', 'transparent');
        };
        //speed bounds
        if (this.Vx > this.VxMax) {
            this.Vx = this.VxMax;
        } else if (-this.Vx > this.VxMax) {
            this.Vx = -this.VxMax;
        }

    };
    this.move = function () {
        this.Vx *= this.friction;
        this.x += this.Vx;
    };
    this.drawLeg = function (stroke) {
        this.drawWires(this.x + this.foot.x * this.flipLegs, this.y + this.foot.y, 2, "#444");
        this.drawWires(this.x + this.knee.x * this.flipLegs, this.y + this.knee.y, 2, "#333");
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.scale(this.flipLegs, 1);
        //leg lines
        ctx.strokeStyle = stroke;
        ctx.lineWidth = 7;
        ctx.beginPath();
        ctx.moveTo(this.hip.x, this.hip.y);
        ctx.lineTo(this.knee.x, this.knee.y);
        ctx.lineTo(this.foot.x, this.foot.y);
        ctx.stroke();
        //toe lines
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(this.foot.x, this.foot.y);
        ctx.lineTo(this.foot.x - 15, this.foot.y + 5);
        ctx.moveTo(this.foot.x, this.foot.y);
        ctx.lineTo(this.foot.x + 15, this.foot.y + 5);
        ctx.stroke();
        //hip joint
        ctx.strokeStyle = this.stroke;
        ctx.fillStyle = this.fill;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(this.hip.x, this.hip.y, 11, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();
        //knee joint
        ctx.beginPath();
        ctx.arc(this.knee.x, this.knee.y, 7, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();
        //foot joint
        ctx.beginPath();
        ctx.arc(this.foot.x, this.foot.y, 6, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();
        ctx.restore();
    };
    this.calcLeg = function (cycle_offset, offset) {
        this.hip.x = 12 + offset;
        this.hip.y = 24 + offset;
        var stepSize = 8 * Math.sqrt(Math.abs(this.Vx));
        var stepAngle = 0.037 * this.walk_cycle + cycle_offset
        this.foot.x = 2 * stepSize * Math.cos(stepAngle) + offset;
        var maxSpan = this.ground - this.y - 5
        this.foot.y = offset + stepSize * Math.sin(stepAngle) + this.height - 5
        if (this.foot.y > maxSpan) this.foot.y = maxSpan; //feet stay above ground
        //calculate knee position as intersection of circle from hip and foot
        var d = Math.sqrt((this.hip.x - this.foot.x) * (this.hip.x - this.foot.x) +
            (this.hip.y - this.foot.y) * (this.hip.y - this.foot.y));
        var l = (this.legLength1 * this.legLength1 - this.legLength2 * this.legLength2 + d * d) / (2 * d);
        var h = Math.sqrt(this.legLength1 * this.legLength1 - l * l);
        this.knee.x = l / d * (this.foot.x - this.hip.x) - h / d * (this.foot.y - this.hip.y) + this.hip.x + offset;
        this.knee.y = l / d * (this.foot.y - this.hip.y) + h / d * (this.foot.x - this.hip.x) + this.hip.y;
    };
    this.drawWires = function (x, y, lineWidth, stroke) {
        ctx.lineWidth = lineWidth;
        ctx.strokeStyle = stroke;
        ctx.beginPath();
        ctx.moveTo(canvas.width, 0);
        ctx.quadraticCurveTo(canvas.width, canvas.height, x, y);
        ctx.stroke();
    };
    this.draw = function () {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = this.fill;
        if (this.mouse.x > this.x) {
            this.flipLegs = 1
        } else {
            this.flipLegs = -1
        }
        this.walk_cycle += this.flipLegs * this.Vx
        //this.drawWires(this.x + this.hip.x * this.flipLegs, this.y + this.hip.y)
        //this.drawWires(this.x +(this.radius-5)*Math.cos(this.angle+Math.PI) , this.y+(this.radius-5)*Math.sin(this.angle+Math.PI) , 10,"#222")
        this.drawWires(this.x + (this.radius + 7) * Math.cos(this.angle + Math.PI),
            this.y + (this.radius + 7) * Math.sin(this.angle + Math.PI), 10, "#222")
        ctx.beginPath();
        ctx.moveTo(this.x + (this.radius + 7) * Math.cos(this.angle + Math.PI),
            this.y + (this.radius + 7) * Math.sin(this.angle + Math.PI));
        ctx.lineTo(this.x, this.y);
        ctx.stroke();
        this.calcLeg(Math.PI, -3);
        this.drawLeg('#444');
        this.calcLeg(0, 0);
        this.drawLeg('#333');

        //draw body

        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.angle);
        ctx.strokeStyle = this.stroke;
        ctx.lineWidth = 2;
        //ctx.fillStyle = this.fill;
        var grd = ctx.createLinearGradient(-30, 0, 30, 0);
        grd.addColorStop(0, "#bbb");
        grd.addColorStop(1, "#fff");
        ctx.fillStyle = grd;
        ctx.beginPath();
        //ctx.moveTo(0, 0);
        ctx.arc(0, 0, 30, 0, 2 * Math.PI);
        ctx.arc(15, 0, 4, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();
        ctx.restore();

    };
    this.info = function () {
        var line = 40;
        ctx.fillStyle = "#666";
        ctx.fillText("Vx = " + this.Vx.toFixed(1), this.x, this.y - line);
        line += 20;
        ctx.fillText("Vy = " + this.Vy.toFixed(1), this.x, this.y - line);
        line += 20;
        ctx.fillText("x = " + this.x.toFixed(1), this.x, this.y - line);
        line += 20;
        ctx.fillText("y = " + this.y.toFixed(1), this.x, this.y - line);
        line += 20;
    };
};
var mech = new mechProto();

function cycle() {
    //mech.mouseControls();
    mech.keyControls();
    mech.move();
    mech.look();
    mech.draw();
    //mech.info();
    requestAnimationFrame(cycle);
}
requestAnimationFrame(cycle);
