let level1 = new Level({
    size: [2000, 400],
    objects: {
        backgroundEffect: [
            new Background(),
        ],
        player: [
            new Player(),
        ],
        box: [
            new Box([0, 300], [200, 20], '#0000ff'),
            new Box([90, 320], [20, canvas.height], '#0000ff'),
            /*########*/
            new Box([250, 200], [100, 20], '#9900cc'),
            new Box([290, 220], [20, canvas.height], '#9900cc'),
            /*########*/
            new Box([450, 300], [100, 20], '#ff0066'),
            new Box([490, 320], [20, canvas.height], '#ff0066'),
            /*########*/
            new Box([650, 200], [100, 20], '#ff9900'),
            new Box([690, 220], [20, canvas.height], '#ff9900'),
            /*########*/
            new Box([850, 100], [100, 20], '#663300'),
            new Box([890, 120], [20, canvas.height], '#663300'),
            /*########*/
            new Box([1050, 200], [100, 20], '#009900'),
            new Box([1090, 220], [20, canvas.height], '#009900'),
            /*########*/
            new Box([1250, 300], [100, 20], '#003300'),
            new Box([1290, 320], [20, canvas.height], '#003300'),
            /*########*/
            new Box([1450, 200], [100, 20], 'lime'),
            new Box([1490, 220], [20, canvas.height], 'lime'),
            /*########*/
            new Box([1650, 100], [100, 20], 'orangered'),
            new Box([1690, 120], [20, canvas.height], 'orangered'),
            /*########*/
            new Box([1850, 100], [150, 20], '#292924'),
            new Box([1890, 120], [20, canvas.height], '#292924'),
            /*########*/
        ]
    }
});