

class Background {
    constructor() {
        this.pos = [ 0, -10 ]
        this.size = [ 0, 0 ];
        this.bg_images = new Image();
        this.bg_images.src = 'background-image.jpg';
        this.level = null;
    }
    update() {
        this.size = [this.level.size[0], this.level.size[1]];
    }
    draw() {
        ctx.beginPath();
        ctx.drawImage(
            this.bg_images,
            this.pos[0] - this.level.cameraPos[0],
            this.pos[1] - this.level.cameraPos[1],
            this.size[0], this.size[1] + 70
        );
        ctx.closePath();
    }
}