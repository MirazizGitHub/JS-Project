
function init() {
    /*  */
    level1.update();
    level1.draw();
    /*objects*/
    /*  */
}



