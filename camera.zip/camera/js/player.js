class Player {
    constructor() {
        this.size = [ 30, 30 ];
        this.pos = { x: 85, y: 150 }
		this.vel = { x: 0, y: 0}
		this.acc = { x: 0, y: 0}
		this.friction = 0.2;
		this.grav = 0.005;
		this.jump = 3.4;
		this.deltaTime = 30;
		this.speed = 3;
        this.color = 'blue';
		this.onGround = false;
        this.level = null;
        this.game = 0;
    }
	physics() {
		this.vel.x += this.acc.x * 1;
		this.vel.x *= (1 - this.friction);
		this.vel.y += this.grav * this.deltaTime;
		this.pos.x += this.vel.x;
		this.pos.y += this.vel.y * this.speed;
		this.onGround = false;
		this.box_length = null;
	}
	update() {
		this.ppos = [this.pos.x, this.pos.y];
		this.physics();
        /*  */
		this.box_length = this.level.box.length;
        this.level.box.forEach(obj => {
            if (this.ppos[1] + this.size[1] <= obj.pos[1] && overlapsWith(this, obj)) {
				this.pos.y = (obj.pos[1] - (this.size[1]));
				this.vel.y = 0;
				this.onGround = true;
			}
            if (this.ppos[1] >= obj.pos[1] + obj.size[1] && overlapsWith(this, obj)) {
                this.pos.y = (obj.pos[1] + obj.size[1]);
                this.vel.y = 0;
            }
            if (this.ppos[0] + this.size[0] <= obj.pos[0] && overlapsWith(this, obj)) {
				this.pos.x = (obj.pos[0] - this.size[0]);
				this.vel.x = 0;
			}
            if (this.ppos[0] >= obj.pos[0] + obj.size[0] && overlapsWith(this, obj)) {
				this.pos.x = (obj.pos[0] + obj.size[0]);
				this.vel.x = 0;
			}
        });
        if(this.pos.x >= this.level.box[this.box_length-1].pos[0]) {
			this.game+=1;
            arrowRight = false;
            arrowTop = false;
            arrowLeft = false;
            ctx.beginPath();
            ctx.lineWidth = 5;
            ctx.strokeStyle = 'red';
            ctx.strokeText('Game wins', canvas.width/2-200, canvas.height/2);
            ctx.fillStyle = 'blue';
            ctx.font = '80px Calibri';
            ctx.fillText('Game wins', canvas.width/2-200, canvas.height/2);
            ctx.closePath();
			if (this.game >= 100) {
            	this.pos.x = 85;
            	this.pos.y = 250;
            	this.game = 0;
			}
        }
        /*  */
		if ((this.pos.y + this.size[1]) >= canvas.height) {
			this.pos.y = (canvas.height - this.size[1]);
			this.vel.y = 0;
			this.game+=1;
            arrowRight = false;
            arrowTop = false;
            arrowLeft = false;
            ctx.beginPath();
            ctx.lineWidth = 5;
            ctx.strokeStyle = 'blue';
            ctx.strokeText('Game Over', canvas.width/2-200, canvas.height/2);
            ctx.fillStyle = 'red';
            ctx.font = '80px Calibri';
            ctx.fillText('Game Over', canvas.width/2-200, canvas.height/2);
            ctx.closePath();
			if (this.game >= 100) {
            	this.pos.x = 85;
            	this.pos.y = 250;
            	this.game = 0;
			}
		}
        if ((this.pos.x + this.size[0]) >= this.level.size[0]) {
            this.pos.x = (this.level.size[0] - this.size[0]);
            this.vel.x *= -2;
        }
		this.control();
        this.draw();
	}
	control() {
		if (arrowTop) {
			if (this.onGround) {
				this.vel.y = -this.jump;
			}
		}
		if (arrowRight) {
			this.acc.x = 1;
		}
		if (arrowLeft) {
			this.acc.x = -1;
		}
		if (!arrowLeft && !arrowRight) {
			this.acc.x = 0;
		}
		if (this.pos.x <= 0) {
			this.acc.x = 0;
			this.vel.x *= -1;
			this.pos.x = 0;
		}
	}
	draw() {
		ctx.beginPath();
        ctx.fillStyle = this.color;
		ctx.fillRect(
            this.pos.x - this.level.cameraPos[0],
            this.pos.y - this.level.cameraPos[1],
            this.size[0],
            this.size[1]
        );
		ctx.closePath();
	}
}

function overlapsWith(player, obj) {
	return (
		player.pos.x <= (obj.pos[0] + obj.size[0]) &&
		(player.pos.x + player.size[0]) >= obj.pos[0]  &&
		(player.pos.y + player.size[1]) >= obj.pos[1] &&
		player.pos.y <= (obj.pos[1] + obj.size[1])
	);
}

