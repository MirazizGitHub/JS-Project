// Canvas sozlamalari
const canvas = document.getElementById("mechcanvas");
const ctx = canvas.getContext("2d");
canvas.width = 800;
canvas.height = 600;
ctx.lineJoin = ctx.lineCap = "round";

// Klaviatura boshqaruvi
const keys = [];
document.body.addEventListener("keydown", (e) => keys[e.keyCode] = true);
document.body.addEventListener("keyup", (e) => keys[e.keyCode] = false);

class Mech {
    constructor() {
        this.ground = 600;
        this.height = 100;
        this.x = canvas.width / 2;
        this.y = this.ground - this.height;
        this.Vx = 0;
        this.VxMax = 6;
        this.Ax = 0.3;
        this.friction = 0.9;
        this.walk_cycle = 0;
        this.flipLegs = 1;
        this.hip = { x: 0, y: 0 }; // x: 12 y: 24
        this.knee = { x: 50, y: 0 };
        this.foot = { x: 0, y: 0 };
        this.legLength1 = 45;
        this.legLength2 = 55;
        this.heightGoal = 100;
    }

    keyControls() {
        // Chapga (←)
        if (keys[37]) {
            this.Vx -= this.Ax;
            this.flipLegs = -1;

            // O'ngga (→)
        } else if (keys[39]) {
            this.Vx += this.Ax;
            this.flipLegs = 1;
        }

        // Maksimal tezlik cheklovi
        this.Vx = Math.max(-this.VxMax, Math.min(this.VxMax, this.Vx));
    }


    move() {
        this.Vx *= this.friction;
        // this.x += this.Vx;
    }

    drawLineWithRect(x1, y1, x2, y2, width) {
        const angle = Math.atan2(y2 - y1, x2 - x1);
        const length = Math.hypot(x2 - x1, y2 - y1);

        ctx.save();
        ctx.translate(x1, y1);
        ctx.rotate(angle);
        ctx.fillRect(0, -width / 2, length, width);
        ctx.restore();
    }

    drawLeg(stroke) {
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.scale(this.flipLegs, 1);

        // Oyoq chiziqlari (fillRect orqali chizilgan)
        ctx.fillStyle = stroke;

        // Bel dan tizzagacha oyoq
        this.drawLineWithRect(this.hip.x, this.hip.y, this.knee.x, this.knee.y, 5);
        // Tizzadan oyoqgacha oyoq
        this.drawLineWithRect(this.knee.x, this.knee.y, this.foot.x, this.foot.y, 5);

        // Oyoq (foot) - to'rtburchak
        ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
        ctx.fillRect(this.foot.x - 15, this.foot.y, 30, 10);

        // Bo'g'imlar (joints) - doiralar
        ctx.fillStyle = "#eee";
        ctx.strokeStyle = "#18884b";
        ctx.lineWidth = 2;

        // Bel (hip) doirasi
        ctx.beginPath();
        ctx.arc(this.hip.x, this.hip.y, 11, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();

        // Tizza doirasi
        ctx.beginPath();
        ctx.arc(this.knee.x, this.knee.y, 7, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();

        // Oyoq doirasi
        ctx.beginPath();
        ctx.arc(this.foot.x, this.foot.y, 6, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();

        ctx.restore();
    }

    calcLeg(cycle_offset, offset, x = 0, y = 0) {
        this.hip.x = x + offset; // 12
        this.hip.y = y + offset; // 24

        const stepSize = 8 * Math.sqrt(Math.abs(this.Vx));
        const stepAngle = 0.03 * this.walk_cycle + cycle_offset;

        // canvasText('stepSize: '+ stepSize.toFixed(3) * 1.2);

        let footX = 2 * stepSize * Math.cos(stepAngle) + x;
        let footY = offset + (stepSize) * Math.sin(stepAngle) + this.height - 10;

        this.foot.x = footX;
        this.foot.y = Math.min(footY, (this.ground - this.y - 10));

        // Tizza pozitsiyasini hisoblash
        const d = Math.hypot(this.hip.x - this.foot.x, this.hip.y - this.foot.y);
        const l = (this.legLength1 ** 2 - this.legLength2 ** 2 + d ** 2) / (2 * d);
        const h = Math.sqrt(this.legLength1 ** 2 - l ** 2);

        // canvasText('d: '+ l.toFixed(2));
        // canvasText('stepSize: ' + this.foot.y);

        this.knee.x = l / d * (this.foot.x - this.hip.x) + h / d * (this.foot.y - this.hip.y) + this.hip.x + offset;
        this.knee.y = l / d * (this.foot.y - this.hip.y) - h / d * (this.foot.x - this.hip.x) + this.hip.y;
    }

    draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        this.walk_cycle += this.flipLegs * this.Vx;

        // this.walk_cycle = this.walk_cycle % (100 * Math.PI);

        // Orqa oyoq
        this.calcLeg(Math.PI, 0);
        this.drawLeg('#444');

        // Old oyoq
        this.calcLeg(0, 0, 0, 0);
        this.drawLeg('#333');
    }
}

const mech = new Mech();


function canvasText(text__) {
    ctx.beginPath();
    ctx.fillStyle = 'blue';
    ctx.font = '30px Arial';
    ctx.fillText(text__, 20, 40);
    ctx.fill();
    ctx.closePath();
}


function cycle() {
    mech.keyControls();
    mech.move();
    mech.draw();

    requestAnimationFrame(cycle);
    // setTimeout(cycle, 100)
}

requestAnimationFrame(cycle);