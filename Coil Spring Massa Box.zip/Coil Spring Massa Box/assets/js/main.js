

const canvas = document.getElementById("c");
const ctx = canvas.getContext("2d");

canvas.width = 1000;
canvas.height = 800;


// body
class Body {
    constructor() {
        this.gravity = 0.1;
        this.ground = canvas.height - 20;
    }

    update() { }

    draw() {
        ctx.beginPath();
        ctx.fillStyle = "#444";
        ctx.fillRect(0, this.ground, canvas.width, 5);
        ctx.closePath();
    }
}

class Box extends Body {
    constructor() {
        super();
        this.x = canvas.width / 2 - 40;
        this.y = 100;
        this.w = 80;
        this.h = 80;
        this.vy = 0;
        this.mass = 5;
        this.dragging = false;
        this.offsetX = 0;
        this.offsetY = 0;

        this.gravitySpeed = 0;
        this.bounce = 1 / Math.sqrt(this.mass);

        this.canvasMouse();
    }

    canvasMouse() {
        canvas.onmousedown = (e) => {
            if (e.offsetX > this.x &&
                e.offsetX < this.x + this.w &&
                e.offsetY > this.y &&
                e.offsetY < this.y + this.h) {
                /**/
                this.dragging = true;
                this.offsetX = e.offsetX - this.x;
                this.offsetY = e.offsetY - this.y;
                this.vy = 0;
                this.gravitySpeed = 0;
            }
        };

        canvas.onmousemove = (e) => {
            if (this.dragging) {
                this.x = e.offsetX - this.offsetX;
                this.y = e.offsetY - this.offsetY;
            }
        };

        canvas.onmouseup = () => {
            this.dragging = false;
        };
    }

    update() {
        if (!this.dragging) {
            this.vy += this.gravity;
            this.y += this.vy;

            // ground
            if (this.y + this.h > this.ground) {
                this.y = this.ground - this.h;
                this.vy *= -this.bounce;
            }
        }

        // plate collision
        if (
            this.vy > 0 &&
            this.x + this.w > plate.x &&
            this.x < plate.x + plate.w &&
            this.y + this.h > plate.y &&
            this.y + this.h < plate.y + plate.h + 5
        ) {
            this.y = plate.y - this.h;

            plate.vy += this.vy * Math.sqrt(this.mass) * 0.5;

            this.vy *= -this.bounce;
        }
    }

    // box
    draw() {
        ctx.beginPath();
        ctx.fillStyle = "#ccc";
        ctx.fillRect(this.x, this.y, this.w, this.h);
        ctx.fill();
        ctx.closePath();

        ctx.beginPath();
        ctx.fillStyle = '#000';
        ctx.font = '14px Arial';
        ctx.fillText(`Mass: ${this.mass}kg`, this.x + 5, this.y + 40);
        ctx.fill();
        ctx.closePath();
    }
}

class Plate extends Body {
    constructor() {
        super();
        this.baseX = 400;
        this.baseY = 500;

        this.x = this.baseX;
        this.y = this.baseY;

        this.w = 200;
        this.h = 20;

        this.vy = 0;        // tezlik
        this.k = 0.08;      // spring stiffness
        this.damping = 0.9; // tebranishni sekin kamaytiradi
    }

    update() {
        let displacement = this.y - this.baseY; // qanchaga bosildi
        let force = -this.k * displacement;

        this.vy += force;
        this.vy *= this.damping; // tebranishni kamaytirish
        this.y += this.vy;

        let maxDisplacement = 100;

        if (this.y > this.baseY + maxDisplacement) {
            this.y = this.baseY + maxDisplacement;
            this.vy = 0;
        }
    }

    draw() {
        ctx.beginPath();
        ctx.fillStyle = "#37f0f7";
        ctx.fillRect(this.x, this.y, this.w, this.h);
        ctx.fill();
        ctx.closePath();
    }
}

let body = new Body();
let box = new Box();
let plate = new Plate();


const init = () => {
    box.update();
    box.draw();

    plate.update();
    plate.draw();

    body.draw();
}


function loop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    /*  */
    init();
    /*  */

    requestAnimationFrame(loop);
}
loop();





