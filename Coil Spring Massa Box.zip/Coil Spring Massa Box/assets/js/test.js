

const canvas = document.getElementById("c");
const ctx = canvas.getContext("2d");

canvas.width = 1000;
canvas.height = 800;

class Box {
    constructor() {
        this.x = canvas.width / 2 - 40;
    }
}

// 📦 BOX
let box = {
    x: canvas.width / 2 - 40,
    y: 100,
    w: 80,
    h: 80,
    vy: 0,
    dragging: false,
    offsetX: 0,
    offsetY: 0
};

let plate

const gravity = 0.6;
const ground = canvas.height - 100;



// 🔁 UPDATE
function update() {
    if (!box.dragging) {
        box.vy += gravity;
        box.y += box.vy;

        // 🧱 ground collision
        if (box.y + box.h > ground) {
            box.y = ground - box.h;
            box.vy = 0;
        }
    }
}

// 🎨 DRAW
function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // ground
    ctx.fillStyle = "#444";
    ctx.fillRect(0, ground, canvas.width, 5);

    // box
    ctx.fillStyle = "#ccc";
    ctx.fillRect(box.x, box.y, box.w, box.h);
}

// 🔄 LOOP
function loop() {
    update();
    draw();
    requestAnimationFrame(loop);
}
loop();

// 🖱️ MOUSEDOWN
canvas.onmousedown = (e) => {
    if (
        e.offsetX > box.x &&
        e.offsetX < box.x + box.w &&
        e.offsetY > box.y &&
        e.offsetY < box.y + box.h
    ) {
        box.dragging = true;
        box.offsetX = e.offsetX - box.x;
        box.offsetY = e.offsetY - box.y;
        box.vy = 0;
    }
};

// 🖱️ MOVE
canvas.onmousemove = (e) => {
    if (box.dragging) {
        box.x = e.offsetX - box.offsetX;
        box.y = e.offsetY - box.offsetY;
    }
};

// 🖱️ UP
canvas.onmouseup = () => {
    box.dragging = false;
};
