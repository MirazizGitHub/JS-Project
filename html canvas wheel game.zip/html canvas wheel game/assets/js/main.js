
const canvas = document.querySelector("#canvas");
const ctx = canvas.getContext("2d");

let loadFont = false;

class Game {
    constructor() {
        this.width = 450;
        this.height = 720;

        canvas.width = this.width;
        canvas.height = this.height;

        this.padding = {
            x: 20, y: 20,
        }

        this.scale = 1;

        this.btn = document.querySelector('.fullScreen');

        this.resize();
        this.body();

        window.addEventListener('resize', () => this.resize());

        /*  */
        this.wheel = new Wheel(this);
        /*  */
    }

    init() {
        /*  */
        this.wheel.update();
        this.wheel.draw();
        /*  */
    }

    body() {
        /*  */

        let toggleBtn = false;
        this.btn.onclick = () => {
            toggleBtn = !toggleBtn;
            if (toggleBtn === true) {
                this.goFullscreen();
            } else {
                this.exitFullscreen();
            }
        }

        /*  */
    }

    goFullscreen() {
        const element = document.documentElement;

        if (element.requestFullscreen) {
            element.requestFullscreen();
        } else if (element.mozRequestFullScreen) {
            element.mozRequestFullScreen();
        } else if (element.webkitRequestFullscreen) {
            element.webkitRequestFullscreen();
        } else if (element.msRequestFullscreen) {
            element.msRequestFullscreen();
        } else {
            alert("Bu brauzer to'liq ekranni qo'llab-quvvatlamaydi.");
        }
    }

    exitFullscreen() {
        if (document.exitFullscreen) {
            document.exitFullscreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
    }

    resize() {
        const scale = Math.min(
            (window.innerWidth - this.padding.x) / this.width,
            (window.innerHeight - this.padding.y) / this.height
        );

        this.scale = scale;

        const dpr = window.devicePixelRatio || 1;

        canvas.width = this.width * scale * dpr;
        canvas.height = this.height * scale * dpr;

        canvas.style.width = this.width * scale + "px";
        canvas.style.height = this.height * scale + "px";

        ctx.scale(scale * dpr, scale * dpr);
    }

}

let game = new Game();



function loop() {
    if (!loadFont) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    game.init();

    requestAnimationFrame(loop);
}

Promise.all([
    document.fonts.load("1em Science Gothic"),
]).then(() => {
    loadFont = true;
    loop();
});

/*
const BurbankFont = new FontFace('BurbankFont', 'url(./assets/fonts/Burbank-Big-Condensed-Bold.otf)');

BurbankFont.load().then(function () {
    document.fonts.add(BurbankFont);

    loadFont = true;
    loop();
    

}).catch(function (error) {
    console.log("not found font:", error);
});
*/

/*
Promise.all([
    document.fonts.load("1em Poppins"),
]).then(() => {
    loadFont = true;
    loop();
});
*/