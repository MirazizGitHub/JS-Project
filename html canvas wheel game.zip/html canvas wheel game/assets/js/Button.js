class Button {
    constructor(pos, size, bgImg, wheel, font) {
        this.x = pos.x;
        this.y = pos.y;

        this.bgImg = bgImg;

        this.width = size[0];
        this.height = size[1];
        this.targetScale = 1;
        this.scale = 1;

        this.down = false;
        this.hover = false;

        this.font = font;
        this.wheel = wheel;

        this.canvasRect = canvas.getBoundingClientRect();

        this.activeBtn = true;
    }

    update() {
        this.scale += (this.targetScale - this.scale) * 0.2;
    }

    draw(bools) {
        this.activeBtn === bools;

        ctx.beginPath();

        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.scale(this.scale, this.scale);

        ctx.drawImage(this.bgImg, -this.width / 2, -this.height / 2, this.width, this.height);


        ctx.fillStyle = this.font.color1;
        ctx.font = this.font.font;
        ctx.textBaseline = "middle";
        ctx.textAlign = "center";
        ctx.fillText(this.font.text, 0, 2);

        ctx.restore();
        ctx.closePath();
    }

    buttonFunc() {
        canvas.addEventListener('mousemove', e => {
            if (!this.activeBtn) return; // ❗ shu nuqta masalani yechadi

            const rect = canvas.getBoundingClientRect();
            let mouseX = (e.clientX - rect.left) / this.wheel.game.scale;
            let mouseY = (e.clientY - rect.top) / this.wheel.game.scale;

            this.hover =
                mouseX >= this.x - this.width / 2 &&
                mouseX <= this.x + this.width / 2 &&
                mouseY >= this.y - this.height / 2 &&
                mouseY <= this.y + this.height / 2;

            this.targetScale = this.hover ? (this.down ? 0.9 : 1.1) : 1;
            canvas.style.cursor = this.hover ? "pointer" : "default";
        });

        canvas.addEventListener('mousedown', e => {
            if (!this.activeBtn) return;
            if (this.hover) {
                this.down = true;
                this.targetScale = 0.9;
            }
        });

        canvas.addEventListener('mouseup', e => {
            if (!this.activeBtn) return;
            if (this.down && this.hover) {
                this.wheel.spinFunc();
                this.activeBtn = false;
                canvas.style.cursor = "default";
            }
            this.down = false;
            this.targetScale = this.hover ? 1.1 : 1;
        });
    }

}