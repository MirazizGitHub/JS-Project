class Wheel {
    constructor(game) {
        this.game = game;
        this.pos = {
            x: this.game.width / 2,
            y: this.game.height / 2,
        };

        this.size = 400;
        this.radius = this.size * 0.5;

        this.winValue = 0;

        this.imgBg = new Image();
        this.imgDot = new Image();
        this.imgPoint = new Image();
        this.img1 = new Image();
        this.img2 = new Image();
        this.priceBg = new Image();
        this.giftImg = new Image();
        this.logo = new Image();

        this.waitingTime = '23h : 59m : 59s';
        this.startBtn = true;

        this.imgBg.src = './assets/images/wheel-bg.png';
        this.imgDot.src = './assets/images/wheel-dot.png';

        this.imgPoint.src = './assets/images/point-1.png';

        // this.priceBg.src = './assets/images/price-bg-1.png';
        // this.priceBg.src = './assets/images/price-bg-2.png';
        this.priceBg.src = './assets/images/price-bg-3.png';

        // this.img1.src = './assets/images/seg-fire-1.png';
        // this.img2.src = './assets/images/seg-fire-2.png';

        this.img1.src = './assets/images/seg-ice-1.png';
        this.img2.src = './assets/images/seg-ice-2.png';

        this.giftImg.src = './assets/images/gift-1.png';
        this.logo.src = './assets/images/logo.png';

        this.segmentBase = [
            { id: '1', img: '', value: '22' },
            { id: '2', img: this.giftImg, value: '333' },
            { id: '3', img: '', value: '2' },
            { id: '4', img: '', value: '55' },
            { id: '5', img: '', value: '71' },
            { id: '6', img: '', value: '33' },
            { id: '7', img: '', value: '1.7' },
            { id: '8', img: this.giftImg, value: '455' },
            { id: '9', img: '', value: '0.5' },
            { id: '10', img: '', value: '89' },
            { id: '11', img: '', value: '66' },
            { id: '12', img: '', value: '88' },
        ];

        this.winArray = ['7', '3', '10'];

        this.segment = this.segmentBase.length;

        this.segmentImgs = [];

        for (let a = 0; a < this.segment; a++) {
            this.segmentImgs.push(a % 2 == 0 ? this.img1 : this.img2);
        }

        this.segmentMove = 0;

        this.spinBgImg = new Image();
        this.spinBgImg.src = './assets/images/button-bg-1.png';

        this.spinButton = new Button(
            { x: 225, y: 620 },
            [130, 40],
            this.spinBgImg, this,
            { color1: '#67431b', font: '25px Science Gothic', text: 'Spin' }
        );
        this.spinButton.buttonFunc();


        this.startAngle = false;

        this.angle = 0;

        this.maxDeg = 30;
        this.counterDeg = 0;
        this.maxSpeed = 0.1;
        this.minSpeed = 0.001;
        this.speed = 0;
        this.friction = 0.985;
    }


    update() {
        if (this.startAngle === true) {

            this.counterDeg = Math.abs(this.angle * (180 / Math.PI));

            const progress = this.counterDeg / this.maxDeg;
            this.speed = this.maxSpeed - (this.maxSpeed - this.minSpeed) * progress;

            this.angle -= this.speed;

            if (this.counterDeg >= this.maxDeg) {
                this.angle = -this.maxDeg * (Math.PI / 180);
                this.startAngle = false;
                console.log(true);
            }
        }


        const deg = this.angle * (180 / Math.PI);
        let normalized = (deg % 360 + 360) % 360;
        const segmentAngle = 360 / this.segment;
        const index = Math.floor(normalized / segmentAngle);
        const fixedIndex = (this.segment - index - 1 + this.segment) % this.segment;

        // ctx.beginPath();
        // ctx.fillStyle = 'white';
        // ctx.font = '15px Calibri';
        // ctx.fillText(`rotate: ${fixedIndex}`, 10, 90);
        // ctx.fillText(`Gift: ${this.segmentBase[fixedIndex].value}`, 10, 110);
        // ctx.fillText(`Angle: ${deg}`, 10, 130);
        // ctx.fillText(`deg: ${index}`, 10, 150);
        // ctx.fillText(`Id: ${this.segmentBase.length - index}`, 10, 170);
        // ctx.fill();
        // ctx.closePath();
    }


    draw() {
        const sliceCount = this.segmentBase.length;

        // size 200x73
        this.drawImages({ x: 95, y: 40 }, 0, this.priceBg, { size: [180, 65.7] });
        this.drawImages({ x: 40, y: 40 }, 0, this.logo, { size: [40, 40] });

        this.drawText({ x: 0, y: 48 }, 0, { x: -20, y: 0 }, 25, 0, 140, this.winValue, {
            color1: 'gold',
            textLineWidth: 0.5,
            color2: '#fff',
        });

        if (this.startBtn === false) {
            this.drawText({ x: 80, y: 630 }, 0, { x: 0, y: 0 }, 40, 0, 140, this.waitingTime, {
                color1: 'gold',
                textLineWidth: 0.5,
                color2: '#fff',
            });
        }

        // wheel js code
        this.drawImages(this.pos, -this.angle, this.imgBg, { size: [440, 440], });
        for (let i = 0; i < sliceCount; i++) {
            const offset = -Math.PI / 2;
            const startAngle = this.angle + offset + 2 * Math.PI * (i / sliceCount);
            const endAngle = this.angle + offset + 2 * Math.PI * ((i + 1) / sliceCount);

            const imageRotate = ((startAngle + endAngle) / 2) - this.segmentMove;

            this.drawImages(this.pos, imageRotate, this.segmentImgs[i], { pos: { x: -46, y: -188, }, size: [92, 165], });
        }
        for (let i = 0; i < sliceCount; i++) {
            const offset = -Math.PI / 2;
            const startAngle = this.angle + offset + 2 * Math.PI * (i / sliceCount);
            const endAngle = this.angle + offset + 2 * Math.PI * ((i + 1) / sliceCount);

            const midAngle = (startAngle + endAngle) / 2;

            if (this.segmentBase[i].img !== '') {
                const giftOffset = { x: 160, y: -0 };
                const giftSize = [60, 60];

                this.drawGift(this.pos, midAngle, this.segmentBase[i].img, giftOffset, giftSize, 1.5);

            }

            const iconOffset = { x: 120, y: -0 };
            const iconSize = [20, 20];
            this.drawGift(this.pos, midAngle, this.logo, iconOffset, iconSize, 1.5);

            const textSize = 25;
            const textOffset = { x: 0, y: 0 };

            this.drawText(this.pos, midAngle, textOffset, textSize, 1.5, 140, this.segmentBase[i].value, {
                color1: 'gold',
                textLineWidth: 0.5,
                color2: '#fff',
            });

        }
        this.drawImages(this.pos, -this.angle * 2, this.imgDot, { size: [42, 42], });
        this.drawImages({ x: this.pos.x, y: this.pos.y - (this.size / 2) }, 0, this.imgPoint, { size: [100, 100] });

        if (this.startBtn === true) {
            this.spinButton.update();
            this.spinButton.draw(this.startBtn);
        }
    }

    drawImages(pos, angle, imgs, data) {

        let imgPos = { x: data.size[0] / -2, y: data.size[1] / -2, };

        ctx.beginPath();
        ctx.save();
        ctx.translate(pos.x, pos.y);
        ctx.rotate(angle);
        if (data.pos !== undefined && data.pos !== null) {
            ctx.drawImage(imgs, data.pos.x, data.pos.y, data.size[0], data.size[1]);
        } else {
            ctx.drawImage(imgs, imgPos.x, imgPos.y, data.size[0], data.size[1]);
        }
        ctx.restore();
        ctx.closePath();
    }

    drawGift(pos, segmentAngle, giftImg, giftOffset, giftSize, extraRotate = 0) {

        ctx.beginPath();

        ctx.save();
        ctx.translate(pos.x, pos.y);
        ctx.rotate(segmentAngle);

        ctx.translate(giftOffset.x, giftOffset.y);
        ctx.rotate(extraRotate);

        ctx.drawImage(
            giftImg,
            -giftSize[0] / 2,
            -giftSize[1] / 2,
            giftSize[0],
            giftSize[1]
        );

        ctx.restore();
        ctx.closePath();
    }

    drawText(pos, segmentAngle, textOffset, textSize, extraRotate = 0, textRadius, textss, txx) {

        let poss = {
            x: pos.x + Math.cos(segmentAngle) * textRadius,
            y: pos.y + Math.sin(segmentAngle) * textRadius,
        }


        ctx.beginPath();

        ctx.save();
        ctx.translate(poss.x, poss.y);
        ctx.rotate(segmentAngle);

        ctx.translate(textOffset.x, textOffset.y);
        ctx.rotate(extraRotate);

        if (!txx) return;

        ctx.strokeStyle = txx.color1; // text color 1
        ctx.lineWidth = txx.textLineWidth; // text line width
        ctx.fillStyle = txx.color2; // text color 2
        ctx.font = `bold ${textSize}px Science Gothic`;

        const w = ctx.measureText(textss).width;

        ctx.fillText(`${textss}`, -w / 2, 0);
        ctx.strokeText(`${textss}`, -w / 2, 0);

        ctx.stroke();
        ctx.fill();

        ctx.restore();
        ctx.closePath();
    }

    spinFunc() {
        if (this.startBtn === true) {

            this.startBtn = false;

            const segmentAngle = 360 / this.segment;
            const winId = parseInt(this.winArray[Math.floor(Math.random() * this.winArray.length)]);

            let winIndex = this.segmentBase[winId - 1].id;

            let minusRot = Math.floor(Math.random() * segmentAngle);

            const targetAngle = winIndex * segmentAngle;
            const fullSpin = 360 * 2;

            this.maxDeg = (fullSpin + targetAngle) - minusRot;
            this.startAngle = true;

            console.log(this.maxDeg);

        }
    }


}
