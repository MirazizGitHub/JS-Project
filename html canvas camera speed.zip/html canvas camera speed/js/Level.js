class Level {
    constructor(options) {
        this.objects = [];
        /* camera start */
        this.size = options.size || [canvas.width, canvas.height];
        this.cameraPos = options.cameraPos || [this.size[0] / 2, this.size[1] / 2];
        /**/
        this.bg = options.objects.backgroundEffect;
        this.player_array = options.objects.player;
        this.box = options.objects.box;
        this.player = null;

        this.cameraSpeed = 500;
        /**/

        //
    }
    updateCamera() {
        /**/
        this.bg.forEach(bgc => {
            bgc.level = this;
            bgc.update();
            bgc.draw();
        });
        this.box.forEach(obj => {
            obj.level = this;
            obj.update();
            obj.draw();
        });
        this.player_array.forEach(pl => {
            pl.level = this;
            pl.update();
            pl.draw();
            this.player = pl;
        });
        /**/
    }
    update(deltaTime) {
        /**/
        this.updateCamera();

        this.cameraPos__numb__x = minmax(
            (this.player.pos.x + this.player.size[0]) - canvas.width / 2,
            0,
            this.size[0] - canvas.width
        );

        this.cameraPos__numb__y = minmax(
            this.player.pos.y - canvas.height / 2,
            0,
            this.size[1] - canvas.height
        );

        const speed = this.cameraSpeed * deltaTime;
        this.cameraPos[0] += (this.cameraPos__numb__x - this.cameraPos[0]) * speed / 100;
        this.cameraPos[1] += (this.cameraPos__numb__y - this.cameraPos[1]) * speed / 100;

    }
    draw() {
        ctx.beginPath();
        ctx.fillStyle = "white";
        ctx.font = "30px Arial";
        ctx.fillText(`Camera player pos x: ${this.cameraPos__numb__x.toFixed(0)}, y: ${this.cameraPos__numb__y.toFixed(0)} `, 50, 50);
        ctx.closePath();
    }
}
function minmax(val, min, max) {
    return Math.max(min, Math.min(max, val));
}