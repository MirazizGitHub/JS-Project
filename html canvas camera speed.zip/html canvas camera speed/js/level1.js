let level1 = new Level({
    size: [2000, 1000],
    objects: {
        backgroundEffect: [
            new Background(),
        ],
        player: [
            new Player(),
        ],
        box: [
            new Box([0, 300], [200, 30], '#0000ff'),  
            new Box([250, 200], [100, 30], '#9900cc'),
            new Box([450, 300], [100, 30], '#ff0066'),
            new Box([650, 200], [100, 30], '#ff9900'),
            new Box([850, 100], [100, 30], '#663300'),
            new Box([1050, 200], [100, 30], '#009900'),
            new Box([1250, 300], [100, 30], '#003300'),
            new Box([1450, 200], [100, 30], 'lime'),
            new Box([1650, 100], [100, 30], 'orangered'),
            new Box([1850, 100], [150, 30], '#292924'),

            // Qo'shimcha boxlar qavat-qavat joylashadi
            new Box([100, 450], [200, 30], '#123456'),   
            new Box([250, 500], [150, 30], '#654321'), 
            new Box([500, 600], [150, 30], '#abcdef'), 
            new Box([750, 700], [150, 30], '#fedcba'), 
            new Box([1000, 800], [150, 30], '#ff0000'),
            new Box([1250, 900], [150, 30], '#00ff00'),
            new Box([1500, 400], [150, 30], '#0000ff'),
            new Box([1750, 500], [150, 30], '#ffff00'),
            new Box([2000, 600], [150, 30], '#ff00ff'),

        ]
    }
});