class Box {
    constructor(pos, size, color) {
        this.pos = [...pos];
        this.size = [...size];
        /*this.color = `hsl(${Math.random() * 361}, 100%, 50%)`;*/
        this.bg_images = new Image();
        this.bg_images.src = 'rectangle.png';
        this.color = color;
        this.level = null;
    }
    update() {  }
    draw() {
        ctx.beginPath();
        ctx.fillStyle = this.color;
        // ctx.fillRect(
        //     this.pos[0] - this.level.cameraPos[0],
        //     this.pos[1] - this.level.cameraPos[1],
        //     this.size[0], this.size[1]
        // );
        ctx.drawImage(
            this.bg_images,
            this.pos[0] - this.level.cameraPos[0],
            this.pos[1] - this.level.cameraPos[1],
            this.size[0], this.size[1]
        );
        ctx.closePath();
    }
}