
function init(deltaTime) {
    /*  */
    level1.update(deltaTime);
    level1.draw();
    /*objects*/
    /*  */
}



