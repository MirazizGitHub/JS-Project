const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

canvas.width = window.innerWidth / 2;
canvas.height = window.innerHeight / 1.3;

let arrowRight = false, arrowTop = false, arrowLeft = false;






let lastTime = performance.now();

function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

	const now = performance.now();
    const deltaTime = (now - lastTime) / 1000;
    lastTime = now;
    /* */
    init(deltaTime);
    /* */
    requestAnimationFrame(animate);
}
controller();
animate();

function controller () {
	document.addEventListener('keydown', function(event) {
		if (event.keyCode === 37) {
			arrowLeft = true;
		}
		if (event.keyCode === 38) {
			arrowTop = true;
		}
		if (event.keyCode === 39) {
			arrowRight = true;
		}
	});
	document.addEventListener('keyup', function(event) {
		if (event.keyCode === 37) {
			arrowLeft = false;
		}
		if (event.keyCode === 38) {
			arrowTop = false;
		}
		if (event.keyCode === 39) {
			arrowRight = false;
		}
	});
}
